fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Alk Store'
description 'Alk Store | شات السيرفر'
version '2.0.0'

dependency 'vrp'

ui_page 'html/index.html'

shared_script '@vrp/AlkStore-Config/Scripts_Config/الشات.lua'

client_script 'client/main.lua'

server_scripts {
    '@vrp/lib/utils.lua',
    '@vrp/AlkStore-Config/Scripts_Config/الشات_sv.lua',
    'server/main.lua',
    'server/admin.lua',
}

files {
    'html/index.html',
    'html/style.css',
    'html/app.js',
    'html/emojis.js',
}
