-- Alk Store | الشات: اوامر قائمة الادارة (منقولة من الشات القديم كما هي)
-- الاعدادات في: vrp/AlkStore-Config/Scripts_Config/الشات_sv.lua
local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")
vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP", "Alk-Chat")

RegisterServerEvent("LuaQV22:Server:DeleteMessage")
AddEventHandler("LuaQV22:Server:DeleteMessage", function(user_id)
    local source_id = vRP.getUserId({source})
    local user_source = vRP.getUserSource({user_id})
    if vRP.hasPermission({source_id,DeletemMessage}) then
        TriggerClientEvent("chat:DeleteAll", -1, user_id)
		log({
			url = LogDeletemMessages,
			title = 'لوق مسح الشات',
			fields = {
				{
					name = "`ايدي المستخدم:`",
					value = "[ " .. source_id .. " ]"
				},
				{
					name = "`اسم المستخدم:`",
					value = "[ " .. vRP.getPlayerName({source}) .. " ]"
				}
			}
		})
		TriggerClientEvent('AlkStore:Notify', source, {
			icon = "auto_read_pause",
			title = "رسالة من السيرفر",
			appname = LUA.Server.LUAServerName,
			message = "تم حذف رساله الاعب",
			time = 5000,
			sound = "not1"
		})
    end
end)

RegisterServerEvent("LuaQV22:Server:EditMessage")
AddEventHandler("LuaQV22:Server:EditMessage", function(message_id)
    local source_id = vRP.getUserId({source})
	if source_id ~= nil then
		if message_id:sub(10, 12) == tostring(source_id) then
			vRP.prompt({source,"الرسالة : ","",function(player,message)
				if message ~= nil then
					TriggerClientEvent("chat:Edit", -1, message_id , message)
					log({
						url = LogEditMessage,
						title = 'لوق تعديل رسالة',
						fields = {
							{
								name = "`ايدي المستخدم:`",
								value = "[ " .. source_id .. " ]"
							},
							{
								name = "`اسم المستخدم:`",
								value = "[ " .. vRP.getPlayerName({player}) .. " ]"
							},
							{
								name = "`الرسالة بعد التعديل:`",
								value = "[ " .. message .. " ]"
							},
						}
					})
					TriggerClientEvent('AlkStore:Notify', source, {
						icon = "success",
						title = "تم بنجاح",
						appname = LUA.Server.LUAServerName,
						message = "تم تعديل الرسالة",
						time = 5000,
						sound = "not1"
					})
				end
			end})
		else
			TriggerClientEvent("chatMessage", source ,'[ChatSystem] | ',{255,0,0}, 'لا يمكن التعديل على رسالة شخص اخر')
		end
	end
end)

RegisterServerEvent("LuaQV2:clearInventory")
AddEventHandler("LuaQV2:clearInventory", function(user_id)
    local source_id = vRP.getUserId({source})
    local user_source = vRP.getUserSource({user_id})
    if vRP.hasPermission({source_id,permclearinv}) then
    vRP.clearInventory({user_id})
	log({
		url = LogClearinv,
		title = 'لوق افراغ الحقيبة',
		fields = {
			{
				name = "`ايدي المستخدم:`",
				value = "[ " .. source_id .. " ]"
			},
			{
				name = "`اسم المستخدم:`",
				value = "[ " .. vRP.getPlayerName({source}) .. " ]"
			},
			{
				name = "`ايدي المستهدف:`",
				value = "[ " .. user_id .. " ]"
			},
			{
				name = "`اسم المستهدف:`",
				value = "[ " .. vRP.getPlayerName({user_source}) .. " ]"
			}
		}
	})
	TriggerClientEvent('AlkStore:Notify', source, {
		icon = "success",
		title = "تم بنجاح",
		appname = LUA.Server.LUAServerName,
		message = "["..source_id.."] تم افراغ حقيبة اللاعب : ايدي اللاعب",
		time = 5000,
		sound = "not1"
	})
    --onsucc(source)
    else 
        --oneror(source)
    end
end)

RegisterServerEvent("LuaQV22:Client:ChatMessageCuff")
AddEventHandler("LuaQV22:Client:ChatMessageCuff", function()
    local source_id = vRP.getUserId({source})
	TriggerClientEvent('AlkStore:Notify', source, {
		icon = "error",
		title = "خطأ",
		appname = LUA.Server.LUAServerName,
		message = "انت مقيد لا يمكنك استخدام الشات",
		time = 5000,
		sound = "not1"
	})
end)



RegisterServerEvent("LuaQV2:SetHunger-Thirst")
AddEventHandler("LuaQV2:SetHunger-Thirst", function(user_id)
    local source_id = vRP.getUserId({source})
    local user_source = vRP.getUserSource({user_id})
    if vRP.hasPermission({source_id,permSetHunger}) then
    vRP.setHunger({user_id,0})
    vRP.setThirst({user_id,0})
	log({
		url = LogSetHunger,
		title = 'لوق تعبئة الاكل و الشرب',
		fields = {
			{
				name = "`ايدي المستخدم:`",
				value = "[ " .. source_id .. " ]"
			},
			{
				name = "`اسم المستخدم:`",
				value = "[ " .. vRP.getPlayerName({source}) .. " ]"
			},
			{
				name = "`ايدي المستهدف:`",
				value = "[ " .. user_id .. " ]"
			},
			{
				name = "`اسم المستهدف:`",
				value = "[ " .. vRP.getPlayerName({user_source}) .. " ]"
			}
		}
	})
    --onsucc(source)
	TriggerClientEvent('AlkStore:Notify', source, {
		icon = "success",
		title = "تم بنجاح",
		appname = LUA.Server.LUAServerName,
		message = "تم تعبئة الاكل و الشرب",
		time = 5000,
		sound = "not1"
	})											
    else 
        --oneror(source)
    end
end)
-- تم كلبشة اللاعب بنجاح

RegisterServerEvent("LuaQV2:toggleHandcuff")
AddEventHandler("LuaQV2:toggleHandcuff", function(user_id)
    local source_id = vRP.getUserId({source})
    local user_source = vRP.getUserSource({user_id})
    if vRP.hasPermission({source_id,permCuff}) then
    if user_source ~= nil then
        vRPclient.toggleHandcuff(user_source)
		log({
			url = LogCuff,
			title = 'لوق كلبشة لاعب',
			fields = {
				{
					name = "`ايدي المستخدم:`",
					value = "[ " .. source_id .. " ]"
				},
				{
					name = "`اسم المستخدم:`",
					value = "[ " .. vRP.getPlayerName({source}) .. " ]"
				},
				{
					name = "`ايدي المستهدف:`",
					value = "[ " .. user_id .. " ]"
				},
				{
					name = "`اسم المستهدف:`",
					value = "[ " .. vRP.getPlayerName({user_source}) .. " ]"
				}
			}
		})
		TriggerClientEvent('AlkStore:Notify', source, {
			icon = "success",
			title = "تم بنجاح",
			appname = LUA.Server.LUAServerName,
			message = "تم كلبشة اللاعب",
			time = 5000,
			sound = "not1"
		})	
    --onsucc(source)
    else 
        --oneror(source)
    end
    end
end)
 -- تم سحب اللاعب بخاصية الكلبشة

RegisterServerEvent("LuaQV2:toggleHandcuff:tp")
AddEventHandler("LuaQV2:toggleHandcuff:tp", function(user_id)
    local source_id = vRP.getUserId({source})
    local user_source = vRP.getUserSource({user_id})
    if vRP.hasPermission({source_id,permCufftp}) then
    if user_source ~= nil then
        vRPclient.getPosition(source,{}, function(x,y,z)
        vRPclient.teleport(user_source,{x,y,z})
        vRPclient.setHandcuffed(user_source,{true})
		TriggerClientEvent("dr:drag", user_source, source)
		TriggerClientEvent('AlkStore:Notify', source, {
			icon = "success",
			title = "تم بنجاح",
			appname = LUA.Server.LUAServerName,
			message = "تم سحب اللاعب بخاصية الكلبشة",
			time = 5000,
			sound = "not1"
		})	
         --notify here
        end)
   
    end
  --  --onsucc(source)
    else 
   --     --oneror(source)
    end
end)


 -- تم اعطاء الرتبة بنجاح
RegisterServerEvent("LuaQV2:AddGroup")
AddEventHandler("LuaQV2:AddGroup", function(user_id)
 local src = source
    local source_id = vRP.getUserId({source})
    local user_source = vRP.getUserSource({user_id})
    if vRP.hasPermission({source_id,permaddgroup}) then
    if user_source ~= nil then
        vRP.prompt({source,"الرتبة المراد اضافة اللاعب اليها : ","",function(source,group)
            vRP.addUserGroup({user_id,group})

			log({
				url = LogAddgroup,
				title = 'لوق اعطاء رتبة',
				fields = {
					{
						name = "`ايدي المستخدم:`",
						value = "[ " .. source_id .. " ]"
					},
					{
						name = "`اسم المستخدم:`",
						value = "[ " .. vRP.getPlayerName({source}) .. " ]"
					},
					{
						name = "`ايدي المستهدف:`",
						value = "[ " .. user_id .. " ]"
					},
					{
						name = "`اسم المستهدف:`",
						value = "[ " .. vRP.getPlayerName({user_source}) .. " ]"
					},
					{
						name = "`الرتبة:`",
						value = "[ " .. group .. " ]"
					},
				}
			})
			TriggerClientEvent('AlkStore:Notify', source, {
				icon = "success",
				title = "تم بنجاح",
				appname = LUA.Server.LUAServerName,
				message = "تم اعطاء الرتبة",
				time = 5000,
				sound = "not1"
			})	
          end})
 --  --onsucc(source)
    end

    else 
  --      --oneror(source)
    end
end)

 -- تم ازالة الرتبة بنجاح
RegisterServerEvent("LuaQV2:RemoveGroup")
AddEventHandler("LuaQV2:RemoveGroup", function(user_id)
local src = source
    local source_id = vRP.getUserId({source})
    local user_source = vRP.getUserSource({user_id})
    if vRP.hasPermission({source_id,permremovegroup}) then
    if user_source ~= nil then
        vRP.prompt({source,"الرتبة المراد ازالة اللاعب منها : ","",function(source,group)
            vRP.removeUserGroup({user_id,group})
            --notify here
			log({
				url = LogRemovegroup,
				title = 'لوق سحب رتبة',
				fields = {
					{
						name = "`ايدي المستخدم:`",
						value = "[ " .. source_id .. " ]"
					},
					{
						name = "`اسم المستخدم:`",
						value = "[ " .. vRP.getPlayerName({source}) .. " ]"
					},
					{
						name = "`ايدي المستهدف:`",
						value = "[ " .. user_id .. " ]"
					},
					{
						name = "`اسم المستهدف:`",
						value = "[ " .. vRP.getPlayerName({user_source}) .. " ]"
					},
					{
						name = "`الرتبة:`",
						value = "[ " .. group .. " ]"
					},
				}
			})	
			TriggerClientEvent('AlkStore:Notify', source, {
				icon = "success",
				title = "تم بنجاح",
				appname = LUA.Server.LUAServerName,
				message = "تم ازالة الرتبة",
				time = 5000,
				sound = "not1"
			})	
          end})
   
    end
  --  --onsucc(source)
    else 
  --      --oneror(source)
    end
end)

-- تم طرد اللاعب بنجاح

RegisterServerEvent("LuaQV2:Kick")
AddEventHandler("LuaQV2:Kick", function(user_id)
    local source_id = vRP.getUserId({source})
    local user_source = vRP.getUserSource({user_id})
    if vRP.hasPermission({source_id,permKick}) then
    if user_source ~= nil then
        vRP.prompt({source,"السبب : ","",function(source,reason)
           log({
				url = LogKick,
				title = 'لوق طرد لاعب',
				fields = {
					{
						name = "`ايدي المستخدم:`",
						value = "[ " .. source_id .. " ]"
					},
					{
						name = "`اسم المستخدم:`",
						value = "[ " .. vRP.getPlayerName({source}) .. " ]"
					},
					{
						name = "`ايدي المستهدف:`",
						value = "[ " .. user_id .. " ]"
					},
					{
						name = "`اسم المستهدف:`",
						value = "[ " .. vRP.getPlayerName({user_source}) .. " ]"
					},
					{
						name = "`السبب:`",
						value = "[ " .. reason .. " ]"
					},
				}
			})
		   vRP.kick({user_source,reason})
		   TriggerClientEvent('AlkStore:Notify', source, {
			icon = "success",
			title = "تم بنجاح",
			appname = LUA.Server.LUAServerName,
			message = "تم طرد اللاعب",
			time = 5000,
			sound = "not1"
		})	
        end})
    end
   -- --onsucc(source)
    else 
 --       --oneror(source)
    end
end)


 -- تم تبنيد اللاعب بنجاح
RegisterServerEvent("LuaQV2:ban")
AddEventHandler("LuaQV2:ban", function(user_id)
    local source_id = vRP.getUserId({source})
    local user_source = vRP.getUserSource({user_id})
    if vRP.hasPermission({source_id,permBanned}) then
    if user_source ~= nil then
        vRP.prompt({source,"السبب : ","",function(source,reason)
			log({
				url = LogBanned,
				title = 'لوق حظر لاعب',
				fields = {
					{
						name = "`ايدي المستخدم:`",
						value = "[ " .. source_id .. " ]"
					},
					{
						name = "`اسم المستخدم:`",
						value = "[ " .. vRP.getPlayerName({source}) .. " ]"
					},
					{
						name = "`ايدي المستهدف:`",
						value = "[ " .. user_id .. " ]"
					},
					{
						name = "`اسم المستهدف:`",
						value = "[ " .. vRP.getPlayerName({user_source}) .. " ]"
					},
					{
						name = "`السبب:`",
						value = "[ " .. reason .. " ]"
					},
				}
			})
            vRP.ban({user_source,"[Banned] "..reason})
			TriggerClientEvent('AlkStore:Notify', source, {
				icon = "success",
				title = "تم بنجاح",
				appname = LUA.Server.LUAServerName,
				message = "تم تبنيد اللاعب",
				time = 5000,
				sound = "not1"
			})	
            --notify here
          end})
   
    end
   -- --onsucc(source)
    else 
    --    --oneror(source)
    end
end)

-- تم انعاش اللاعب بنجاح
RegisterServerEvent("LuaQV2:revive")
AddEventHandler("LuaQV2:revive", function(user_id)
    local source_id = vRP.getUserId({source})
    local user_source = vRP.getUserSource({user_id})
    if vRP.hasPermission({source_id,permrevive}) then
    if user_source ~= nil then
        vRPclient.varyHealth(user_source,{100})
        vRP.varyHunger({user_id,-100})
        vRP.varyThirst({user_id,-100})
		log({
			url = LogRevive,
			title = 'لوق انعاش',
			fields = {
				{
					name = "`ايدي المستخدم:`",
					value = "[ " .. source_id .. " ]"
				},
				{
					name = "`اسم المستخدم:`",
					value = "[ " .. vRP.getPlayerName({source}) .. " ]"
				},
				{
					name = "`ايدي المستهدف:`",
					value = "[ " .. user_id .. " ]"
				},
				{
					name = "`اسم المستهدف:`",
					value = "[ " .. vRP.getPlayerName({user_source}) .. " ]"
				}
			}
		})
		TriggerClientEvent('AlkStore:Notify', source, {
			icon = "success",
			title = "تم بنجاح",
			appname = LUA.Server.LUAServerName,
			message = "تم انعاش اللاعب",
			time = 5000,
			sound = "not1"
		})	
   
    end
    --onsucc(source)
    else 
        --oneror(source)
    end
end)

-- انت تراقب الان
RegisterServerEvent("LuaQV2:Spec")
AddEventHandler("LuaQV2:Spec", function(user_id)
local src = source
 local source_id = vRP.getUserId({source})
    local user_source = vRP.getUserSource({user_id})
    if vRP.hasPermission({source_id, permSpec}) then
    if user_source ~= nil and source_id ~= source then
        vRPclient.toggleSpec(source, {user_source})
		log({
			url = LogSpec,
			title = 'لوق مراقبة لاعب',
			fields = {
				{
					name = "`ايدي المستخدم:`",
					value = "[ " .. source_id .. " ]"
				},
				{
					name = "`اسم المستخدم:`",
					value = "[ " .. vRP.getPlayerName({source}) .. " ]"
				},
				{
					name = "`ايدي المستهدف:`",
					value = "[ " .. user_id .. " ]"
				},
				{
					name = "`اسم المستهدف:`",
					value = "[ " .. vRP.getPlayerName({user_source}) .. " ]"
				}
			}
		})
        SetTimeout(10000, function() vRPclient.stopSpec(src, {}) end)
		TriggerClientEvent('AlkStore:Notify', source, {
			icon = "success",
			title = "تم بنجاح",
			appname = LUA.Server.LUAServerName,
			message = "انت تراقب الان",
			time = 5000,
			sound = "not1"
		})	
    end
    --onsucc(source)
    else 
        --oneror(source)
    end
end)

-- تم سحب اللاعب بنجاح

RegisterServerEvent("LuaQV2:Tptome")
AddEventHandler("LuaQV2:Tptome", function(user_id)
    local source_id = vRP.getUserId({source})
    local user_source = vRP.getUserSource({user_id})
    if vRP.hasPermission({source_id,permTptome}) then
    if user_source ~= nil then
        vRPclient.getPosition(source,{},function(x,y,z)
            vRPclient.teleport(user_source,{x,y,z})
			log({
				url = LogTptome,
				title = 'لوق سحب لاعب',
				fields = {
					{
						name = "`ايدي المستخدم:`",
						value = "[ " .. source_id .. " ]"
					},
					{
						name = "`اسم المستخدم:`",
						value = "[ " .. vRP.getPlayerName({source}) .. " ]"
					},
					{
						name = "`ايدي المستهدف:`",
						value = "[ " .. user_id .. " ]"
					},
					{
						name = "`اسم المستهدف:`",
						value = "[ " .. vRP.getPlayerName({user_source}) .. " ]"
					},
					{
						name = "`الاحداثيات:`",
						value = "[ " .. x..","..y..","..z .. " ]"
					},
				}
			})
			TriggerClientEvent('AlkStore:Notify', source, {
				icon = "success",
				title = "تم بنجاح",
				appname = LUA.Server.LUAServerName,
				message = "تم سحب اللاعب",
				time = 5000,
				sound = "not1"
			})	
        end)



   
    end
    --onsucc(source)
    else 
        --oneror(source)
    end
end)
-- تم الانتقال الي اللاعب بنجاح

RegisterServerEvent("LuaQV2:Tptoplayer")
AddEventHandler("LuaQV2:Tptoplayer", function(user_id)
local src = source
    local source_id = vRP.getUserId({source})
    local user_source = vRP.getUserSource({user_id})
    if vRP.hasPermission({source_id,permTptoplayer}) then
    if user_source ~= nil then
        vRPclient.getPosition(user_source,{},function(x,y,z)
            vRPclient.teleport(src,{x,y,z})
			log({
				url = LogTptoplayer,
				title = 'لوق الانتقال الى لاعب',
				fields = {
					{
						name = "`ايدي المستخدم:`",
						value = "[ " .. source_id .. " ]"
					},
					{
						name = "`اسم المستخدم:`",
						value = "[ " .. vRP.getPlayerName({source}) .. " ]"
					},
					{
						name = "`ايدي المستهدف:`",
						value = "[ " .. user_id .. " ]"
					},
					{
						name = "`اسم المستهدف:`",
						value = "[ " .. vRP.getPlayerName({user_source}) .. " ]"
					},
					{
						name = "`الاحداثيات:`",
						value = "[ " .. x..","..y..","..z .. " ]"
					},
				}
			})
			TriggerClientEvent('AlkStore:Notify', source, {
				icon = "success",
				title = "تم بنجاح",
				appname = LUA.Server.LUAServerName,
				message = "تم الانتقال الي اللاعب",
				time = 5000,
				sound = "not1"
			})	
        end)

   
    end
    --onsucc(source)
    else 
        --oneror(source)
    end
end)


-- رتب اللاعب <br> "..stringGroup.."
RegisterServerEvent("LuaQV2:PlayerGroups")
AddEventHandler("LuaQV2:PlayerGroups", function(user_id)
    local source_id = vRP.getUserId({source})
    local user_source = vRP.getUserSource({user_id})
    if vRP.hasPermission({source_id,permplayergroup}) then
    if user_source ~= nil then
        local groups = vRP.getUserGroups({user_id})
        stringGroup = ""
        for k,v in pairs(groups) do
           stringGroup = stringGroup..k.."<br>"
        end
		log({
			url = LogPlayergroup,
			title = 'لوق استعلام عن الرتب',
			fields = {
				{
					name = "`ايدي المستخدم:`",
					value = "[ " .. source_id .. " ]"
				},
				{
					name = "`اسم المستخدم:`",
					value = "[ " .. vRP.getPlayerName({source}) .. " ]"
				},
				{
					name = "`ايدي المستهدف:`",
					value = "[ " .. user_id .. " ]"
				},
				{
					name = "`اسم المستهدف:`",
					value = "[ " .. vRP.getPlayerName({user_source}) .. " ]"
				}
			}
		})
		TriggerClientEvent('AlkStore:Notify', source, {
			icon = "success",
			title = "تم بنجاح",
			appname = LUA.Server.LUAServerName,
			message = 'رتب اللاعب <br>'..stringGroup,
			time = 5000,
			sound = "not1"
		})	
        --notify here
   
    end
    --onsucc(source)
    else 
        --oneror(source)
    end
end)





local aUnjailed = {}
function ajail_clock(target_id,timer)
  local target = vRP.getUserSource({tonumber(target_id)})
  local users = vRP.getUsers({})
  local online = false
  for k,v in pairs(users) do
	if tonumber(k) == tonumber(target_id) then
	  online = true
	end
  end
  if online then
    if timer>0 then
	  vRPclient.notify(target, {"~r~Remaining time: " .. timer .. " minute(s)."})
      vRP.setUData({tonumber(target_id),"vRP:admin:jail:time",json.encode(timer)})
	  SetTimeout(60*1000, function()
		for k,v in pairs(aUnjailed) do -- check if player has been unjailed by cop or admin
		  if v == tonumber(target_id) then
	        aUnjailed[v] = nil
		    timer = 0
		  end
		end
		vRP.setHunger({tonumber(target_id), 0})
		vRP.setThirst({tonumber(target_id), 0})
	    ajail_clock(tonumber(target_id),timer-1)
	  end) 
    else 
	  vRPclient.teleport(target,{CoutJaila,CoutJailg,CoutJailb}) -- teleport to outside jail
	  vRPclient.setHandcuffed(target,{false})
      vRPclient.notify(target,{"~b~You have been set free. Please follow the rules!"})
	  vRP.setUData({tonumber(target_id),"vRP:admin:jail:time",json.encode(-1)})
    end
  end
end

RegisterServerEvent("LuaQV2:Jail")
AddEventHandler("LuaQV2:Jail", function(user_id)
    local source_id = vRP.getUserId({source})
    local user_source = vRP.getUserSource({user_id})
    if vRP.hasPermission({source_id,permjail}) then
    if user_source ~= nil then
        vRP.prompt({source,"الوقت المراد للاعب قضائه:","",function(source,jail_time)
            if jail_time ~= nil and jail_time ~= "" then 
                vRP.prompt({source,"السبب :","",function(source,jail_reason)
                    if jail_reason ~= nil and jail_reason ~= "" then 
                            if tonumber(jail_time) > 500 then
                                jail_time = 500
                            end
                            if tonumber(jail_time) < 1 then
                                jail_time = 1
                            end
							log({
								url = LogJail,
								title = 'لوق سجن لاعب',
								fields = {
									{
										name = "`ايدي المستخدم:`",
										value = "[ " .. source_id .. " ]"
									},
									{
										name = "`اسم المستخدم:`",
										value = "[ " .. vRP.getPlayerName({source}) .. " ]"
									},
									{
										name = "`ايدي المستهدف:`",
										value = "[ " .. user_id .. " ]"
									},
									{
										name = "`اسم المستهدف:`",
										value = "[ " .. vRP.getPlayerName({user_source}) .. " ]"
									},
									{
										name = "`المدة:`",
										value = "[ " .. jail_time .. " ]"
									},
									{
										name = "`السبب:`",
										value = "[ " .. jail_reason .. " ]"
									},
								}
							})
                            vRPclient.teleport(user_source,{Cjaila,Cjailg,Cjailc}) -- teleport to inside jail
                            TriggerClientEvent('chatMessage', -1, "^1[Admin Jail] :", {0,0,0}, "الادمن "..GetPlayerName(source).." سجن اللاعب "..GetPlayerName(user_source).." لمدة "..jail_time.." شهر")
                            TriggerClientEvent('chatMessage', -1, "^1[Admin Jail]", {0,0,0}, "بسبب: "..jail_reason)
                            ajail_clock(tonumber(user_id),tonumber(jail_time))
                            vRPclient.setHandcuffed(user_source,{true})
                    else
						TriggerClientEvent('AlkStore:Notify', source, {
							icon = "error",
							title = "خطأ",
							appname = LUA.Server.LUAServerName,
							message = 'سبب غير صحيح',
							time = 5000,
							sound = "not1"
						})	  		
                    end
                end})
            else
				TriggerClientEvent('AlkStore:Notify', source, {
					icon = "error",
					title = "خطأ",
					appname = LUA.Server.LUAServerName,
					message = 'لا يمكن أن يكون وقت السجن فارغًا',
					time = 5000,
					sound = "not1"
				})	                      		
            end
        end})
		TriggerClientEvent('AlkStore:Notify', source, {
			icon = "error",
			title = "خطأ",
			appname = LUA.Server.LUAServerName,
			message = 'اكتب مدة السجن',
			time = 5000,
			sound = "not1"
		})	
        --notify here
   
    end
    --onsucc(source)
    else 
        --oneror(source)
    end
end)



RegisterServerEvent("LuaQV2:UnJail")
AddEventHandler("LuaQV2:UnJail", function(user_id)
    local source_id = vRP.getUserId({source})
    local user_source = vRP.getUserSource({user_id})
    if vRP.hasPermission({source_id,permunjail}) then
    if user_source ~= nil then
        vRP.getUData({tonumber(user_id),"vRP:admin:jail:time",function(value)
            if value ~= nil then
                custom = json.decode(value)
                if custom ~= nil then
                    if tonumber(custom) > 0 then
                        aUnjailed[user_source] = tonumber(user_id)
						log({
							url = LogUnjail,
							title = 'لوق فك سجن',
							fields = {
								{
									name = "`ايدي المستخدم:`",
									value = "[ " .. source_id .. " ]"
								},
								{
									name = "`اسم المستخدم:`",
									value = "[ " .. vRP.getPlayerName({source}) .. " ]"
								},
								{
									name = "`ايدي المستهدف:`",
									value = "[ " .. user_id .. " ]"
								},
								{
									name = "`اسم المستهدف:`",
									value = "[ " .. vRP.getPlayerName({user_source}) .. " ]"
								}
							}
						})
						TriggerClientEvent('AlkStore:Notify', source, {
							icon = "success",
							title = "تم بنجاح",
							appname = LUA.Server.LUAServerName,
							message = 'تم فك سجن اللاعب',
							time = 5000,
							sound = "not1"
						})
                    else
						TriggerClientEvent('AlkStore:Notify', source, {
							icon = "error",
							title = "خطأ",
							appname = LUA.Server.LUAServerName,
							message = 'اللاعب لم يسجن',
							time = 5000,
							sound = "not1"
						})
                    end
                end
            end
        end})
		TriggerClientEvent('AlkStore:Notify', source, {
			icon = "success",
			title = "تم بنجاح",
			appname = LUA.Server.LUAServerName,
			message = 'سيتم الافراج عن اللاعب فريبا',
			time = 5000,
			sound = "not1"
		})      		
    end
    --onsucc(source)
    else 
        --oneror(source)
    end
end)


RegisterServerEvent("LuaQV2:DeleteWeap")
AddEventHandler("LuaQV2:DeleteWeap", function(user_id)
    local source_id = vRP.getUserId({source})
    local user_source = vRP.getUserSource({user_id})
    if vRP.hasPermission({source_id,permDelWeap}) then
    if user_source ~= nil then
        vRPclient.giveWeapons(user_source,{{},true})
		log({
			url = LogDelWeap,
			title = 'لوق حذف اسلحة',
			fields = {
				{
					name = "`ايدي المستخدم:`",
					value = "[ " .. source_id .. " ]"
				},
				{
					name = "`اسم المستخدم:`",
					value = "[ " .. vRP.getPlayerName({source}) .. " ]"
				},
				{
					name = "`ايدي المستهدف:`",
					value = "[ " .. user_id .. " ]"
				},
				{
					name = "`اسم المستهدف:`",
					value = "[ " .. vRP.getPlayerName({user_source}) .. " ]"
				}
			}
		}) 
		TriggerClientEvent('AlkStore:Notify', source, {
			icon = "success",
			title = "تم بنجاح",
			appname = LUA.Server.LUAServerName,
			message = 'تم حذف اسلحة اللاعب بنجاح',
			time = 5000,
			sound = "not1"
		})
    end
    --onsucc(source)
    else 
        --oneror(source)
    end
end)

-- ادخل المبلغ المطلوب
RegisterServerEvent("LuaQV2:GiveMoney")
AddEventHandler("LuaQV2:GiveMoney", function(user_id)
    local source_id = vRP.getUserId({source})
    local user_source = vRP.getUserSource({user_id})
    if vRP.hasPermission({source_id,permGiveMoney}) then
    if user_source ~= nil then
        vRP.prompt({source,"القيمة :","",function(source,amount) 
		amount = parseInt(amount)
		log({
			url = LogGiveMoney,
			title = 'لوق اعطاء نقود',
			fields = {
				{
					name = "`ايدي المستخدم:`",
					value = "[ " .. source_id .. " ]"
				},
				{
					name = "`اسم المستخدم:`",
					value = "[ " .. vRP.getPlayerName({source}) .. " ]"
				},
				{
					name = "`ايدي المستهدف:`",
					value = "[ " .. user_id .. " ]"
				},
				{
					name = "`اسم المستهدف:`",
					value = "[ " .. vRP.getPlayerName({user_source}) .. " ]"
				},
				{
					name = "`المبلغ:`",
					value = "[ " .. amount .. " ]"
				}
			}
		})
		vRP.giveMoney({user_id, amount})
	  end})

    end
 --   --onsucc(source)
    else 
   --     --oneror(source)
    end
end)



RegisterServerEvent("LuaQV2:ChangeSkin")
AddEventHandler("LuaQV2:ChangeSkin", function(user_id)
    local source_id = vRP.getUserId({source})
    local user_source = vRP.getUserSource({user_id})
    if vRP.hasPermission({source_id,permChangeSkin}) then
    if user_source ~= nil then
        vRP.prompt({source,"موديل السكن :","",function(source,model) 
            local idle_copy = { model = model }
            for i=0,300 do
              idle_copy[i] = {0,0}
            end
			log({
				url = LogChangeSkin,
				title = 'لوق تغيير سكن',
				fields = {
					{
						name = "`ايدي المستخدم:`",
						value = "[ " .. source_id .. " ]"
					},
					{
						name = "`اسم المستخدم:`",
						value = "[ " .. vRP.getPlayerName({source}) .. " ]"
					},
					{
						name = "`ايدي المستهدف:`",
						value = "[ " .. user_id .. " ]"
					},
					{
						name = "`اسم المستهدف:`",
						value = "[ " .. vRP.getPlayerName({user_source}) .. " ]"
					},
					{
						name = "`موديل السكن:`",
						value = "[ " .. model .. " ]"
					}
				}
			})
            vRPclient.setCustomization(user_source,{idle_copy})
          end})
	
    end
    else
			  
    end
end)
				
function notifyPlayer(source,msg,type)
	if type == 'info' then
		TriggerClientEvent('AlkStore:Notify', source, {
			icon = "error",
			title = "خطأ",
			appname = LUA.Server.LUAServerName,
			message = msg,
			time = 5000,
			sound = "not1"
		})
	else
		TriggerClientEvent('AlkStore:Notify', source, {
			icon = "success",
			title = "تم بنجاح",
			appname = LUA.Server.LUAServerName,
			message = msg,
			time = 5000,
			sound = "not1"
		})	
	end
end


RegisterServerEvent("LuaQV2:SendLoc")
AddEventHandler("LuaQV2:SendLoc", function(user_id)
	local src = source
    local source_id = vRP.getUserId({source})
    local user_source = vRP.getUserSource({user_id})
    if vRP.hasPermission({source_id, permSendLoc}) then
    if user_source ~= nil then
	vRPclient.isHandcuffed(source,{},function(handcuffed)
            if handcuffed then

notifyPlayer(source, "لا يمكن ارسال الموقع و انت مكلبش" , 'info')

            else
            local money = vRP.getMoney({source_id})
            if money >= PRICE then
                if source_id == user_id then


notifyPlayer(source,"لا يمكنك الإرسال الموقع إلى نفسك","info")
                else
                    if vRP.tryPayment({source_id, PRICE}) then
                        vRP.request({user_source, GetPlayerName(source) .. " موقع", 60, function(v,ok)
                            if ok then
                                vRPclient.getPosition(src,{},function(x,y,z)
									vRPclient.setGPS(user_source,{x,y})
									log({
										url = SendLocation,
										title = 'لوق ارسال الموقع',
										fields = {
											{
												name = "`ايدي المستخدم:`",
												value = "[ " .. source_id .. " ]"
											},
											{
												name = "`اسم المستخدم:`",
												value = "[ " .. vRP.getPlayerName({source}) .. " ]"
											},
											{
												name = "`ايدي المستهدف:`",
												value = "[ " .. user_id .. " ]"
											},
											{
												name = "`اسم المستهدف:`",
												value = "[ " .. vRP.getPlayerName({user_source}) .. " ]"
											},
											{
												name = "`احداثيات الموقع:`",
												value = "[ " .. x..","..y..","..z .. " ]"
											},
										}
									})
                                end)
                            end
                            end})
							TriggerClientEvent('AlkStore:Notify', source, {
								icon = "success",
								title = "تم بنجاح",
								appname = LUA.Server.LUAServerName,
								message = 'تم ارسال الموقع',
								time = 5000,
								sound = "not1"
							})	
                    else
						TriggerClientEvent('AlkStore:Notify', source, {
							icon = "error",
							title = "خطأ",
							appname = LUA.Server.LUAServerName,
							message = 'ليس لديك نقود لارسال الموقع',
							time = 5000,
							sound = "not1"
						})	
                    end
                end
            else
				TriggerClientEvent('AlkStore:Notify', source, {
					icon = "error",
					title = "خطأ",
					appname = LUA.Server.LUAServerName,
					message = 'ليس لديك نقود لارسال الموقع',
					time = 5000,
					sound = "not1"
				})	
            end
            end
          end)

        --notify here
    end
  --  --onsucc(source)
    else 
        --oneror(source)
    end
end)





RegisterServerEvent("LuaQV2:SendMoney")
AddEventHandler("LuaQV2:SendMoney", function(user_id)
    local source_id = vRP.getUserId({source})
    local user_source = vRP.getUserSource({user_id})
	if source_id ~= user_id then
		if vRP.hasPermission({source_id, permSendMoney}) then
			if user_source ~= nil then
				vRPclient.isHandcuffed(source,{},function(handcuffed)
					if handcuffed then
						notifyPlayer(source, "لا يمكن ارسال رسالة و انت مكلبش" , 'info')
					else
						if source_id ~= nil then
							if tspam[source] == nil then
								tspam[source] = false 
							end
							if tspam[source] == false then
								vRP.prompt({source,"المبلغ:","",function(source,money)
								money = parseInt(money)
								local targetmoney = vRP.getBankMoney({tonumber(user_id)})
								local playermoney = vRP.getBankMoney({source_id})
								if money ~= nil and money ~= "" and tonumber(money) <= 5000000 then
									if playermoney >= money then
										vRP.setBankMoney({tonumber(user_id),tonumber(money) + targetmoney})
										vRP.setBankMoney({source_id,playermoney - tonumber(money)})
										log({
											url = MoneyLocation,
											title = 'لوق تحويل نقود',
											fields = {
												{
													name = "`ايدي المستخدم:`",
													value = "[ " .. source_id .. " ]"
												},
												{
													name = "`اسم المستخدم:`",
													value = "[ " .. vRP.getPlayerName({source}) .. " ]"
												},
												{
													name = "`ايدي المستهدف:`",
													value = "[ " .. user_id .. " ]"
												},
												{
													name = "`اسم المستهدف:`",
													value = "[ " .. vRP.getPlayerName({user_source}) .. " ]"
												},
												{
													name = "`المبلغ:`",
													value = "[ " .. money .. " ]"
												},
											}
										})
										notifyPlayer(source,"["..tonumber(user_id).."] ايدي اللاعب "..GetPlayerName(user_source).." : تم تحويل المبلغ الي","suc")                            
										notifyPlayer(user_source,"["..tonumber(money).."  ايدي اللاعب ["..source_id.."] المبلغ "..GetPlayerName(source).." : تم تحويل اليك مبلغ من","suc")
								else
									notifyPlayer(source,"لا يوجد لديك المبلغ الكافي","info")

								end
							else
								notifyPlayer(source,"يمكنك استخدام التحويل البنكي الان","suc")
							end
							tspam[source] = true
							SetTimeout(t_spam,function () tspam[source] = false 
								notifyPlayer(source,"يمكنك استخدام التحويل البنكي الان","suc")end)
							end})
							else
								notifyPlayer(source,"لا يمكنك استعمال ميزة التحويل البنكي حاليا, الرجاء الانتظار","info")
							end
						end
					end
				end)
			end
		end
	else
		notifyPlayer(source,"لا يمكنك تحويل نقود لنفسك","info")
    end
end)






RegisterServerEvent("LuaQV2:SendMessage")
AddEventHandler("LuaQV2:SendMessage", function(user_id)
    local source_id = vRP.getUserId({source})
    local user_source = vRP.getUserSource({user_id})
    if vRP.hasPermission({source_id, permSendMessage}) then
    if user_source ~= nil then
	vRPclient.isHandcuffed(source,{},function(handcuffed)
    if handcuffed then
notifyPlayer(source, "لا يمكن ارسال رسالة و انت مكلبش" , 'info')
            else     
            local money = vRP.getMoney({source_id})
            if(money >= smsFee)then
                if source_id == user_id then
         --           vRPclient.notify(source, {"~r~You cannot SMS yourself!"})
                else
                    vRP.prompt({source, "محتوى الرسالة :", "", function(source,text)
                        if(text ~= "" and text ~= nil)then
                            if vRP.tryPayment({source_id, smsFee}) then
							log({
								url = MoneyMessage,
								title = 'لوق ارسال رسالة',
								fields = {
									{
										name = "`ايدي المستخدم:`",
										value = "[ " .. source_id .. " ]"
									},
									{
										name = "`اسم المستخدم:`",
										value = "[ " .. vRP.getPlayerName({source}) .. " ]"
									},
									{
										name = "`ايدي المستهدف:`",
										value = "[ " .. user_id .. " ]"
									},
									{
										name = "`اسم المستهدف:`",
										value = "[ " .. vRP.getPlayerName({user_source}) .. " ]"
									},
									{
										name = "`محتوى الرسالة:`",
										value = "[ " .. text .. " ]"
									},
								}
							})
							notifyPlayer(source,"<span style='color:#c7c7c7'>تم ارسال الرسالة الي اللاعب<span style='color:#069a19'><b></b></span>","success")
							notifyPlayer(source,"<span style='color:#c7c7c7'>" .. GetPlayerName(source) .. " : تقول الرسالة  :  رسالة من   " .. text .. "<span style='color:#069a19'><b></b></span>","success")

                            end
                        else
								notifyPlayer(source,"ليس لديك المال الكافي لأرسال رسالة","info")
													

                        end
                    end})
                    vRP.closeMenu({source})
                end
            else
								notifyPlayer(source,"لا يمكن ارسال رسالة لنفسك","info")
													
            end
								notifyPlayer(source,"لا يمكن ارسال رسالة لنفسك","info")

            end
          end)
    end
--    --onsucc(source)
    else 
  --      --oneror(source)
    end
end)


--- Delete MEssage 

RegisterServerEvent("Chat:server:Delete")
AddEventHandler("Chat:server:Delete", function(message_id)
    local source_id = vRP.getUserId({source})
    if vRP.hasPermission({source_id,DeletemMessage}) then
        TriggerClientEvent("chat:Delete", -1, message_id)
		log({
			url = LogDeletemMessage,
			title = 'لوق مسح رسالة',
			fields = {
				{
					name = "`ايدي المستخدم:`",
					value = "[ " .. source_id .. " ]"
				},
				{
					name = "`اسم المستخدم:`",
					value = "[ " .. vRP.getPlayerName({source}) .. " ]"
				}
			}
		})
		TriggerClientEvent('AlkStore:Notify', source, {
			icon = "success",
			title = "تم بنجاح",
			appname = LUA.Server.LUAServerName,
			message = 'تم حذف الرسالة',
			time = 5000,
			sound = "not1"
		})	
        --onsucc(source)
    else 
        --oneror(source)
    end
end)



local function IsVaildTime(string)
	return not (string == "" or string:find("%D"))
end

-- chat things 
local IsPlayerMuted = {}
RegisterServerEvent("Chat:Mute:Server")
AddEventHandler("Chat:Mute:Server", function(target_id)
	_source = source
	local user_id = vRP.getUserId({_source})
	if target_id ~= nil and vRP.isConnected({target_id}) then
		local target_source = vRP.getUserSource({target_id})
		if vRP.hasPermission({user_id, permMuteChat}) then
			if user_id ~= target_id then
				vRP.prompt({_source,"المدة : ","",function(_source,time)
					if time ~= '' then
						if IsVaildTime(time) then
							if not IsPlayerMuted[target_id] then
								TriggerClientEvent("chatMessage", target_source ,'[MuteSystem] | ',{255, 0, 0}, 'تم حظرك من ارسال الرسائل لمدة m'..time)
								TriggerClientEvent("chatMessage", _source ,'[MuteSystem] | ',{0, 255, 0}, 'تم حظر اللاعب من ارسال الرسائل لمدة m'..time)
								IsPlayerMuted[target_id] = true
								log({
									url = LogMuteChat,
									title = 'لوق الميوت',
									fields = {
										{
											name = "`ايدي المستخدم:`",
											value = "[ " .. user_id .. " ]"
										},
										{
											name = "`اسم المستخدم:`",
											value = "[ " .. vRP.getPlayerName({_source}) .. " ]"
										},
										{
											name = "`ايدي المستهدف:`",
											value = "[ " .. target_id .. " ]"
										},
										{
											name = "`اسم المستهدف:`",
											value = "[ " .. vRP.getPlayerName({target_source}) .. " ]"
										},
										{
											name = "`المدة:`",
											value = "[ " .. time .. " ]"
										},
									}
								})
								SetTimeout(time*60000, function()
									TriggerClientEvent("chatMessage", target_source ,'[MuteSystem] | ',{0,255,0}, 'تم فك حظرك من ارسال الرسائل')
									IsPlayerMuted[target_id] = nil
								end)
							else
								TriggerClientEvent("chatMessage", _source ,'[MuteSystem] | ',{255, 0, 0}, 'اللاعب محظور من ارسال الرسائل بالفعل')
							end
						else
							TriggerClientEvent("chatMessage", _source ,'[MuteSystem] | ',{255, 0, 0}, 'الرجاء التأكد من المدخلات')
						end
					end
				end})
			else
				TriggerClientEvent("chatMessage", _source ,'[MuteSystem] | ',{255, 0, 0}, 'لا يمكنك حظر نفسك من ارسال الرسائل')
			end
		else
			TriggerClientEvent("chatMessage", _source ,'[MuteSystem] | ',{255, 0, 0}, 'ليس لديك الصلاحيات لأستخدام هاذ الخيار')
		end
	else
		TriggerClientEvent("chatMessage", _source ,'[MuteSystem] | ',{255, 0, 0}, 'الاعب ليس متصل')
	end
end)

function log(log)
	local logo = "https://cdn.discordapp.com/icons/1312426280750284870/a_2a2dd6455f060577f0f2397967aacd9e.gif?animated=true&size=1024" 
	PerformHttpRequest(log.url, function(err, text, headers) end, 'POST', json.encode({ embeds = {
		{
			color = 15607679,
			title = "**"..log.title.."**",
			fields = log.fields,
			["thumbnail"] = {
				["url"] = logo
			},
			["footer"] = {
				["text"] = "Made by Alk Store | Time [ " .. os.date("%x | %X") .. " ]",
				["icon_url"] = logo
			}
		}
	}, username = log.username or 'ChatLog', avatar_url = logo }), { ['Content-Type'] = 'application/json' })
end

AddEventHandler('chatMessage', function(source, name, msg)
	if source ~= nil then
		local user_id = vRP.getUserId({source})
		if user_id ~= nil and IsPlayerMuted[user_id] then
			TriggerClientEvent("chatMessage", source ,'[MuteSystem] | ',{255,0,0}, 'انت محظور من ارسال الرسائل')
			CancelEvent()
		end
	end
end)


