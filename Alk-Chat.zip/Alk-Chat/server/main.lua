-- ============================================================================
--  Alk Store | Chat  -  server
--  الاعدادات: vrp/AlkStore-Config/Scripts_Config/الشات.lua  و  الشات_sv.lua
-- ============================================================================
local Proxy = module("vrp", "lib/Proxy")
vRP = Proxy.getInterface("vRP")

local C, SV = AlkChat, AlkChatSV

-- ------------------------------------------------------------------ helpers
local channels, channelOrder = {}, {}
for _, ch in ipairs(C.Channels) do channels[ch.id] = ch; channelOrder[#channelOrder + 1] = ch.id end

local history = {}      -- [channel] = { msg, ... }
local byId = {}         -- [id] = msg
local pins = {}         -- [channel] = { id, ... }
local nextId = 0
local lastSent, lastTyping = {}, {}
local infoCache = {}    -- [src] = { at = time, info = {} }

local function utf8len(s) local ok, n = pcall(utf8.len, s); return ok and n or #s end
local function trim(s) return (tostring(s or ''):gsub('^%s+', ''):gsub('%s+$', '')) end
local function has(uid, perm) return perm == nil or perm == '' or vRP.hasPermission({ uid, perm }) end

local function playerInfo(src, fresh)
    local c = infoCache[src]
    if c and not fresh and os.time() - c.at < 30 then return c.info end
    local uid = vRP.getUserId({ src })
    if not uid then return nil end
    local info = { uid = uid, src = src, name = GetPlayerName(src) or ('#' .. uid) }
    for _, t in ipairs(SV.Titles) do
        if has(uid, t.perm) then info.title, info.color = t.label, t.color; break end
    end
    if not info.title then
        local job = vRP.getUserGroupByType({ uid, 'job' })
        info.title = (job and job ~= '') and job or SV.DefaultTitle
        info.color = SV.DefaultColor
    end
    for _, v in ipairs(SV.VIP) do
        if has(uid, v.perm) then info.vip = { label = v.label, effect = v.effect, bg = v.background ~= '' and v.background or nil, bubble = (v.bubble and v.bubble ~= '') and v.bubble or nil }; break end
    end
    info.perms = {
        everyone = has(uid, SV.Perms.Everyone), pin = has(uid, SV.Perms.Pin), delete = has(uid, SV.Perms.Delete),
        poll = has(uid, SV.Perms.Poll), admin = has(uid, SV.Perms.AdminMenu),
    }
    info.channels = {}
    for _, id in ipairs(channelOrder) do
        local ch = channels[id]
        if has(uid, ch.perm) then
            info.channels[id] = { canWrite = not ch.readonly or has(uid, ch.writePerm) }
        end
    end
    infoCache[src] = { at = os.time(), info = info }
    return info
end
AddEventHandler('playerDropped', function() infoCache[source] = nil; lastTyping[source] = nil end)
AddEventHandler('vRP:playerJoinGroup', function(uid) local s = vRP.getUserSource({ uid }); if s then infoCache[s] = nil end end)
AddEventHandler('vRP:playerLeaveGroup', function(uid) local s = vRP.getUserSource({ uid }); if s then infoCache[s] = nil end end)

-- who can see a channel
local function members(channel)
    local ch = channels[channel]
    if not ch or not ch.perm then return nil end   -- nil = everybody
    local list = {}
    for _, p in ipairs(GetPlayers()) do
        local info = playerInfo(tonumber(p))
        if info and info.channels[channel] then list[#list + 1] = tonumber(p) end
    end
    return list
end

local function sendTo(channel, event, ...)
    local list = members(channel)
    if not list then TriggerClientEvent(event, -1, ...) return end
    for _, p in ipairs(list) do TriggerClientEvent(event, p, ...) end
end

local function systemTo(src, text, color)
    TriggerClientEvent('Alk-Chat:system', src, { text = text, color = color or '#ef4444' })
end

local function store(msg)
    local h = history[msg.channel] or {}
    history[msg.channel] = h
    h[#h + 1] = msg
    byId[msg.id] = msg
    while #h > C.History do
        local old = table.remove(h, 1)
        byId[old.id] = nil
    end
end

local function snippet(msg)
    if msg.image then return '🖼️ صورة' end
    if msg.sticker then return '✨ ستيكر' end
    if msg.poll then return '📊 ' .. msg.poll.question end
    local t = msg.text or ''
    if utf8len(t) > 90 then t = t:sub(1, utf8.offset(t, 91) - 1) .. '…' end
    return t
end

local function baseMessage(info, channel)
    nextId = nextId + 1
    return {
        id = 'm' .. nextId, channel = channel, time = os.time(),
        uid = info.uid, name = info.name, title = info.title, color = info.color, vip = info.vip,
        reactions = {},
    }
end

local function log(title, fields)
    if not SV.LogChat or SV.LogChat == '' then return end
    PerformHttpRequest(SV.LogChat, function() end, 'POST', json.encode({
        username = C.ServerName .. ' | Chat',
        embeds = { { color = 3107839, title = title, fields = fields, footer = { text = C.ServerName .. ' | ' .. os.date('%x %X') } } }
    }), { ['Content-Type'] = 'application/json' })
end

-- checks shared by every kind of message
local function canPost(src, info, channel)
    local ch = info.channels[channel]
    if not ch then return false end
    if not ch.canWrite then systemTo(src, 'هذي القناة للقراءة بس'); return false end
    local now = GetGameTimer()
    if C.AntiSpam > 0 and lastSent[info.uid] and now - lastSent[info.uid] < C.AntiSpam * 1000 then
        systemTo(src, 'الرجاء عدم السبام', '#f59e0b'); return false
    end
    return true
end

-- ------------------------------------------------------------------ messages
local function handleSend(src, data)
    if type(data) ~= 'table' then return end
    local info = playerInfo(src)
    if not info then return end
    local channel = channels[data.channel] and data.channel or 'general'
    if not canPost(src, info, channel) then return end

    local text = trim(data.text)
    local sticker = type(data.sticker) == 'string' and data.sticker:match('^[%x_]+$') and #data.sticker < 40 and data.sticker or nil
    if text == '' and not sticker then return end
    if utf8len(text) > C.MaxLength then systemTo(src, ('الحد الاعلى %d حرف'):format(C.MaxLength)); return end

    -- let other scripts react / cancel (mute system, black-listed words ...)
    TriggerEvent('chatMessage', src, info.name, text)
    if WasEventCanceled() then return end

    local msg = baseMessage(info, channel)
    msg.text = text
    msg.sticker = sticker

    -- mentions
    if text:find('@everyone') or text:find('@here') then
        if info.perms.everyone then msg.everyone = true end
    end
    local mentions = {}
    for id in text:gmatch('@(%d+)') do mentions[#mentions + 1] = tonumber(id) end
    if #mentions > 0 then msg.mentions = mentions end

    -- reply
    if type(data.replyTo) == 'string' and byId[data.replyTo] then
        local r = byId[data.replyTo]
        msg.reply = { id = r.id, name = r.name, color = r.color, text = snippet(r) }
    end

    lastSent[info.uid] = GetGameTimer()
    store(msg)
    sendTo(channel, 'Alk-Chat:message', msg)
    log('رسالة في #' .. channel, { { name = 'اللاعب', value = ('[%d] %s'):format(info.uid, info.name) }, { name = 'الرسالة', value = text ~= '' and text or ('sticker ' .. tostring(sticker)) } })
end
RegisterNetEvent('Alk-Chat:send', function(data) handleSend(source, data) end)

-- old resources that still use the standard chat pipeline
RegisterNetEvent('_chat:messageEntered', function(author, color, message)
    handleSend(source, { channel = 'general', text = message })
end)

-- pasted images (sent as a latent event because they are big)
RegisterNetEvent('Alk-Chat:image', function(data)
    local src = source
    if not C.Images.Enabled or type(data) ~= 'table' or type(data.image) ~= 'string' then return end
    local info = playerInfo(src)
    if not info then return end
    local channel = channels[data.channel] and data.channel or 'general'
    if not canPost(src, info, channel) then return end
    if not data.image:match('^data:image/[%a]+;base64,[%w%+/=]+$') then return end
    if #data.image > C.Images.MaxKB * 1024 * 1.4 then systemTo(src, 'الصورة كبيرة'); return end
    local caption = trim(data.caption)
    if utf8len(caption) > C.MaxLength then caption = '' end

    local msg = baseMessage(info, channel)
    msg.image = data.image
    msg.text = caption
    lastSent[info.uid] = GetGameTimer()
    store(msg)
    local list = members(channel)
    if not list then
        TriggerLatentClientEvent('Alk-Chat:message', -1, 150000, msg)
    else
        for _, p in ipairs(list) do TriggerLatentClientEvent('Alk-Chat:message', p, 150000, msg) end
    end
end)

-- typing indicator
RegisterNetEvent('Alk-Chat:typing', function(channel)
    local src = source
    if not channels[channel] then return end
    local now = GetGameTimer()
    if lastTyping[src] and now - lastTyping[src] < 2000 then return end
    lastTyping[src] = now
    local info = playerInfo(src)
    if not info or not info.channels[channel] then return end
    local list = members(channel)
    if not list then
        list = {}
        for _, p in ipairs(GetPlayers()) do list[#list + 1] = tonumber(p) end
    end
    for _, p in ipairs(list) do
        if p ~= src then TriggerClientEvent('Alk-Chat:typing', p, channel, info.uid, info.name) end
    end
end)

-- reactions
RegisterNetEvent('Alk-Chat:react', function(id, emoji)
    local src = source
    local msg = byId[id]
    if not msg or type(emoji) ~= 'string' or #emoji == 0 or #emoji > 32 then return end
    local info = playerInfo(src)
    if not info or not info.channels[msg.channel] then return end
    local list = msg.reactions[emoji] or {}
    local found
    for i, u in ipairs(list) do if u == info.uid then found = i break end end
    if found then table.remove(list, found) else
        local kinds = 0
        for _ in pairs(msg.reactions) do kinds = kinds + 1 end
        if not msg.reactions[emoji] and kinds >= 12 then return end
        list[#list + 1] = info.uid
    end
    msg.reactions[emoji] = #list > 0 and list or nil
    sendTo(msg.channel, 'Alk-Chat:update', { id = id, reactions = msg.reactions })
end)

-- pins
local function pinList(channel)
    local out = {}
    for _, id in ipairs(pins[channel] or {}) do
        local m = byId[id]
        if m then out[#out + 1] = { id = m.id, name = m.name, color = m.color, text = snippet(m) } end
    end
    return out
end
RegisterNetEvent('Alk-Chat:pin', function(id)
    local src = source
    local msg = byId[id]
    local info = playerInfo(src)
    if not msg or not info or not info.perms.pin then return end
    local list = pins[msg.channel] or {}
    pins[msg.channel] = list
    local at
    for i, v in ipairs(list) do if v == id then at = i end end
    if at then table.remove(list, at); msg.pinned = nil else list[#list + 1] = id; msg.pinned = true end
    sendTo(msg.channel, 'Alk-Chat:update', { id = id, pinned = msg.pinned or false })
    sendTo(msg.channel, 'Alk-Chat:pins', msg.channel, pinList(msg.channel))
end)

-- delete / edit (own message for a few minutes, or staff)
local function ownRecent(info, msg) return msg.uid == info.uid and os.time() - msg.time <= C.EditMinutes * 60 end
RegisterNetEvent('Alk-Chat:delete', function(id)
    local src = source
    local msg = byId[id]
    local info = playerInfo(src)
    if not msg or not info then return end
    if not (info.perms.delete or ownRecent(info, msg)) then return end
    byId[id] = nil
    local h = history[msg.channel] or {}
    for i, m in ipairs(h) do if m.id == id then table.remove(h, i) break end end
    sendTo(msg.channel, 'Alk-Chat:remove', id)
    if msg.pinned then
        for i, v in ipairs(pins[msg.channel] or {}) do if v == id then table.remove(pins[msg.channel], i) break end end
        sendTo(msg.channel, 'Alk-Chat:pins', msg.channel, pinList(msg.channel))
    end
end)
RegisterNetEvent('Alk-Chat:edit', function(id, text)
    local src = source
    local msg = byId[id]
    local info = playerInfo(src)
    text = trim(text)
    if not msg or not info or not ownRecent(info, msg) or msg.poll or text == '' or utf8len(text) > C.MaxLength then return end
    msg.text, msg.edited = text, true
    sendTo(msg.channel, 'Alk-Chat:update', { id = id, text = text, edited = true })
end)

-- polls
RegisterNetEvent('Alk-Chat:poll', function(data)
    local src = source
    local info = playerInfo(src)
    if not info or type(data) ~= 'table' then return end
    local channel = channels[data.channel] and data.channel or 'general'
    if not info.perms.poll then systemTo(src, 'ما عندك صلاحية تسوي تصويت'); return end
    if not canPost(src, info, channel) then return end
    local question = trim(data.question)
    if question == '' or utf8len(question) > 120 or type(data.options) ~= 'table' then return end
    local options = {}
    for _, o in ipairs(data.options) do
        o = trim(o)
        if o ~= '' and utf8len(o) <= 60 and #options < 6 then options[#options + 1] = { text = o, votes = 0 } end
    end
    if #options < 2 then return end
    local msg = baseMessage(info, channel)
    msg.poll = { question = question, options = options, voters = {} }
    lastSent[info.uid] = GetGameTimer()
    store(msg)
    sendTo(channel, 'Alk-Chat:message', msg)
end)
RegisterNetEvent('Alk-Chat:vote', function(id, option)
    local src = source
    local msg = byId[id]
    local info = playerInfo(src)
    option = tonumber(option)
    if not msg or not msg.poll or not info or not info.channels[msg.channel] or not option or not msg.poll.options[option] then return end
    local key = tostring(info.uid)
    local prev = msg.poll.voters[key]
    if prev == option then return end
    if prev then msg.poll.options[prev].votes = msg.poll.options[prev].votes - 1 end
    msg.poll.options[option].votes = msg.poll.options[option].votes + 1
    msg.poll.voters[key] = option
    sendTo(msg.channel, 'Alk-Chat:update', { id = id, poll = msg.poll })
end)

-- ------------------------------------------------------------------ init / sync
local function historyFor(info)
    local out = {}
    for channel in pairs(info.channels) do
        local list = {}
        for _, m in ipairs(history[channel] or {}) do
            if m.image then   -- images are too heavy to resend; keep a placeholder
                local copy = {}
                for k, v in pairs(m) do copy[k] = v end
                copy.image, copy.imageGone = nil, true
                list[#list + 1] = copy
            else
                list[#list + 1] = m
            end
        end
        out[channel] = list
    end
    return out
end

RegisterNetEvent('Alk-Chat:ready', function()
    local src = source
    local info = playerInfo(src, true)
    if not info then return end   -- no user_id yet: vRP:playerSpawn below asks again
    local visible, pinData = {}, {}
    for _, id in ipairs(channelOrder) do
        local ch = channels[id]
        if info.channels[id] then
            visible[#visible + 1] = { id = id, label = ch.label, icon = ch.icon, canWrite = info.channels[id].canWrite }
            pinData[id] = pinList(id)
        end
    end
    TriggerClientEvent('Alk-Chat:init', src, {
        me = { uid = info.uid, name = info.name },
        perms = info.perms,
        channels = visible,
        history = historyFor(info),
        pins = pinData,
    })
end)
-- vRP spawned the player: (re)send everything now that we know his user_id
AddEventHandler('vRP:playerSpawn', function(uid, src, first)
    if first then infoCache[src] = nil; TriggerClientEvent('Alk-Chat:requestReady', src) end
end)

-- ------------------------------------------------------------------ standard chat compatibility
RegisterServerEvent('chat:init')
RegisterServerEvent('chat:addTemplate')
RegisterServerEvent('chat:addMessage')
RegisterServerEvent('chat:addSuggestion')
RegisterServerEvent('chat:removeSuggestion')
RegisterServerEvent('chat:clear')
RegisterServerEvent('__cfx_internal:commandFallback')

AddEventHandler('__cfx_internal:commandFallback', function(command)
    local name = GetPlayerName(source)
    TriggerEvent('chatMessage', source, name, '/' .. command)
    if not WasEventCanceled() then
        systemTo(source, 'امر غير معروف: /' .. tostring(command):match('^(%S+)'), '#f59e0b')
    end
    CancelEvent()
end)

local function refreshCommands(player)
    if not GetRegisteredCommands then return end
    local suggestions = {}
    for _, command in ipairs(GetRegisteredCommands()) do
        if IsPlayerAceAllowed(player, ('command.%s'):format(command.name)) then
            suggestions[#suggestions + 1] = { name = '/' .. command.name, help = '' }
        end
    end
    TriggerClientEvent('chat:addSuggestions', player, suggestions)
end
AddEventHandler('chat:init', function() refreshCommands(source) end)
AddEventHandler('onServerResourceStart', function()
    Wait(500)
    for _, player in ipairs(GetPlayers()) do refreshCommands(player) end
end)

-- admin menu "delete all messages of a player" (server/admin.lua) also clears the stored history
AddEventHandler('LuaQV22:Server:DeleteMessage', function(user_id)
    local info = playerInfo(source)
    user_id = tonumber(user_id)
    if not info or not info.perms.delete or not user_id then return end
    for _, list in pairs(history) do
        for i = #list, 1, -1 do
            if list[i].uid == user_id then byId[list[i].id] = nil; table.remove(list, i) end
        end
    end
end)

-- other scripts: exports['Alk-Chat']:SendSystem(source, 'text', '#hex')
exports('SendSystem', function(target, text, color) systemTo(target, text, color) end)
