/* ============================================================================
   Alk Store | Chat  -  NUI
   ============================================================================ */
(() => {
'use strict';

const RES = window.GetParentResourceName ? window.GetParentResourceName() : 'Alk-Chat';
const post = (name, data = {}) => fetch(`https://${RES}/${name}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json; charset=UTF-8' }, body: JSON.stringify(data),
}).catch(() => {});

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };

// ------------------------------------------------------------------ state
const S = {
    cfg: { fade: 12, maxLength: 250, quick: ['👍', '❤️', '😂', '😮', '😢', '🔥'], stickers: [], images: { Enabled: true, MaxKB: 350, LinkPreview: true }, editMinutes: 5, sound: true, theme: 'classic', logo: '', serverName: 'Alk Store' },
    me: { uid: -1, name: '' }, perms: {},
    channels: [{ id: 'general', label: 'العام', icon: 'fa-solid fa-hashtag', canWrite: true }],
    current: 'general',
    lists: {},          // channel -> [msg]
    byId: {},
    pins: {},
    unread: {},         // channel -> { n, at }
    typing: {},         // channel -> uid -> { name, until }
    templates: {},
    sugs: [],
    open: false,
    reply: null, editing: null, image: null,
    sent: [], sentIdx: -1,
    sugIdx: 0,
    search: '',
};
let sysId = 0;

// ------------------------------------------------------------------ helpers
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const timeStr = (t) => { const d = t ? new Date(t * 1000) : new Date(); return d.toTimeString().slice(0, 5); };
const rgb = (c) => Array.isArray(c) ? `rgb(${c[0] | 0},${c[1] | 0},${c[2] | 0})` : (typeof c === 'string' && /^#[0-9a-f]{3,8}$/i.test(c) ? c : null);
const stickerUrl = (code) => `https://fonts.gstatic.com/s/e/notoemoji/latest/${code}/512.gif`;
const chan = (id) => S.channels.find((c) => c.id === id);
const list = (id) => (S.lists[id] = S.lists[id] || []);
const emojiOnly = (s) => /^(\p{Extended_Pictographic}|\p{Emoji_Component}|‍|️|\s){1,24}$/u.test(s) && !/[0-9#*]/.test(s.replace(/\s/g, ''));

const GTA = { 0: '#fff', 1: '#ef4444', 2: '#22c55e', 3: '#facc15', 4: '#3b82f6', 5: '#22d3ee', 6: '#a855f7', 7: '#fff', 8: '#b91c1c', 9: '#9ca3af' };
const gtaColors = (html) => {   // ^1 colours and ~r~ codes from legacy scripts (html is already escaped)
    let open = 0;
    html = html.replace(/~[a-zA-Z]~/g, '').replace(/\^(\d)/g, (_, n) => { const r = (open ? '</span>' : '') + `<span style="color:${GTA[n]}">`; open = 1; return r; });
    return html + (open ? '</span>' : '');
};

// markdown-lite. ALWAYS escapes first, only then adds our own tags.
function fmt(text) {
    const tokens = [];
    const keep = (h) => `\u0000${tokens.push(h) - 1}\u0000`;
    let s = esc(text);
    s = s.replace(/```([\s\S]+?)```/g, (_, c) => keep(`<pre><code>${c.replace(/^\n/, '')}</code></pre>`));
    s = s.replace(/`([^`\n]+)`/g, (_, c) => keep(`<code>${c}</code>`));
    s = s.replace(/(https?:\/\/[^\s<]+[^\s<.,;:!?)\]'"])/g, (u) => keep(`<a class="link" data-url="${u}">${u}</a>`));
    s = s.replace(/\*\*([^*\n]+)\*\*/g, '<b>$1</b>')
         .replace(/__([^_\n]+)__/g, '<u>$1</u>')
         .replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<i>$2</i>')
         .replace(/~~([^~\n]+)~~/g, '<s>$1</s>')
         .replace(/\|\|([^|\n]+)\|\|/g, '<span class="spoiler">$1</span>');
    s = s.replace(/@(everyone|here)\b/g, '<span class="mention all">@$1</span>');
    s = s.replace(/@(\d{1,7})\b/g, (_, id) => `<span class="mention${+id === S.me.uid ? ' me' : ''}">@${id}</span>`);
    return s.replace(/\u0000(\d+)\u0000/g, (_, i) => tokens[i]);
}

// ------------------------------------------------------------------ sounds (no files needed)
let actx;
function beep(kind) {
    if (!S.cfg.sound) return;
    try {
        actx = actx || new (window.AudioContext || window.webkitAudioContext)();
        const notes = kind === 'everyone' ? [[880, 0], [660, .14], [880, .28], [990, .42]] : kind === 'mention' ? [[740, 0], [988, .1]] : [[600, 0]];
        notes.forEach(([f, t]) => {
            const o = actx.createOscillator(), g = actx.createGain();
            o.type = kind === 'everyone' ? 'square' : 'sine'; o.frequency.value = f;
            g.gain.setValueAtTime(.0001, actx.currentTime + t);
            g.gain.exponentialRampToValueAtTime(kind === 'everyone' ? .12 : .08, actx.currentTime + t + .02);
            g.gain.exponentialRampToValueAtTime(.0001, actx.currentTime + t + .13);
            o.connect(g).connect(actx.destination); o.start(actx.currentTime + t); o.stop(actx.currentTime + t + .15);
        });
    } catch (e) {}
}

// ------------------------------------------------------------------ rendering
const box = $('#messages');

function canEdit(m) { return m.uid === S.me.uid && Date.now() / 1000 - m.time <= S.cfg.editMinutes * 60; }

function actionsHtml(m) {
    if (m.system) return '';
    const c = chan(m.channel);
    let h = '';
    if (c && c.canWrite) h += '<button data-act="reply" title="رد"><i class="fa-solid fa-reply"></i></button>';
    h += '<button data-act="react" title="رياكشن"><i class="fa-regular fa-face-smile"></i></button>';
    if (m.text) h += '<button data-act="copy" title="نسخ"><i class="fa-regular fa-copy"></i></button>';
    if (S.perms.pin) h += `<button data-act="pin" title="${m.pinned ? 'الغاء التثبيت' : 'تثبيت'}"><i class="fa-solid fa-thumbtack"></i></button>`;
    if (canEdit(m) && m.text && !m.poll && !m.image && !m.sticker) h += '<button data-act="edit" title="تعديل"><i class="fa-solid fa-pen"></i></button>';
    if (S.perms.delete || canEdit(m)) h += '<button data-act="delete" class="danger" title="حذف"><i class="fa-solid fa-trash"></i></button>';
    return `<div class="msg-actions">${h}</div>`;
}

function reactionsHtml(m) {
    const r = m.reactions || {};
    const keys = Object.keys(r).filter((k) => r[k] && r[k].length);
    if (!keys.length) return '';
    return '<div class="reactions">' + keys.map((k) =>
        `<button class="react${r[k].includes(S.me.uid) ? ' mine' : ''}" data-emoji="${esc(k)}">${esc(k)}<b>${r[k].length}</b></button>`).join('') + '</div>';
}

function pollHtml(m) {
    const p = m.poll;
    const total = p.options.reduce((a, o) => a + o.votes, 0);
    const mine = p.voters ? p.voters[String(S.me.uid)] : undefined;
    return `<div class="poll"><div class="poll-q"><i class="fa-solid fa-square-poll-vertical"></i>${esc(p.question)}</div>` +
        p.options.map((o, i) => {
            const pct = total ? Math.round(o.votes * 100 / total) : 0;
            return `<button class="poll-opt${mine === i + 1 ? ' voted' : ''}" data-opt="${i + 1}"><div class="fill" style="width:${pct}%"></div><span>${esc(o.text)}</span><span>${pct}% · ${o.votes}</span></button>`;
        }).join('') + `<div class="poll-total">${total} صوت</div></div>`;
}

function replyHtml(m) {
    if (!m.reply) return '';
    return `<div class="reply-ref" data-jump="${esc(m.reply.id)}" style="--c:${esc(m.reply.color || '')}"><i class="fa-solid fa-reply"></i><b>${esc(m.reply.name)}</b><span>${esc(m.reply.text)}</span></div>`;
}

function textHtml(m) {
    if (m.system) {
        const author = m.author ? `<span class="sys-author" style="--c:${m.color || 'var(--accent-2)'}">${gtaColors(esc(m.author))}</span>` : '';
        const text = m.html != null ? m.html : gtaColors(fmt(m.text || ''));
        return `<div class="msg-body">${author}${text}</div>`;
    }
    return m.text ? `<div class="msg-body${emojiOnly(m.text) && !m.image ? ' jumbo' : ''}">${fmt(m.text)}</div>` : '';
}

// everything that sits under the bubble (stickers, images, polls)
function extrasHtml(m) {
    if (m.system) return '';
    let h = '';
    if (m.sticker) h += `<img class="sticker" src="${stickerUrl(esc(m.sticker))}" alt="">`;
    if (m.image) h += `<img class="msg-image" src="${m.image.startsWith('data:image/') ? m.image : ''}" alt="">`;
    if (m.imageGone) h += '<div class="image-gone"><i class="fa-regular fa-image"></i> صورة</div>';
    if (m.poll) h += pollHtml(m);
    if (S.cfg.images.LinkPreview && m.text) {
        const u = (m.text.match(/https?:\/\/[^\s]+\.(?:png|jpe?g|gif|webp)(?:\?[^\s]*)?/i) || [])[0];
        if (u) h += `<img class="msg-image" src="${esc(u)}" alt="" onerror="this.remove()">`;
    }
    return h;
}

function headHtml(m) {
    if (m.system) return '';
    const fx = m.vip && m.vip.effect ? ` fx-${esc(m.vip.effect)}` : '';
    // .tag = "1 | TITLE || Name :" used by the compact (easy) theme, the rest by the other themes
    const tag = `<bdi>${m.uid}</bdi> | ${m.title ? `<bdi>${esc(m.title)}</bdi> || ` : ''}<bdi>${esc(m.name)}</bdi>`;
    return `<div class="msg-head">` +
        `<span class="tag${fx}" data-uid="${m.uid}" style="--c:${esc(m.color || '#2dd4bf')}">${tag}</span><span class="colon">:</span>` +
        `<span class="title" style="--c:${esc(m.color || '#2f6bff')}">${esc(m.title || '')}</span>` +
        (m.vip ? `<i class="fa-solid fa-crown vip-crown" title="${esc(m.vip.label)}"></i>` : '') +
        `<span class="name${fx}" data-uid="${m.uid}" style="--c:${esc(m.color || '')}">${esc(m.name)}</span>` +
        `<span class="uid">#${m.uid}</span>` +
        (m.pinned ? '<i class="fa-solid fa-thumbtack pin-flag"></i>' : '') +
        `<span class="time">${timeStr(m.time)}</span>${m.edited ? '<span class="edited">(معدلة)</span>' : ''}</div>`;
}

function grouped(prev, m) {
    return prev && !prev.system && !m.system && prev.uid === m.uid && !m.reply && !prev.poll && !m.poll && m.time - prev.time < 180;
}

function render(m, prev) {
    const e = el('div', 'msg');
    e.dataset.id = m.id;
    if (m.system) e.classList.add('system');
    if (grouped(prev, m)) e.classList.add('grouped');
    if (m.mentions && m.mentions.includes(S.me.uid)) e.classList.add('mentioned');
    if (m.everyone) e.classList.add('everyone');
    if (m.pinned) e.classList.add('pinned');
    if (m.vip && m.vip.bg) { e.classList.add('vip-bg'); e.style.setProperty('--vipbg', `url("${encodeURI(m.vip.bg)}")`); }
    if (m.vip && m.vip.bubble && rgb(m.vip.bubble)) { e.classList.add('vip-color'); e.style.setProperty('--vipc', rgb(m.vip.bubble)); }
    if (m.system && m.color) e.style.setProperty('--sys', 'var(--text)');
    if (m.color) e.style.setProperty('--av', rgb(m.color) || m.color);
    const pin = m.pinned ? '<i class="fa-solid fa-thumbtack pin-end"></i>' : '';
    e.innerHTML = replyHtml(m) + `<div class="bubble">${headHtml(m)}${textHtml(m)}${pin}</div>` + extrasHtml(m) + reactionsHtml(m) + actionsHtml(m);
    e._t = Date.now();
    m.el = e;
    return e;
}

function refresh(m) {
    if (!m.el) return;
    const idx = list(m.channel).indexOf(m);
    const n = render(m, list(m.channel)[idx - 1]);
    n._t = m.el._t;
    if (m.el.classList.contains('faded')) n.classList.add('faded');
    m.el.replaceWith(n);
    m.el = n;
    applySearch();
}

const nearBottom = () => box.scrollHeight - box.scrollTop - box.clientHeight < 80;
function toBottom(force) { if (force || nearBottom() || !S.open) { box.scrollTop = box.scrollHeight; $('#jump').classList.add('hidden'); } else $('#jump').classList.remove('hidden'); }

function renderChannel() {
    box.innerHTML = '';
    let prev = null;
    for (const m of list(S.current)) { const e = render(m, prev); if (!S.open) e.classList.add('faded'); box.appendChild(e); prev = m; }
    const c = chan(S.current);
    $('#channel-title').textContent = c ? `# ${c.label}` : '';
    const input = $('#input');
    input.disabled = c && !c.canWrite;
    input.placeholder = c && !c.canWrite ? 'هذي القناة للقراءة فقط' : 'اكتب رسالتك ...';
    renderPins(); renderTyping(); applySearch();
    box.style.scrollBehavior = 'auto'; toBottom(true); box.style.scrollBehavior = '';
}

function renderChannels() {
    const nav = $('#channels');
    nav.innerHTML = '';
    for (const c of S.channels) {
        const u = S.unread[c.id];
        const b = el('button', `ch${c.id === S.current ? ' active' : ''}${c.canWrite ? '' : ' readonly'}`,
            `<i class="${esc(c.icon || 'fa-solid fa-hashtag')}"></i>${esc(c.label)}` + (u && u.n ? `<span class="badge${u.at ? ' at' : ''}">${u.at ? '@' : (u.n > 99 ? '99+' : u.n)}</span>` : ''));
        b.onclick = () => switchChannel(c.id);
        nav.appendChild(b);
    }
    // unread badge on the # button
    let total = 0, anyAt = false;
    for (const c of S.channels) { const u = S.unread[c.id]; if (u && u.n) { total += u.n; anyAt = anyAt || u.at; } }
    const dot = $('#ch-dot');
    dot.textContent = anyAt ? '@' : (total > 9 ? '9+' : total);
    dot.classList.toggle('hidden', !total);
    dot.classList.toggle('at', anyAt);
}

function switchChannel(id) {
    if (!chan(id)) return;
    S.current = id;
    S.unread[id] = { n: 0, at: false };
    cancelReply();
    renderChannels(); renderChannel();
    closePopovers();
}

function addMessage(m, { silent } = {}) {
    if (S.byId[m.id]) return;
    const l = list(m.channel);
    const prev = l[l.length - 1];
    l.push(m);
    S.byId[m.id] = m;
    while (l.length > 120) { const old = l.shift(); delete S.byId[old.id]; if (old.el) old.el.remove(); }

    if (m.channel === S.current) {
        const e = render(m, prev);
        if (!silent) e.classList.add('new');
        box.appendChild(e);
        applySearch();
        toBottom(m.uid === S.me.uid);
    } else if (!silent) {
        const u = S.unread[m.channel] = S.unread[m.channel] || { n: 0, at: false };
        u.n++;
        if ((m.mentions && m.mentions.includes(S.me.uid)) || m.everyone) u.at = true;
        renderChannels();
    }
    if (silent || m.uid === S.me.uid) return;
    if (m.everyone) { everyoneAlert(m); beep('everyone'); }
    else if (m.mentions && m.mentions.includes(S.me.uid)) beep('mention');
    if (!m.system && S.typing[m.channel]) { delete S.typing[m.channel][m.uid]; renderTyping(); }
}

function system(text, color, author, html, channel) {
    addMessage({ id: 's' + (++sysId), system: true, channel: channel || S.current, time: Date.now() / 1000, text, color, author, html });
}

// fade old messages while the chat is closed
setInterval(() => {
    if (S.open) return;
    const limit = Date.now() - S.cfg.fade * 1000;
    $$('.msg', box).forEach((e) => { if (e._t < limit) e.classList.add('faded'); });
}, 500);

// ------------------------------------------------------------------ pins / typing / search
function renderPins() {
    const p = S.pins[S.current] || [];
    const bar = $('#pinned-bar');
    bar.classList.toggle('hidden', !p.length);
    if (p.length) {
        const last = p[p.length - 1];
        $('#pinned-text').innerHTML = `<b style="color:${esc(last.color || '')}">${esc(last.name)}:</b> ${esc(last.text)}`;
        $('#pinned-count').textContent = p.length > 1 ? `${p.length} مثبتة` : '';
    }
    $('#pins-list').innerHTML = p.length ? p.slice().reverse().map((x) =>
        `<div class="pin-item" data-jump="${esc(x.id)}" style="--c:${esc(x.color || '')}"><b>${esc(x.name)}</b>${esc(x.text)}</div>`).join('') : '<div class="empty">ما في رسائل مثبتة</div>';
}

function renderTyping() {
    const t = S.typing[S.current] || {};
    const now = Date.now();
    const names = Object.values(t).filter((x) => x.until > now).map((x) => x.name);
    const box2 = $('#typing');
    box2.classList.toggle('on', names.length > 0);
    $('#typing-text').textContent = !names.length ? '' : names.length === 1 ? `${names[0]} يكتب ...` :
        names.length === 2 ? `${names[0]} و ${names[1]} يكتبون ...` : 'عدة اشخاص يكتبون ...';
}
setInterval(renderTyping, 1000);

// wrap every match inside the message text with <mark class="hl">
function highlight(e, q) {
    $$('mark.hl', e).forEach((x) => x.replaceWith(document.createTextNode(x.textContent)));
    e.normalize();
    if (!q) return 0;
    let n = 0;
    $$('.msg-body', e).forEach((body) => {
        const walker = document.createTreeWalker(body, NodeFilter.SHOW_TEXT);
        const nodes = [];
        while (walker.nextNode()) nodes.push(walker.currentNode);
        for (const node of nodes) {
            const low = node.data.toLowerCase();
            let i = low.indexOf(q);
            if (i < 0) continue;
            const frag = document.createDocumentFragment();
            let last = 0;
            while (i >= 0) {
                frag.appendChild(document.createTextNode(node.data.slice(last, i)));
                const mk = document.createElement('mark'); mk.className = 'hl'; mk.textContent = node.data.slice(i, i + q.length);
                frag.appendChild(mk); n++;
                last = i + q.length; i = low.indexOf(q, last);
            }
            frag.appendChild(document.createTextNode(node.data.slice(last)));
            node.replaceWith(frag);
        }
    });
    return n;
}

function applySearch() {
    const q = S.search.trim().toLowerCase();
    let n = 0;
    $$('.msg', box).forEach((e) => {
        const m = S.byId[e.dataset.id];
        const hay = m ? `${m.name || ''} ${m.author || ''} ${m.text || ''}`.toLowerCase() : '';
        const hit = !q || hay.includes(q);
        e.classList.toggle('search-miss', !hit);
        const marks = highlight(e, q);
        if (q) n += marks || (hit ? 1 : 0);
    });
    $('#search-count').textContent = q ? n : '';
}

function jumpTo(id) {
    const m = S.byId[id];
    if (!m) return;
    if (m.channel !== S.current) switchChannel(m.channel);
    if (S.search) { S.search = ''; $('#search').value = ''; applySearch(); }
    m.el.scrollIntoView({ block: 'center' });
    m.el.classList.remove('flash'); void m.el.offsetWidth; m.el.classList.add('flash');
}

// ------------------------------------------------------------------ alerts
let alertTimer;
function everyoneAlert(m) {
    $('#ea-name').textContent = `📢 ${m.name} منشن الجميع`;
    $('#ea-text').textContent = (m.text || '').replace(/@everyone|@here/g, '').trim() || 'تنبيه مهم';
    const a = $('#everyone-alert');
    a.classList.add('hidden'); void a.offsetWidth; a.classList.remove('hidden');
    clearTimeout(alertTimer);
    alertTimer = setTimeout(() => a.classList.add('hidden'), 7000);
}

// ------------------------------------------------------------------ open / close
const chatEl = $('#chat');
function openChat() {
    S.open = true;
    chatEl.classList.remove('closed');
    $$('.msg', box).forEach((e) => e.classList.remove('faded'));
    S.unread[S.current] = { n: 0, at: false };
    renderChannels();
    toBottom(true);
    setTimeout(() => $('#input').focus(), 30);
}
function closeChat(notify = true) {
    S.open = false;
    chatEl.classList.add('closed');
    closePopovers();
    hideFloat();
    $('#poll-modal').classList.add('hidden');
    $('#suggestions').classList.add('hidden');
    fmtBar.classList.add('hidden');
    const limit = Date.now() - S.cfg.fade * 1000;
    $$('.msg', box).forEach((e) => { if (e._t < limit) e.classList.add('faded'); });
    toBottom(true);
    if (notify) post('close');
}

// ------------------------------------------------------------------ composer
const input = $('#input');
function autoSize() { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 110) + 'px'; }
function updateCounter() {
    const n = [...input.value].length;
    const c = $('#counter');
    c.textContent = n > S.cfg.maxLength * 0.7 ? `${n}/${S.cfg.maxLength}` : '';
    c.classList.toggle('warn', n > S.cfg.maxLength * 0.9);
}

function setReply(m) {
    S.editing = null;
    S.reply = m;
    $('#reply-bar').classList.remove('hidden');
    $('#reply-text').innerHTML = `رد على <b>${esc(m.name)}</b>: ${esc(m.text || (m.sticker ? 'ستيكر' : m.image ? 'صورة' : ''))}`;
    input.focus();
}
function setEdit(m) {
    S.reply = null;
    S.editing = m;
    $('#reply-bar').classList.remove('hidden');
    $('#reply-text').innerHTML = '<b>تعديل الرسالة</b> - اضغط Enter للحفظ';
    input.value = m.text; autoSize(); input.focus();
}
function cancelReply() {
    if (S.editing) { input.value = ''; autoSize(); }
    S.reply = null; S.editing = null;
    $('#reply-bar').classList.add('hidden');
}
$('#reply-cancel').onclick = cancelReply;

let typingAt = 0;
input.addEventListener('input', () => {
    autoSize(); updateCounter(); renderSuggestions();
    const v = input.value.trim();
    if (v && v[0] !== '/' && Date.now() - typingAt > 2500) { typingAt = Date.now(); post('typing', { channel: S.current }); }
});

function send() {
    const text = input.value.trim();
    if (S.image) {
        post('image', { channel: S.current, image: S.image, caption: text });
        clearImage();
    } else if (S.editing) {
        if (text) post('edit', { id: S.editing.id, text });
    } else if (text) {
        const cmd = text[0] === '/';
        post('send', { channel: S.current, text, replyTo: S.reply ? S.reply.id : null, close: cmd });
        S.sent.unshift(text); S.sent = S.sent.slice(0, 30);
        if (cmd || S.cfg.closeOnSend) { input.value = ''; autoSize(); updateCounter(); cancelReply(); $('#suggestions').classList.add('hidden'); S.sentIdx = -1; closeChat(!cmd); return; }
    } else return;
    input.value = ''; autoSize(); updateCounter(); cancelReply();
    $('#suggestions').classList.add('hidden');
    S.sentIdx = -1;
}
$('#btn-send').onclick = send;

input.addEventListener('keydown', (e) => {
    const sugOpen = !$('#suggestions').classList.contains('hidden');
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        const typed = input.value.trim();
        if (sugOpen && typed.split(' ').length === 1 && !S.sugs.some((s) => s.name === typed)) { pickSuggestion(); return; }
        send();
    } else if (e.key === 'Tab' && sugOpen) { e.preventDefault(); pickSuggestion(); }
    else if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
        const up = e.key === 'ArrowUp';
        if (sugOpen) { e.preventDefault(); moveSuggestion(up ? -1 : 1); return; }
        if (input.value && S.sentIdx === -1) return;
        e.preventDefault();
        S.sentIdx = Math.max(-1, Math.min(S.sent.length - 1, S.sentIdx + (up ? 1 : -1)));
        input.value = S.sentIdx >= 0 ? S.sent[S.sentIdx] : ''; autoSize();
    }
});

// suggestions (/commands)
function currentSugs() {
    const v = input.value;
    if (v[0] !== '/') return [];
    const word = v.split(' ')[0].toLowerCase();
    return S.sugs.filter((s) => s.name.toLowerCase().startsWith(word)).slice(0, 8);
}
function renderSuggestions() {
    const items = currentSugs();
    const b = $('#suggestions');
    if (!items.length || input.value.includes(' ')) { b.classList.add('hidden'); return; }
    S.sugIdx = Math.min(S.sugIdx, items.length - 1);
    b.innerHTML = items.map((s, i) => `<div class="sug${i === S.sugIdx ? ' active' : ''}" data-i="${i}"><b>${esc(s.name)}</b>` +
        (s.params ? ' ' + s.params.map((p) => `[${esc(p.name)}]`).join(' ') : '') + (s.help ? `<small>${esc(s.help)}</small>` : '') + '</div>').join('');
    b.classList.remove('hidden');
}
function moveSuggestion(d) { const n = currentSugs().length; S.sugIdx = (S.sugIdx + d + n) % n; renderSuggestions(); }
function pickSuggestion(i = S.sugIdx) {
    const s = currentSugs()[i];
    if (!s) return;
    input.value = s.name + ' '; autoSize();
    $('#suggestions').classList.add('hidden'); input.focus();
}
$('#suggestions').addEventListener('mousedown', (e) => { const s = e.target.closest('.sug'); if (s) { e.preventDefault(); pickSuggestion(+s.dataset.i); } });

// ------------------------------------------------------------------ images (paste)
function clearImage() { S.image = null; $('#image-bar').classList.add('hidden'); }
$('#image-cancel').onclick = clearImage;

function compress(file) {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => {
            let w = img.width, h = img.height;
            const max = 900;
            if (w > max || h > max) { const r = Math.min(max / w, max / h); w = Math.round(w * r); h = Math.round(h * r); }
            const c = document.createElement('canvas');
            c.width = w; c.height = h;
            c.getContext('2d').drawImage(img, 0, 0, w, h);
            const limit = S.cfg.images.MaxKB * 1024 * 1.37;
            let q = 0.82, data = c.toDataURL('image/jpeg', q);
            while (data.length > limit && q > 0.3) { q -= 0.1; data = c.toDataURL('image/jpeg', q); }
            if (data.length > limit) reject(); else resolve(data);
            URL.revokeObjectURL(img.src);
        };
        img.onerror = reject;
        img.src = URL.createObjectURL(file);
    });
}
input.addEventListener('paste', (e) => {
    if (!S.cfg.images.Enabled) return;
    const item = Array.from(e.clipboardData.items || []).find((i) => i.type.startsWith('image/'));
    if (!item) return;
    e.preventDefault();
    compress(item.getAsFile()).then((data) => {
        S.image = data;
        $('#image-preview').src = data;
        $('#image-bar').classList.remove('hidden');
    }).catch(() => system('الصورة كبيرة جداً', '#ef4444'));
});

// ------------------------------------------------------------------ popovers
function closePopovers(except) { ['#picker', '#settings', '#pins', '#channels-pop'].forEach((s) => { if (s !== except) $(s).classList.add('hidden'); }); $('#btn-settings').classList.remove('active'); }
function toggle(sel) { const p = $(sel); const show = p.classList.contains('hidden'); closePopovers(sel); p.classList.toggle('hidden', !show); return show; }

$('#btn-settings').onclick = () => { $('#btn-settings').classList.toggle('active', toggle('#settings')); };
$('#btn-pins').onclick = () => toggle('#pins');
$('#btn-channels').onclick = () => toggle('#channels-pop');

// text formatting toolbar (appears when text is selected in the input)
const fmtBar = $('#fmt-bar');
const FMT = { b: ['**', '**'], i: ['*', '*'], u: ['__', '__'], s: ['~~', '~~'], c: ['`', '`'], sp: ['||', '||'] };
const updateFmt = () => fmtBar.classList.toggle('hidden', input.disabled || input.selectionStart === input.selectionEnd);
['select', 'mouseup', 'keyup'].forEach((ev) => input.addEventListener(ev, updateFmt));
input.addEventListener('blur', () => fmtBar.classList.add('hidden'));
fmtBar.addEventListener('mousedown', (e) => {
    e.preventDefault();   // keep the selection / focus in the input
    const b = e.target.closest('[data-fmt]');
    if (!b) return;
    const [a, z] = FMT[b.dataset.fmt];
    const s = input.selectionStart, en = input.selectionEnd;
    input.value = input.value.slice(0, s) + a + input.value.slice(s, en) + z + input.value.slice(en);
    input.selectionStart = s + a.length; input.selectionEnd = en + a.length;
    autoSize(); updateCounter();
});
$('#pinned-bar').onclick = () => toggle('#pins');
$('#pins').addEventListener('click', (e) => { const p = e.target.closest('[data-jump]'); if (p) { closePopovers(); jumpTo(p.dataset.jump); } });

// themes / sound
function applyTheme(t) {
    document.body.className = `theme-${t}`;
    $$('.themes button').forEach((b) => b.classList.toggle('active', b.dataset.theme === t));
    S.cfg.theme = t;
}
$$('.themes button').forEach((b) => b.onclick = () => { applyTheme(b.dataset.theme); post('settings', { theme: b.dataset.theme }); });
const syncSound = () => { $('#opt-sound').checked = S.cfg.sound; $('#set-sound').classList.toggle('off', !S.cfg.sound); };
$('#opt-sound').onchange = (e) => { S.cfg.sound = e.target.checked; syncSound(); post('settings', { sound: S.cfg.sound }); };

// settings tray buttons
const setPanel = (id) => { $$('.set-panel').forEach((p) => p.classList.toggle('hidden', p.id !== id || !p.classList.contains('hidden'))); $$('.tray .tb[data-panel]').forEach((b) => b.classList.toggle('active', b.dataset.panel === id && !$('#' + id).classList.contains('hidden'))); };
$('#set-close').onclick = () => closePopovers();
$('#set-sound').onclick = () => { const o = $('#opt-sound'); o.checked = !o.checked; o.onchange({ target: o }); };
$('#set-search').onclick = () => { closePopovers(); $('#search-bar').classList.remove('hidden'); $('#search').focus(); };
$('#set-poll').onclick = () => $('#btn-poll').click();
$$('.tray .tb[data-panel]').forEach((b) => b.onclick = () => setPanel(b.dataset.panel));
$('#search-close').onclick = () => { S.search = ''; $('#search').value = ''; applySearch(); $('#search-bar').classList.add('hidden'); input.focus(); };

// emoji / sticker picker
let pickerTab = 'emoji', emojiCat = Object.keys(window.EMOJIS)[0];
function renderPicker() {
    $$('.picker-tabs button').forEach((b) => b.classList.toggle('active', b.dataset.tab === pickerTab));
    const cats = $('#picker-cats'), grid = $('#picker-grid');
    grid.classList.toggle('stickers', pickerTab === 'sticker');
    if (pickerTab === 'emoji') {
        cats.innerHTML = Object.keys(window.EMOJIS).map((k) => `<button class="${k === emojiCat ? 'active' : ''}" data-cat="${k}"><i class="${k}"></i></button>`).join('');
        cats.classList.remove('hidden');
        grid.innerHTML = window.EMOJIS[emojiCat].map((e) => `<button data-emoji="${e}">${e}</button>`).join('');
    } else {
        cats.classList.add('hidden');
        grid.innerHTML = S.cfg.stickers.map((c) => `<button data-sticker="${esc(c)}"><img src="${stickerUrl(esc(c))}" loading="lazy" alt=""></button>`).join('');
    }
}
$('#btn-emoji').onclick = () => { if (toggle('#picker')) renderPicker(); };
$('.picker-tabs').onclick = (e) => { const b = e.target.closest('button'); if (b) { pickerTab = b.dataset.tab; renderPicker(); } };
$('#picker-cats').onclick = (e) => { const b = e.target.closest('button'); if (b) { emojiCat = b.dataset.cat; renderPicker(); } };
$('#picker-grid').onclick = (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    if (b.dataset.emoji) {
        const s = input.selectionStart ?? input.value.length;
        input.value = input.value.slice(0, s) + b.dataset.emoji + input.value.slice(input.selectionEnd ?? s);
        input.focus(); input.selectionStart = input.selectionEnd = s + b.dataset.emoji.length;
        autoSize(); updateCounter();
    } else if (b.dataset.sticker) {
        const c = chan(S.current);
        if (c && c.canWrite) post('send', { channel: S.current, text: '', sticker: b.dataset.sticker, replyTo: S.reply ? S.reply.id : null });
        cancelReply(); closePopovers();
    }
};

// polls
function pollRow(v = '') {
    const i = el('input'); i.maxLength = 60; i.placeholder = `خيار ${$$('#poll-opts input').length + 1}`; i.value = v;
    $('#poll-opts').appendChild(i);
}
$('#btn-poll').onclick = () => {
    if (S.perms.poll === false) { system('ما عندك صلاحية تسوي تصويت', '#ef4444'); return; }
    closePopovers();
    $('#poll-q').value = ''; $('#poll-opts').innerHTML = ''; pollRow(); pollRow();
    $('#poll-modal').classList.remove('hidden'); $('#poll-q').focus();
};
$('#poll-add').onclick = () => { if ($$('#poll-opts input').length < 6) pollRow(); };
$('#poll-cancel').onclick = () => $('#poll-modal').classList.add('hidden');
$('#poll-create').onclick = () => {
    const question = $('#poll-q').value.trim();
    const options = $$('#poll-opts input').map((i) => i.value.trim()).filter(Boolean);
    if (!question || options.length < 2) return;
    post('poll', { channel: S.current, question, options });
    $('#poll-modal').classList.add('hidden');
};

// search
$('#search').addEventListener('input', (e) => { S.search = e.target.value; applySearch(); });
$('#jump').onclick = () => toBottom(true);
box.addEventListener('scroll', () => { if (nearBottom()) $('#jump').classList.add('hidden'); });

// ------------------------------------------------------------------ floating menus
const floatEl = $('#menu'), reactEl = $('#react-pop');
function hideFloat() { floatEl.classList.add('hidden'); reactEl.classList.add('hidden'); }
function place(node, x, y) {
    node.classList.remove('hidden');
    const r = node.getBoundingClientRect();
    node.style.left = Math.min(x, innerWidth - r.width - 8) + 'px';
    node.style.top = Math.min(y, innerHeight - r.height - 8) + 'px';
}
function showReactPicker(m, x, y) {
    reactEl.innerHTML = S.cfg.quick.map((e) => `<button data-emoji="${esc(e)}">${esc(e)}</button>`).join('') +
        '<button data-more="1" title="المزيد"><i class="fa-solid fa-plus" style="font-size:14px"></i></button>';
    reactEl.dataset.id = m.id;
    place(reactEl, x, y);
}
reactEl.onclick = (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    if (b.dataset.more) { // full emoji list in the same popup
        reactEl.innerHTML = Object.values(window.EMOJIS).flat().slice(0, 64).map((x) => `<button data-emoji="${x}">${x}</button>`).join('');
        reactEl.style.flexWrap = 'wrap'; reactEl.style.width = '312px';
        return;
    }
    post('react', { id: reactEl.dataset.id, emoji: b.dataset.emoji });
    reactEl.style.flexWrap = ''; reactEl.style.width = '';
    hideFloat();
};

const ADMIN_ITEMS = [
    ['spectate', 'fa-solid fa-eye', 'مراقبة'], ['TPToMe', 'fa-solid fa-arrows-to-dot', 'سحب لعندي'], ['TPToPlayer', 'fa-solid fa-location-arrow', 'الذهاب له'],
    ['revive', 'fa-solid fa-heart-pulse', 'انعاش'], ['food', 'fa-solid fa-burger', 'تعبئة الاكل والشرب'], ['cuff', 'fa-solid fa-handcuffs', 'كلبشة'],
    ['cufftp', 'fa-solid fa-people-pulling', 'كلبشة وسحب'], ['mute', 'fa-solid fa-comment-slash', 'ميوت شات'], ['jail', 'fa-solid fa-dungeon', 'سجن'],
    ['unjail', 'fa-solid fa-door-open', 'اخراج من السجن'], ['PlayerGroup', 'fa-solid fa-users', 'استعلام عن الرتب'], ['addgroup', 'fa-solid fa-user-plus', 'اضافة رتبة'],
    ['removegroup', 'fa-solid fa-user-minus', 'ازالة رتبة'], ['givemoney', 'fa-solid fa-money-bill', 'اعطاء فلوس'], ['ChangeSkin', 'fa-solid fa-shirt', 'تغيير سكن'],
    ['Deletewep', 'fa-solid fa-gun', 'حذف الاسلحة'], ['emptybag', 'fa-solid fa-box-open', 'افراغ الحقيبة'], ['DeletePlayerMessage', 'fa-solid fa-eraser', 'حذف كل رسائله', 'danger'],
    ['Kick', 'fa-solid fa-right-from-bracket', 'طرد', 'danger'], ['Ban', 'fa-solid fa-gavel', 'باند', 'danger'],
];
function showPlayerMenu(m, x, y) {
    let h = `<div class="head"><b style="--c:${esc(m.color || '')}">${esc(m.name)}</b> #${m.uid}</div>`;
    h += `<button class="mi" data-do="mention"><i class="fa-solid fa-at"></i>منشن</button>`;
    if (m.uid !== S.me.uid) {
        h += `<button class="mi" data-do="sendMoney"><i class="fa-solid fa-sack-dollar"></i>تحويل نقود</button>`;
        h += `<button class="mi" data-do="sendLoc"><i class="fa-solid fa-location-dot"></i>ارسال موقعك</button>`;
        h += `<button class="mi" data-do="sendMessage"><i class="fa-solid fa-envelope"></i>ارسال رسالة</button>`;
    }
    if (S.perms.admin) {
        h += '<div class="sep"></div><div class="head">الادارة</div>';
        h += ADMIN_ITEMS.map(([a, i, t, c]) => `<button class="mi ${c || ''}" data-do="${a}"><i class="${i}"></i>${t}</button>`).join('');
    }
    floatEl.innerHTML = h;
    floatEl.dataset.uid = m.uid;
    floatEl.style.maxHeight = '70vh'; floatEl.style.overflowY = 'auto';
    place(floatEl, x, y);
}
floatEl.onclick = (e) => {
    const b = e.target.closest('[data-do]');
    if (!b) return;
    const uid = +floatEl.dataset.uid;
    if (b.dataset.do === 'mention') {
        input.value = (input.value ? input.value.trimEnd() + ' ' : '') + `@${uid} `;
        input.focus(); autoSize();
    } else {
        post('action', { action: b.dataset.do, uid });
        closeChat(false);
    }
    hideFloat();
};

// copy (clipboard API is not always allowed in NUI)
function copyText(t) {
    const ta = el('textarea'); ta.value = t; document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); } catch (e) {}
    ta.remove();
}

// clicks inside the message list
box.addEventListener('click', (e) => {
    const t = e.target;
    const msgEl = t.closest('.msg');
    const m = msgEl && S.byId[msgEl.dataset.id];
    const link = t.closest('a.link');
    if (link) { askOpenLink(link.dataset.url); return; }
    if (t.classList.contains('spoiler')) { t.classList.toggle('shown'); return; }
    if (t.classList.contains('msg-image')) { $('#lightbox-img').src = t.src; $('#lightbox').classList.remove('hidden'); return; }
    if (!m) return;
    const jump = t.closest('[data-jump]');
    if (jump) { jumpTo(jump.dataset.jump); return; }
    const name = t.closest('.name, .tag');
    if (name) { showPlayerMenu(m, e.clientX + 6, e.clientY + 6); return; }
    const react = t.closest('.react');
    if (react) { post('react', { id: m.id, emoji: react.dataset.emoji }); return; }
    const opt = t.closest('.poll-opt');
    if (opt) { post('vote', { id: m.id, option: +opt.dataset.opt }); return; }
    const act = t.closest('[data-act]');
    if (!act) return;
    const r = act.getBoundingClientRect();
    switch (act.dataset.act) {
        case 'reply': setReply(m); break;
        case 'react': showReactPicker(m, r.left, r.bottom + 6); break;
        case 'copy': copyText(m.text || ''); break;
        case 'pin': post('pin', { id: m.id }); break;
        case 'edit': setEdit(m); break;
        case 'delete': post('delete', { id: m.id }); break;
    }
});
$('#lightbox').onclick = () => $('#lightbox').classList.add('hidden');

// external links ask first
let pendingUrl = null;
function askOpenLink(url) {
    pendingUrl = url;
    $('#link-url').textContent = url;
    $('#link-modal').classList.remove('hidden');
}
$('#link-open').onclick = () => {
    if (pendingUrl && window.invokeNative) window.invokeNative('openUrl', pendingUrl);
    pendingUrl = null; $('#link-modal').classList.add('hidden');
};
$('#link-cancel').onclick = () => { pendingUrl = null; $('#link-modal').classList.add('hidden'); };

document.addEventListener('mousedown', (e) => {
    const t = e.target instanceof Element ? e.target : document.body;
    if (!t.closest('.float') && !t.closest('[data-act="react"]')) hideFloat();
    if (!t.closest('.popover') && !t.closest('.icon-btn') && !t.closest('#pinned-bar')) closePopovers();
});
document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape' || !S.open) return;
    if (!$('#poll-modal').classList.contains('hidden')) { $('#poll-modal').classList.add('hidden'); return; }
    if (!$('#lightbox').classList.contains('hidden')) { $('#lightbox').classList.add('hidden'); return; }
    if (!$('#link-modal').classList.contains('hidden')) { $('#link-cancel').click(); return; }
    if (!floatEl.classList.contains('hidden') || !reactEl.classList.contains('hidden')) { hideFloat(); return; }
    closeChat();
});

// ------------------------------------------------------------------ legacy chat API
function legacy(d) {
    const args = (d.args || []).map((a) => (a == null ? '' : String(a)));
    let author = d.author, text;
    if (author === undefined && args.length > 1) { author = args.shift(); }
    text = args.join(' ');
    if (author === '' || author === undefined) author = null;
    const tpl = d.templateId ? S.templates[d.templateId] : d.template;
    let html = null;
    if (tpl) html = String(tpl).replace(/\{(\d+)\}/g, (_, i) => esc(args[i] ?? (i == 0 ? author : '')));
    addMessage({ id: 's' + (++sysId), system: true, channel: 'general', time: Date.now() / 1000, author, text, color: rgb(d.color), html });
}

// ------------------------------------------------------------------ messages from Lua
window.addEventListener('message', ({ data }) => {
    switch (data.type) {
        case 'config': {
            Object.assign(S.cfg, data.config);
            $('.brand-logo').src = S.cfg.logo;
            $('.brand-name').textContent = S.cfg.serverName;
            input.maxLength = S.cfg.maxLength;
            syncSound();
            applyTheme(S.cfg.theme);
            break;
        }
        case 'init': {
            const d = data.data;
            S.me = d.me; S.perms = d.perms || {};
            S.channels = d.channels || S.channels;
            if (!chan(S.current)) S.current = S.channels[0].id;
            S.pins = d.pins || {};
            for (const ch of S.channels) {
                const keepSys = list(ch.id).filter((m) => m.system);
                S.lists[ch.id] = [];
                for (const m of (d.history[ch.id] || [])) { S.lists[ch.id].push(m); S.byId[m.id] = m; }
                S.lists[ch.id].push(...keepSys);
            }
            $('#btn-poll').classList.toggle('hidden', S.perms.poll === false);
            renderChannels(); renderChannel();
            break;
        }
        case 'message': addMessage(data.msg); break;
        case 'system': system(data.data.text, data.data.color, '⚠'); break;
        case 'legacy': legacy(data.data || {}); break;
        case 'update': {
            const p = data.patch, m = S.byId[p.id];
            if (!m) return;
            if (p.reactions !== undefined) m.reactions = p.reactions || {};
            if (p.poll) m.poll = p.poll;
            if (p.text !== undefined) { m.text = p.text; m.edited = true; }
            if (p.pinned !== undefined) m.pinned = p.pinned;
            refresh(m);
            break;
        }
        case 'remove': {
            const m = S.byId[data.id];
            if (!m) return;
            const l = list(m.channel); l.splice(l.indexOf(m), 1);
            delete S.byId[data.id];
            if (m.el) m.el.remove();
            break;
        }
        case 'removeUser':
            Object.values(S.byId).filter((m) => m.uid === data.uid).forEach((m) => {
                const l = list(m.channel); l.splice(l.indexOf(m), 1); delete S.byId[m.id]; if (m.el) m.el.remove();
            });
            break;
        case 'pins': S.pins[data.channel] = data.list || []; if (data.channel === S.current) renderPins(); break;
        case 'typing': {
            (S.typing[data.channel] = S.typing[data.channel] || {})[data.uid] = { name: data.name, until: Date.now() + 4000 };
            if (data.channel === S.current) renderTyping();
            break;
        }
        case 'suggestion':
            for (const s of data.list || []) { if (s && s.name && !S.sugs.find((x) => x.name === s.name)) S.sugs.push(s); }
            break;
        case 'suggestionRemove': S.sugs = S.sugs.filter((s) => s.name !== data.name); break;
        case 'template': S.templates[data.id] = data.html; break;
        case 'clear': S.lists = {}; S.byId = {}; renderChannel(); break;
        case 'open': openChat(); break;
        case 'close': closeChat(false); break;
        case 'visible': chatEl.classList.toggle('off', !data.value); break;
        case 'screen': chatEl.classList.toggle('screen-hidden', !!data.hidden); break;
    }
});

renderChannels();
post('loaded');
})();
