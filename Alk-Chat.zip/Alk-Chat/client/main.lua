-- ============================================================================
--  Alk Store | Chat  -  client
-- ============================================================================
local C = AlkChat
local isOpen, nuiReady, visible, pauseHidden = false, false, true, false

local function nui(type, data)
    data = data or {}
    data.type = type
    SendNUIMessage(data)
end

-- ------------------------------------------------------------------ server -> ui
RegisterNetEvent('Alk-Chat:init', function(data) nui('init', { data = data }) end)
RegisterNetEvent('Alk-Chat:message', function(msg) nui('message', { msg = msg }) end)
RegisterNetEvent('Alk-Chat:update', function(patch) nui('update', { patch = patch }) end)
RegisterNetEvent('Alk-Chat:remove', function(id) nui('remove', { id = id }) end)
RegisterNetEvent('Alk-Chat:pins', function(channel, list) nui('pins', { channel = channel, list = list }) end)
RegisterNetEvent('Alk-Chat:typing', function(channel, uid, name) nui('typing', { channel = channel, uid = uid, name = name }) end)
RegisterNetEvent('Alk-Chat:system', function(data) nui('system', { data = data }) end)
RegisterNetEvent('Alk-Chat:requestReady', function() if nuiReady then TriggerServerEvent('Alk-Chat:ready') end end)

-- ------------------------------------------------------------------ standard chat API (other scripts)
RegisterNetEvent('chatMessage')
RegisterNetEvent('chat:addTemplate')
RegisterNetEvent('chat:addMessage')
RegisterNetEvent('chat:addSuggestion')
RegisterNetEvent('chat:addSuggestions')
RegisterNetEvent('chat:removeSuggestion')
RegisterNetEvent('chat:clear')

AddEventHandler('chatMessage', function(author, color, text)
    nui('legacy', { data = { author = author, color = color, args = text ~= nil and { text } or {} } })
end)
AddEventHandler('chat:addMessage', function(message) nui('legacy', { data = message }) end)
AddEventHandler('chat:addSuggestion', function(name, help, params) nui('suggestion', { list = { { name = name, help = help, params = params } } }) end)
AddEventHandler('chat:addSuggestions', function(list) nui('suggestion', { list = list }) end)
AddEventHandler('chat:removeSuggestion', function(name) nui('suggestionRemove', { name = name }) end)
AddEventHandler('chat:addTemplate', function(id, html) nui('template', { id = id, html = html }) end)
AddEventHandler('chat:clear', function() nui('clear') end)
AddEventHandler('chat:close', function() if isOpen then isOpen = false; SetNuiFocus(false, false); nui('close') end end)

-- old admin events from server/admin.lua
RegisterNetEvent('chat:Delete', function(id) nui('remove', { id = id }) end)
RegisterNetEvent('chat:DeleteAll', function(uid) nui('removeUser', { uid = tonumber(uid) }) end)
RegisterNetEvent('chat:Edit', function(id, text) nui('update', { patch = { id = id, text = text, edited = true } }) end)
RegisterNetEvent('chat:Audio', function() end)

-- citizen menu button (Alk-Files) : show / hide chat
RegisterNetEvent('Alk-Chat:client:show/hidechat', function()
    visible = not visible
    nui('visible', { value = visible })
    TriggerEvent('Alk-NuiNotify:SendAlert', C.ServerName, visible and 'تم اظهار الشات' or 'تم اخفاء الشات', 3000, 'info')
end)

-- ------------------------------------------------------------------ ui -> lua
RegisterNUICallback('loaded', function(_, cb)
    nuiReady = true
    TriggerServerEvent('chat:init')
    TriggerServerEvent('Alk-Chat:ready')
    nui('config', { config = {
        serverName = C.ServerName, logo = C.Logo, fade = C.FadeSeconds, maxLength = C.MaxLength,
        theme = GetResourceKvpString('alkchat_theme') or C.DefaultTheme,
        sound = GetResourceKvpInt('alkchat_mute') ~= 1,
        quick = C.QuickReactions, stickers = C.Stickers, images = C.Images, editMinutes = C.EditMinutes, closeOnSend = C.CloseOnSend,
    } })
    cb('ok')
end)

local function closeInput()
    isOpen = false
    SetNuiFocus(false, false)
end

RegisterNUICallback('close', function(_, cb) closeInput(); cb('ok') end)

RegisterNUICallback('send', function(data, cb)
    local text = tostring(data.text or '')
    if data.close then closeInput() end
    if text:sub(1, 1) == '/' and not data.sticker then
        ExecuteCommand(text:sub(2))
    else
        TriggerServerEvent('Alk-Chat:send', { channel = data.channel, text = text, replyTo = data.replyTo, sticker = data.sticker })
    end
    cb('ok')
end)

RegisterNUICallback('image', function(data, cb)
    TriggerLatentServerEvent('Alk-Chat:image', 150000, { channel = data.channel, image = data.image, caption = data.caption })
    cb('ok')
end)

RegisterNUICallback('typing', function(data, cb) TriggerServerEvent('Alk-Chat:typing', data.channel); cb('ok') end)
RegisterNUICallback('react', function(data, cb) TriggerServerEvent('Alk-Chat:react', data.id, data.emoji); cb('ok') end)
RegisterNUICallback('pin', function(data, cb) TriggerServerEvent('Alk-Chat:pin', data.id); cb('ok') end)
RegisterNUICallback('delete', function(data, cb) TriggerServerEvent('Alk-Chat:delete', data.id); cb('ok') end)
RegisterNUICallback('edit', function(data, cb) TriggerServerEvent('Alk-Chat:edit', data.id, data.text); cb('ok') end)
RegisterNUICallback('poll', function(data, cb) TriggerServerEvent('Alk-Chat:poll', data); cb('ok') end)
RegisterNUICallback('vote', function(data, cb) TriggerServerEvent('Alk-Chat:vote', data.id, data.option); cb('ok') end)
RegisterNUICallback('settings', function(data, cb)
    if data.theme then SetResourceKvp('alkchat_theme', data.theme) end
    if data.sound ~= nil then SetResourceKvpInt('alkchat_mute', data.sound and 0 or 1) end
    cb('ok')
end)

-- player menu (click on a name). Server side checks every permission again.
local actions = {
    sendMoney = 'LuaQV2:SendMoney', sendLoc = 'LuaQV2:SendLoc', sendMessage = 'LuaQV2:SendMessage',
    spectate = 'LuaQV2:Spec', TPToMe = 'LuaQV2:Tptome', TPToPlayer = 'LuaQV2:Tptoplayer',
    Kick = 'LuaQV2:Kick', Ban = 'LuaQV2:ban', addgroup = 'LuaQV2:AddGroup', removegroup = 'LuaQV2:RemoveGroup',
    revive = 'LuaQV2:revive', food = 'LuaQV2:SetHunger-Thirst', mute = 'Chat:Mute:Server',
    cuff = 'LuaQV2:toggleHandcuff', cufftp = 'LuaQV2:toggleHandcuff:tp', ChangeSkin = 'LuaQV2:ChangeSkin',
    Deletewep = 'LuaQV2:DeleteWeap', givemoney = 'LuaQV2:GiveMoney', emptybag = 'LuaQV2:clearInventory',
    PlayerGroup = 'LuaQV2:PlayerGroups', jail = 'LuaQV2:Jail', unjail = 'LuaQV2:UnJail',
    DeletePlayerMessage = 'LuaQV22:Server:DeleteMessage',
}
RegisterNUICallback('action', function(data, cb)
    local event = actions[data.action]
    if event and tonumber(data.uid) then
        if IsPedCuffed(PlayerPedId()) then
            TriggerServerEvent('LuaQV22:Client:ChatMessageCuff')
        else
            closeInput()
            nui('close')
            TriggerServerEvent(event, tonumber(data.uid))
        end
    end
    cb('ok')
end)

-- ------------------------------------------------------------------ open key / screen state
CreateThread(function()
    SetTextChatEnabled(false)
    SetNuiFocus(false, false)
    while true do
        Wait(0)
        DisableControlAction(0, C.OpenKey, true)
        if not isOpen and nuiReady and visible and IsDisabledControlJustReleased(0, C.OpenKey) and not IsPauseMenuActive() then
            isOpen = true
            SetNuiFocus(true, true)
            nui('open')
        end
        local shouldHide = IsScreenFadedOut() or IsPauseMenuActive()
        if shouldHide ~= pauseHidden then
            pauseHidden = shouldHide
            nui('screen', { hidden = shouldHide })
        end
    end
end)

-- refresh command suggestions when resources start/stop
local function refreshCommands()
    if not GetRegisteredCommands then return end
    local list = {}
    for _, command in ipairs(GetRegisteredCommands()) do
        if IsAceAllowed(('command.%s'):format(command.name)) then list[#list + 1] = { name = '/' .. command.name, help = '' } end
    end
    nui('suggestion', { list = list })
end
AddEventHandler('onClientResourceStart', function() Wait(500); refreshCommands() end)
AddEventHandler('onClientResourceStop', function() Wait(500); refreshCommands() end)
