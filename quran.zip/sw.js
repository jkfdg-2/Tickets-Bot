/* Service Worker: يحفظ الموقع ونص القرآن للعمل دون اتصال.
   التلاوات تُحفظ تدريجيًا عند الاستماع إليها. */
const VERSION = 'rattil-v5';
const AUDIO = 'rattil-audio';
const SHELL = [
  './', 'index.html', 'css/style.css', 'css/fonts.css',
  'fonts/amiri-quran-arabic-400-normal.woff2', 'fonts/ibm-plex-sans-arabic-arabic-400-normal.woff2',
  'fonts/ibm-plex-sans-arabic-arabic-600-normal.woff2', 'fonts/ibm-plex-sans-arabic-arabic-700-normal.woff2', 'manifest.json', 'icons/icon.svg',
  'data/quran-data.js', 'js/config.js', 'js/store.js', 'js/quran.js', 'js/ui.js', 'js/audio.js',
  'js/recite-engine.js', 'js/speech.js', 'js/recorder.js', 'js/app.js', 'js/player-ui.js',
  'js/reciters/everyayah.js', 'js/reciters/catalog.js', 'js/views/reciters.js', 'js/progress.js',
  'js/views/home.js', 'js/views/reader.js', 'js/views/lists.js', 'js/views/search.js',
  'js/views/favorites.js', 'js/views/memorize.js', 'js/views/khatma.js', 'js/views/settings.js',
  'js/views/plan.js', 'js/views/test.js', 'js/views/progress.js'
];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSION).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== VERSION && k !== AUDIO).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET') return;
  if (url.hostname === 'everyayah.com') {
    // التلاوة: من الذاكرة أولًا، وإلا تُجلب كاملة (بلا Range) وتُحفظ
    e.respondWith(caches.open(AUDIO).then(async c => {
      const hit = await c.match(url.href);
      if (hit) return hit;
      const res = await fetch(url.href);
      if (res.status === 200) c.put(url.href, res.clone());
      return res;
    }));
    return;
  }
  if (url.origin !== location.origin) return;
  e.respondWith(caches.match(e.request).then(hit => hit || fetch(e.request).then(res => {
    if (res.ok) { const copy = res.clone(); caches.open(VERSION).then(c => c.put(e.request, copy)); }
    return res;
  })));
});
