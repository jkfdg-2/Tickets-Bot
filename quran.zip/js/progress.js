/* تقدّم الحفظ: خطة الحفظ + المراجعة المتباعدة + أخطاء كل آية + الاختبارات + الأيام المتتالية + آخر نشاط.
   كل شيء محفوظ على الجهاز عبر App.Store. */
(function () {
  const Q = App.Q, Store = App.Store;
  const DAY = 86400000;
  const dayKey = d => { const x = new Date(d); x.setHours(0, 0, 0, 0); return x.getTime(); };
  const addDays = (d, n) => { const x = new Date(dayKey(d)); x.setDate(x.getDate() + n); return x.getTime(); };
  const today = () => dayKey(Date.now());

  // فترات المراجعة بالأيام: بعد يوم، ٣ أيام، أسبوع، ثم تتباعد حسب مستوى المستخدم
  const INTERVALS = [1, 3, 7, 14, 30, 60, 120];
  const PASS = 90;        // اختبار ناجح
  const PLAN_PASS = 80;   // إتمام ورد الخطة

  function rangeLabel(from, to) {
    const a = Q.ref(from), b = Q.ref(to);
    if (a.sura === b.sura) {
      const name = Q.sura(a.sura).name;
      return from === to ? `سورة ${name} — الآية ${Q.ar(a.ayah)}` : `سورة ${name} — الآيات ${Q.ar(a.ayah)}–${Q.ar(b.ayah)}`;
    }
    return `${Q.shortRef(from)} — ${Q.shortRef(to)}`;
  }

  /* ---------- الأيام النشطة ---------- */
  function markActive() {
    const days = Store.read('activeDays', []);
    const t = today();
    if (days[days.length - 1] !== t) { days.push(t); Store.write('activeDays', days.slice(-400)); }
  }
  function streak() {
    const set = new Set(Store.read('activeDays', []));
    let d = set.has(today()) ? today() : addDays(today(), -1), n = 0;
    while (set.has(d)) { n++; d = addDays(d, -1); }
    return n;
  }

  /* ---------- آخر نشاط ---------- */
  function setActivity(kind, label, href) { Store.write('activity', { kind, label, href, at: Date.now() }); markActive(); }
  function lastActivity() {
    const a = Store.read('activity', null), r = Store.lastRead();
    if (r && (!a || r.at > a.at)) return { kind: 'read', label: 'قراءة ' + Q.shortRef(r.gi) + '، صفحة ' + Q.ar(r.page), href: `#/read?p=${r.page}&g=${r.gi}`, at: r.at };
    return a;
  }

  /* ---------- أخطاء كل آية (لأولوية المراجعة) ---------- */
  function ayahErrs() { return Store.read('ayahErrs', {}); }
  /* words: كلمات محرك التسميع { gi, state } */
  function recordWords(words) {
    const errs = ayahErrs(), per = new Map();
    words.forEach(w => {
      if (w.state === 'pending') return;
      const e = per.get(w.gi) || 0;
      per.set(w.gi, e + (w.state === 'err' || w.state === 'skip' ? 1 : 0));
    });
    per.forEach((e, gi) => {
      if (e) errs[gi] = (errs[gi] || 0) + e;
      else if (errs[gi]) { errs[gi] = Math.max(0, errs[gi] - 1); if (!errs[gi]) delete errs[gi]; } // قراءة صحيحة تخفف الأولوية
    });
    Store.write('ayahErrs', errs);
    markActive();
  }
  function weakAyahs(n = 5) {
    return Object.entries(ayahErrs()).map(([gi, e]) => ({ gi: +gi, errs: e })).sort((a, b) => b.errs - a.errs).slice(0, n);
  }
  function rangeWeight(from, to) {
    const errs = ayahErrs(); let s = 0;
    for (let g = from; g <= to; g++) s += errs[g] || 0;
    return s;
  }

  /* ---------- المراجعة ---------- */
  function reviews() { return Store.read('reviews', []); }
  function saveReviews(r) { Store.write('reviews', r); }
  function findReview(from, to) { return reviews().find(r => r.from === from && r.to === to) || null; }
  function addReview(from, to) {
    const all = reviews();
    if (all.some(r => r.from === from && r.to === to)) return false;
    all.push({ id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), from, to, stage: 0, due: addDays(Date.now(), INTERVALS[0]), created: Date.now(), lastAcc: null, count: 0 });
    saveReviews(all);
    return true;
  }
  /* نتيجة المراجعة تحدد الموعد التالي: متقن ← يتباعد، متوسط ← نفس الفترة، ضعيف ← من البداية */
  function reviewDone(id, acc) {
    const all = reviews(), r = all.find(x => x.id === id);
    if (!r) return null;
    r.stage = acc >= PASS ? Math.min(r.stage + 1, INTERVALS.length - 1) : acc >= 70 ? r.stage : 0;
    r.due = addDays(Date.now(), INTERVALS[r.stage]);
    r.lastAcc = acc; r.count++; r.last = Date.now();
    saveReviews(all);
    return r;
  }
  function removeReview(id) { saveReviews(reviews().filter(r => r.id !== id)); }
  /* المستحقة اليوم مرتبة بالأولوية: الأكثر تأخرًا ثم الأكثر أخطاءً */
  function dueReviews() {
    const t = today();
    return reviews().filter(r => r.due <= t).map(r => Object.assign({ late: Math.round((t - r.due) / DAY), weight: rangeWeight(r.from, r.to) }, r))
      .sort((a, b) => (b.weight - a.weight) || (b.late - a.late));
  }
  function upcomingReviews(n = 5) { const t = today(); return reviews().filter(r => r.due > t).sort((a, b) => a.due - b.due).slice(0, n); }
  function suggestedDates() { return INTERVALS.slice(0, 3).map(d => addDays(Date.now(), d)); }

  /* الآيات المحفوظة = كل ما دخل جدول المراجعة */
  function memorizedSet() {
    const s = new Set();
    reviews().forEach(r => { for (let g = r.from; g <= r.to; g++) s.add(g); });
    return s;
  }
  function dueAyahCount() {
    const s = new Set();
    dueReviews().forEach(r => { for (let g = r.from; g <= r.to; g++) s.add(g); });
    return s.size;
  }

  /* ---------- خطة الحفظ ---------- */
  function buildPlan(from, to, perDay, start) {
    const days = [];
    for (let g = from; g <= to; g += perDay) days.push({ from: g, to: Math.min(to, g + perDay - 1), done: false, doneAt: null, acc: null });
    return { from, to, perDay, start: dayKey(start), days, created: Date.now() };
  }
  function plan() { return Store.read('memPlan', null); }
  function setPlan(p) { Store.write('memPlan', p); }
  function planDay(p) { const i = p.days.findIndex(d => !d.done); return i < 0 ? null : Object.assign({ index: i, date: addDays(p.start, i) }, p.days[i]); }
  function planPct(p) {
    const total = p.to - p.from + 1;
    const done = p.days.filter(d => d.done).reduce((s, d) => s + d.to - d.from + 1, 0);
    return Math.round(done / total * 100);
  }
  function completePlanDay(i, acc) {
    const p = plan(); if (!p || !p.days[i]) return false;
    const d = p.days[i];
    d.done = true; d.doneAt = Date.now(); d.acc = acc;
    setPlan(p);
    addReview(d.from, d.to);
    return true;
  }

  /* ---------- الاختبارات والجلسات ---------- */
  function tests() { return Store.read('tests', []); }
  function addTest(t) { const all = tests(); all.unshift(t); Store.write('tests', all.slice(0, 100)); bump('tests'); if (t.accuracy >= PASS) bump('testsPassed'); }
  function counters() { return Object.assign({ sessions: 0, tests: 0, testsPassed: 0 }, Store.read('counters', {})); }
  function bump(k) { const c = counters(); c[k]++; Store.write('counters', c); }

  /* بعد تسميع أو اختبار: تحديث الخطة أو المراجعة حسب السياق. يُرجع وصف ما حدث */
  function applyResult(ctx, from, to, acc) {
    if (ctx.plan != null) {
      if (acc >= PLAN_PASS) { completePlanDay(ctx.plan, acc); return { kind: 'plan-done' }; }
      return { kind: 'plan-retry' };
    }
    if (ctx.review) { const r = reviewDone(ctx.review, acc); return r ? { kind: 'review', review: r } : null; }
    const r = findReview(from, to);
    if (r) return { kind: 'review', review: reviewDone(r.id, acc) };
    return { kind: 'suggest' };
  }

  /* بطاقة ما بعد النتيجة (تُستخدم في التسميع والاختبار) */
  function outcomeHtml(o, from, to) {
    if (!o) return '';
    const ui = App.ui, fmt = d => ui.dateFmt.format(d);
    if (o.kind === 'plan-done') {
      const p = plan(), next = p && planDay(p);
      return `<section class="panel outcome ok">✅ <strong>أتممت ورد اليوم من خطة الحفظ.</strong> أُضيف إلى جدول المراجعة، وأول مراجعة ${fmt(addDays(Date.now(), 1))}.
        ${next ? `<a class="btn btn-sm" href="#/plan">الورد التالي</a>` : '<p>🎉 أتممت خطة الحفظ كاملة!</p>'}</section>`;
    }
    if (o.kind === 'plan-retry') return `<section class="panel outcome warn">لم يُسجَّل ورد اليوم بعد: يلزم ${Q.ar(PLAN_PASS)}٪ فأكثر. راجع أخطاءك وأعد المحاولة.</section>`;
    if (o.kind === 'review') {
      const r = o.review, days = INTERVALS[r.stage];
      return `<section class="panel outcome">🔄 <strong>سُجّلت المراجعة.</strong> المراجعة القادمة بعد ${Q.ar(days)} ${days === 1 ? 'يوم' : days <= 10 ? 'أيام' : 'يومًا'}: ${fmt(r.due)}.</section>`;
    }
    if (o.kind === 'suggest') {
      const ds = suggestedDates();
      return `<section class="panel outcome" data-outcome>
        <strong>📅 مواعيد المراجعة المقترحة لهذا المقطع</strong>
        <ul class="review-dates"><li>بعد يوم: ${fmt(ds[0])}</li><li>بعد ٣ أيام: ${fmt(ds[1])}</li><li>بعد أسبوع: ${fmt(ds[2])}</li><li>ثم تتباعد حسب مستواك</li></ul>
        <button class="btn btn-primary btn-sm" data-add-review="${from},${to}">أضفه إلى جدول المراجعة</button></section>`;
    }
    return '';
  }
  function bindOutcome(root) {
    const b = root.querySelector('[data-add-review]'); if (!b) return;
    b.addEventListener('click', () => {
      const [f, t] = b.dataset.addReview.split(',').map(Number);
      addReview(f, t);
      b.closest('[data-outcome]').innerHTML = '✅ أُضيف إلى جدول المراجعة. تجده في <a href="#/plan">الخطة والمراجعة</a>.';
    });
  }

  App.Progress = {
    outcomeHtml, bindOutcome,
    INTERVALS, PASS, PLAN_PASS, rangeLabel, dayKey, addDays, today,
    markActive, streak, setActivity, lastActivity,
    recordWords, weakAyahs, ayahErrs,
    reviews, addReview, reviewDone, removeReview, findReview, dueReviews, upcomingReviews, suggestedDates, memorizedSet, dueAyahCount,
    buildPlan, plan, setPlan, planDay, planPct, completePlanDay,
    tests, addTest, counters, bump, applyResult
  };
})();
