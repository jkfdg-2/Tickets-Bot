/* مزوّد EveryAyah.com — ملف مستقل لكل آية، يُبث مباشرة من خوادم المصدر.
   لا يستخدم أي API: الروابط ثابتة بالشكل data/<المجلد>/SSSAAA.mp3،
   وقائمة القراء مكتوبة هنا فلا تحتاج جلب فهرس من الإنترنت. */
(function () {
  const BASE = 'https://everyayah.com/data/';
  const pad = n => String(n).padStart(3, '0');

  // [المجلد, الاسم العربي, النوع, الرواية]
  const LIST = [
    ['Alafasy_128kbps', 'مشاري العفاسي', 'مرتل'],
    ['Abdul_Basit_Murattal_192kbps', 'عبدالباسط عبدالصمد', 'مرتل'],
    ['Abdul_Basit_Mujawwad_128kbps', 'عبدالباسط عبدالصمد', 'مجود'],
    ['Abdullah_Basfar_192kbps', 'عبدالله بصفر', 'مرتل'],
    ['Abdurrahmaan_As-Sudais_192kbps', 'عبدالرحمن السديس', 'مرتل'],
    ['Abu_Bakr_Ash-Shaatree_128kbps', 'أبو بكر الشاطري', 'مرتل'],
    ['Ahmed_ibn_Ali_al-Ajamy_128kbps_ketaballah.net', 'أحمد بن علي العجمي', 'مرتل'],
    ['Ghamadi_40kbps', 'سعد الغامدي', 'مرتل'],
    ['Hani_Rifai_192kbps', 'هاني الرفاعي', 'مرتل'],
    ['Husary_128kbps', 'محمود خليل الحصري', 'مرتل'],
    ['Husary_128kbps_Mujawwad', 'محمود خليل الحصري', 'مجود'],
    ['Husary_Muallim_128kbps', 'محمود خليل الحصري', 'المصحف المعلم'],
    ['Hudhaify_128kbps', 'علي بن عبدالرحمن الحذيفي', 'مرتل'],
    ['Ibrahim_Akhdar_32kbps', 'إبراهيم الأخضر', 'مرتل'],
    ['MaherAlMuaiqly128kbps', 'ماهر المعيقلي', 'مرتل'],
    ['Minshawy_Murattal_128kbps', 'محمد صديق المنشاوي', 'مرتل'],
    ['Minshawy_Mujawwad_192kbps', 'محمد صديق المنشاوي', 'مجود'],
    ['Mohammad_al_Tablaway_128kbps', 'محمد الطبلاوي', 'مرتل'],
    ['Muhammad_Ayyoub_128kbps', 'محمد أيوب', 'مرتل'],
    ['Muhammad_Jibreel_128kbps', 'محمد جبريل', 'مرتل'],
    ['Saood_ash-Shuraym_128kbps', 'سعود الشريم', 'مرتل'],
    ['Salaah_AbdulRahman_Bukhatir_128kbps', 'صلاح بو خاطر', 'مرتل'],
    ['Muhsin_Al_Qasim_192kbps', 'عبدالمحسن القاسم', 'مرتل'],
    ['Abdullaah_3awwaad_Al-Juhaynee_128kbps', 'عبدالله عواد الجهني', 'مرتل'],
    ['Salah_Al_Budair_128kbps', 'صلاح البدير', 'مرتل'],
    ['Abdullah_Matroud_128kbps', 'عبدالله المطرود', 'مرتل'],
    ['Ahmed_Neana_128kbps', 'أحمد نعينع', 'مرتل'],
    ['Muhammad_AbdulKareem_128kbps', 'محمد عبدالكريم', 'مرتل'],
    ['Khaalid_Abdullaah_al-Qahtaanee_192kbps', 'خالد القحطاني', 'مرتل'],
    ['Yasser_Ad-Dussary_128kbps', 'ياسر الدوسري', 'مرتل'],
    ['Nasser_Alqatami_128kbps', 'ناصر القطامي', 'مرتل'],
    ['Ali_Hajjaj_AlSuesy_128kbps', 'علي حجاج السويسي', 'مرتل'],
    ['Sahl_Yassin_128kbps', 'سهل ياسين', 'مرتل'],
    ['Yaser_Salamah_128kbps', 'ياسر سلامة', 'مرتل'],
    ['Akram_AlAlaqimy_128kbps', 'أكرم العلاقمي', 'مرتل'],
    ['Ali_Jaber_64kbps', 'علي جابر', 'مرتل'],
    ['Fares_Abbad_64kbps', 'فارس عباد', 'مرتل'],
    ['Ayman_Sowaid_64kbps', 'أيمن سويد', 'مرتل'],
    ['khalefa_al_tunaiji_64kbps', 'خليفة الطنيجي', 'مرتل'],
    ['mahmoud_ali_al_banna_32kbps', 'محمود علي البنا', 'مرتل'],
    ['aziz_alili_128kbps', 'عزيز عليلي', 'مرتل'],
    ['Nabil_Rifa3i_48kbps', 'نبيل الرفاعي', 'مرتل'],
    ['warsh/warsh_ibrahim_aldosary_128kbps', 'إبراهيم الدوسري', 'مرتل', 'ورش عن نافع'],
    ['warsh/warsh_yassin_al_jazaery_64kbps', 'ياسين الجزائري', 'مرتل', 'ورش عن نافع']
  ];

  const Provider = {
    id: 'everyayah',
    name: 'EveryAyah.com',
    license: 'التلاوات تُبث مباشرة من EveryAyah.com (ملف لكل آية)',

    list() {
      return LIST.map(([folder, name, style, rewaya]) => ({
        id: 'everyayah:' + folder, name, image: null,
        recordings: [{
          key: 'everyayah:' + folder, provider: 'everyayah',
          label: (rewaya || 'حفص عن عاصم') + ' - ' + style + ' (آية بآية)',
          rewaya: rewaya || 'حفص عن عاصم', style, folder,
          surahs: null, ayahMode: 'file', allowDownload: false
        }]
      }));
    },
    ayahUrl(rec, sura, ayah) { return BASE + rec.folder + '/' + pad(sura) + pad(ayah) + '.mp3'; }
  };

  App.providers = App.providers || {};
  App.providers.everyayah = Provider;
})();
