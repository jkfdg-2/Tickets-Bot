/* فهرس القراء الموحّد
   - يجمع القراء من المزوّدين المفعّلين في config.providers
   - القائمة ثابتة في ملفات المزوّدين؛ لا اتصال بأي API */
(function () {
  const collator = new Intl.Collator('ar');
  let catalog = null;          // [{id, name, image, recordings[]}]
  let byKey = new Map();       // key → {reciter, recording}
  const listeners = new Set();

  const nameKey = n => App.Q.norm.normSearch(String(n).replace(/^(الشيخ|شيخ)\s+/, '')).replace(/\s+/g, '');

  /* دمج قراء المزوّدين المختلفين تحت بطاقة واحدة بالاسم */
  function merge(groups) {
    const map = new Map();
    groups.flat().forEach(r => {
      const k = nameKey(r.name);
      if (!map.has(k)) map.set(k, { id: r.id, name: r.name, image: r.image || null, recordings: [] });
      const t = map.get(k);
      t.image = t.image || r.image || null;
      r.recordings.forEach(rec => { if (!t.recordings.some(x => x.key === rec.key)) t.recordings.push(rec); });
    });
    const images = App.config.reciterImages || {};
    const out = [...map.values()].map(r => {
      r.image = images[r.name] || r.image;
      r.canAyah = r.recordings.some(x => x.ayahMode !== 'surah');
      r.rewayat = [...new Set(r.recordings.map(x => x.rewaya).filter(Boolean))];
      r.full = r.recordings.some(x => !x.surahs);
      return r;
    });
    return out.sort((a, b) => collator.compare(a.name, b.name));
  }

  function load() {
    if (catalog) return;
    const P = App.providers, en = App.config.providers;
    const list = merge(Object.keys(en).filter(k => en[k] && P[k]).map(k => P[k].list()));
    catalog = list;
    byKey = new Map();
    list.forEach(r => r.recordings.forEach(rec => byKey.set(rec.key, { reciter: r, recording: rec })));
  }

  /* مفتاح من إصدار سابق (MP3Quran أو الملفات المحلية) ← نفس القارئ بالاسم */
  const LOCAL_OLD = { Alafasy_64kbps: 'Alafasy_128kbps', Husary_64kbps: 'Husary_128kbps',
    Abdul_Basit_Murattal_64kbps: 'Abdul_Basit_Murattal_192kbps', Maher_AlMuaiqly_64kbps: 'MaherAlMuaiqly128kbps' };
  function migrate(key) {
    const loc = /^local:(.+)$/.exec(key);
    if (loc && LOCAL_OLD[loc[1]] && byKey.has('everyayah:' + LOCAL_OLD[loc[1]])) return 'everyayah:' + LOCAL_OLD[loc[1]];
    const old = App.Store.read('reciterCatalog', null);
    const prev = old && old.data && old.data.find(r => r.recordings.some(x => x.key === key));
    const r = prev && catalog.find(x => nameKey(x.name) === nameKey(prev.name));
    return r ? r.recordings[0].key : null;
  }

  const Catalog = {
    get list() { load(); return catalog; },
    on(fn) { listeners.add(fn); return () => listeners.delete(fn); },
    load() { load(); return Promise.resolve(); },

    find(key) { load(); return byKey.get(key) || null; },

    /* القارئ الافتراضي للموقع */
    currentKey(override) {
      const k = override || App.Store.settings().reciter;
      if (this.find(k)) return k;
      const m = k && migrate(k);
      if (m) return m;
      const def = App.config.defaults.reciter;
      return this.find(def) ? def : (this.list[0] && this.list[0].recordings[0].key);
    },
    current(override) { return this.find(this.currentKey(override)); },
    select(key) { App.Store.setSetting('reciter', key); listeners.forEach(fn => fn(Catalog)); },

    /* أفضل تسجيل يدعم الآية للقارئ نفسه (للحفظ والتسميع) */
    ayahCapable(key) {
      const f = this.find(key);
      if (!f) return null;
      if (f.recording.ayahMode !== 'surah') return f;
      const alt = f.reciter.recordings.find(r => r.ayahMode !== 'surah');
      return alt ? { reciter: f.reciter, recording: alt } : null;
    },

    search(q) {
      const nq = q ? nameKey(q) : '';
      return this.list.filter(r => !nq || nameKey(r.name).includes(nq));
    },
    providerOf(rec) { return App.providers[rec.provider]; }
  };

  App.Catalog = Catalog;
})();
