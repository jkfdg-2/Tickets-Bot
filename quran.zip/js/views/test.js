/* 🎙️ اختبار الحفظ: آية بآية، الآية مخفية حتى تُتمّ قراءتها ثم تظهر مع تحديد الأخطاء */
App.views.test = {
  render(main, params) {
    const { Q, Store } = App, P = App.Progress, ui = App.ui, { esc, icons } = ui;
    ui.setTitle('اختبار الحفظ');
    const self = this;
    const supported = App.SpeechListener.supported();
    let range = Store.lastMemorizeRange() || { from: Q.gi(1, 1), to: Q.gi(1, 7) };
    if (params.from != null) range = { from: +params.from, to: params.to != null ? +params.to : +params.from };
    const ctx = { plan: params.plan != null ? +params.plan : null, review: params.review || null };
    const ctxFits = () => (ctx.plan != null || ctx.review) && range.from === +params.from && range.to === +params.to;

    showSetup();

    /* ---------------- الإعداد ---------------- */
    function showSetup() {
      const a = Q.ref(range.from), b = Q.ref(range.to);
      const recent = P.tests().slice(0, 5);
      main.innerHTML = `
        <h1 class="page-title">اختبار الحفظ 🎙️</h1>
        ${ui.memNav('test')}
        <p class="lead">الآيات مخفية. اقرأ كل آية من حفظك بالمايك، وعند إتمامها تظهر الآية الأصلية مع تحديد أخطائك، ثم انتقل للآية التالية.</p>
        ${ctxFits() ? `<p class="ctx-banner">${ctx.plan != null ? `📅 اختبار ورد اليوم ${Q.ar(ctx.plan + 1)} من خطة الحفظ` : '🔄 مراجعة مجدولة — نتيجتك تحدد موعد المراجعة القادمة'}</p>` : ''}
        <section class="panel">
          <div class="range-grid">
            <fieldset><legend>من</legend>
              <label>السورة<select data-fs>${ui.suraOptions(a.sura)}</select></label>
              <label>الآية<select data-fa>${ui.ayahOptions(a.sura, a.ayah)}</select></label>
            </fieldset>
            <fieldset><legend>إلى</legend>
              <label>السورة<select data-ts>${ui.suraOptions(b.sura)}</select></label>
              <label>الآية<select data-ta>${ui.ayahOptions(b.sura, b.ayah)}</select></label>
            </fieldset>
          </div>
          <p class="range-summary" data-summary></p>
        </section>
        <div class="cta-row">
          <button class="btn btn-primary btn-lg" data-start ${supported ? '' : 'disabled'}>${icons.mic}<span>ابدأ الاختبار</span></button>
        </div>
        ${supported ? '' : `<p class="notice">متصفحك لا يدعم التعرف على الصوت. استخدم Google Chrome أو Microsoft Edge، أو Safari على iPhone.</p>`}
        ${recent.length ? `<section class="history">
          <h2 class="section-title">آخر الاختبارات</h2>
          <ul class="rows">${recent.map(t => `
            <li class="row"><button class="row-main" data-again="${t.from},${t.to}">
              <span class="score ${t.accuracy >= 90 ? 'good' : t.accuracy >= 70 ? 'mid' : 'low'}">${Q.ar(t.accuracy)}٪</span>
              <span class="row-text"><strong>${esc(P.rangeLabel(t.from, t.to))}</strong>
              <span class="muted">${Q.ar(t.errors)} أخطاء، ${ui.dateShort.format(t.at)}</span></span></button></li>`).join('')}</ul>
        </section>` : ''}`;

      const fs = main.querySelector('[data-fs]'), fa = main.querySelector('[data-fa]');
      const ts = main.querySelector('[data-ts]'), ta = main.querySelector('[data-ta]');
      const start = main.querySelector('[data-start]');
      const update = () => {
        const from = Q.gi(+fs.value, +fa.value), to = Q.gi(+ts.value, +ta.value);
        const sum = main.querySelector('[data-summary]');
        if (to < from) { sum.innerHTML = '<span class="bad">نهاية المقطع قبل بدايته. عدّل «إلى».</span>'; start.disabled = true; return; }
        const n = to - from + 1;
        if (n > App.config.maxReciteAyahs) { sum.innerHTML = `<span class="bad">المقطع طويل. الحد الأقصى ${Q.ar(App.config.maxReciteAyahs)} آية.</span>`; start.disabled = true; return; }
        range = { from, to }; start.disabled = !supported;
        let words = 0; for (let g = from; g <= to; g++) words += Q.words(g).length;
        sum.textContent = `${Q.ar(n)} آية، ${Q.ar(words)} كلمة`;
      };
      fs.addEventListener('change', () => { fa.innerHTML = ui.ayahOptions(+fs.value, 1); if (+ts.value < +fs.value) { ts.value = fs.value; ta.innerHTML = ui.ayahOptions(+fs.value, Math.min(5, Q.sura(+fs.value).ayahs)); } update(); });
      ts.addEventListener('change', () => { ta.innerHTML = ui.ayahOptions(+ts.value, Q.sura(+ts.value).ayahs); update(); });
      fa.addEventListener('change', update); ta.addEventListener('change', update);
      update();
      start.addEventListener('click', startTest);
      main.querySelectorAll('[data-again]').forEach(b => b.addEventListener('click', () => {
        const [f, t] = b.dataset.again.split(',').map(Number); range = { from: f, to: t }; showSetup();
      }));
    }

    /* ---------------- الاختبار ---------------- */
    function startTest() {
      App.Player.stop();
      App.unlockAudio();
      const testCtx = ctxFits() ? ctx : {};
      const q = `from=${range.from}&to=${range.to}` + (testCtx.plan != null ? '&plan=' + testCtx.plan : testCtx.review ? '&review=' + testCtx.review : '');
      P.setActivity('test', 'اختبار ' + P.rangeLabel(range.from, range.to), '#/test?' + q);
      const ayahs = []; for (let g = range.from; g <= range.to; g++) ayahs.push(g);
      const strictness = Store.settings().strictness;
      const results = [];          // لكل آية: { gi, words: [{text,state,heard}] }
      let idx = -1, engine = null, state = 'idle'; // listening | revealed
      let started = 0, timerId = null, finished = false, committed = 0, listener = null;

      main.innerHTML = `
        <div class="recite-bar">
          <span class="live" data-live><span class="dot"></span><span data-status>جارٍ التحضير…</span></span>
          <span class="stat"><span class="muted">الآية</span> <strong data-pos></strong></span>
          <span class="stat"><span class="muted">الوقت</span> <strong data-time>٠:٠٠</strong></span>
          <span class="stat"><span class="muted">الأخطاء</span> <strong data-errs>٠</strong></span>
          <div class="recite-actions"><button class="btn btn-sm btn-danger" data-stop>إنهاء</button></div>
        </div>
        <p class="heard" data-heard aria-live="polite"></p>
        <article class="mushaf test-card" data-card></article>
        <div class="cta-row test-actions" data-actions></div>`;
      const card = main.querySelector('[data-card]'), actions = main.querySelector('[data-actions]');
      const heardEl = main.querySelector('[data-heard]'), status = main.querySelector('[data-status]'), live = main.querySelector('[data-live]');
      const errsEl = main.querySelector('[data-errs]');
      let wordEls = [];

      const totalErrors = () => results.reduce((s, r) => s + r.words.filter(w => w.state === 'err' || w.state === 'skip').length, 0)
        + (engine && state === 'listening' ? engine.words.filter(w => w.state === 'err' || w.state === 'skip').length : 0);

      function showAyah(i) {
        idx = i; state = 'listening';
        const gi = ayahs[i], r = Q.ref(gi);
        engine = new App.ReciteEngine([gi], {
          strictness,
          onChange(e) {
            if (state !== 'listening') return;
            if (e.type === 'error') {
              App.beep();
              const w = engine.words[e.word];
              ui.toast(e.state === 'skip' ? `فاتتك كلمة: «${w.text}»` : `خطأ — الصواب: «${w.text}»`);
              errsEl.textContent = Q.ar(totalErrors());
            }
            paint();
            if (e.type === 'complete') setTimeout(() => reveal(false), 350);
          }
        });
        main.querySelector('[data-pos]').textContent = `${Q.ar(i + 1)} / ${Q.ar(ayahs.length)}`;
        card.className = 'mushaf test-card is-locked';
        card.innerHTML = `
          <p class="test-ref">سورة ${esc(Q.sura(r.sura).name)} — الآية ${Q.ar(r.ayah)} <span class="lock" data-lock>🔒 مخفية</span></p>
          <p class="ayat quran">${Q.words(gi).map((w, k) => `<span class="w" data-w="${k}">${esc(w)}</span>`).join(' ')} ${ui.ayahMark(r.ayah)}</p>
          <p class="test-progress muted" data-prog></p>`;
        wordEls = [...card.querySelectorAll('.w')];
        engine.words.forEach((w, k) => { if (w.state === 'ok') wordEls[k].classList.add('w-ok'); });
        actions.innerHTML = `<button class="btn" data-reveal>انتهيت، أظهر الآية</button>`;
        actions.querySelector('[data-reveal]').addEventListener('click', () => reveal(true));
        heardEl.innerHTML = `<span class="muted">اقرأ الآية من حفظك…</span>`;
        paint();
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }

      function paint() {
        let read = 0;
        engine.words.forEach((w, k) => {
          const el = wordEls[k];
          el.className = 'w' + (w.state === 'ok' ? ' w-ok' : w.state === 'err' ? ' w-err' : w.state === 'skip' ? ' w-skip' : '');
          if (w.state === 'err') el.dataset.heard = w.heard ? 'قلتَ: ' + w.heard : '';
          else if (w.state === 'skip') el.dataset.heard = 'فاتتك';
          else delete el.dataset.heard;
          if (w.state !== 'pending') read++;
        });
        const p = card.querySelector('[data-prog]');
        if (p) p.textContent = state === 'listening' ? `قرأت ${Q.ar(read)} من ${Q.ar(engine.words.length)} كلمة` : '';
      }

      /* إظهار الآية بعد انتهاء القراءة (manual: ضغط المستخدم قبل الإتمام) */
      function reveal(manual) {
        if (state !== 'listening') return;
        state = 'revealed';
        engine.process(true);
        engine.words.forEach(w => { if (w.state === 'pending') { w.state = 'skip'; w.heard = null; } });
        paint();
        const gi = ayahs[idx];
        results.push({ gi, words: engine.words.map(w => ({ gi: w.gi, text: w.text, state: w.state, heard: w.heard })) });
        const errs = engine.words.filter(w => w.state === 'err' || w.state === 'skip').length;
        errsEl.textContent = Q.ar(totalErrors());
        card.classList.remove('is-locked');
        card.classList.add(errs ? 'has-errors' : 'is-perfect');
        card.querySelector('[data-lock]').textContent = errs ? `📖 ${Q.ar(errs)} ${errs === 1 ? 'خطأ' : 'أخطاء'}` : '📖 صحيحة ✓';
        heardEl.innerHTML = errs ? '<span class="bad">قارن قراءتك بالنص: الكلمات الملوّنة بالأحمر هي أخطاؤك.</span>' : '<span class="good-text">أحسنت! قراءة صحيحة.</span>';
        const last = idx === ayahs.length - 1;
        actions.innerHTML = last
          ? `<button class="btn btn-primary btn-lg" data-next>عرض النتيجة</button>`
          : `<button class="btn btn-primary btn-lg" data-next>➡️ الآية التالية</button>`;
        actions.querySelector('[data-next]').addEventListener('click', () => last ? finish() : showAyah(idx + 1));
        actions.querySelector('[data-next]').focus();
      }

      main.querySelector('[data-stop]').addEventListener('click', () => {
        // الآية الحالية تُحسب فقط إن بدأ قراءتها
        if (state === 'listening' && engine.pos > 0) reveal(true);
        finish();
      });

      listener = new App.SpeechListener({
        onFinal(alts) {
          const rest = alts.map(a => a.slice(committed));
          committed = 0;
          if (state !== 'listening') return;
          let best = rest[0], bestScore = -1;
          rest.forEach(a => { const s = engine.scoreCandidate(a); if (s > bestScore) { bestScore = s; best = a; } });
          if (best.length) engine.feedFinal(best);
          // توقّف بعد الكلمة الأخيرة: لا كلمة تالية ننتظرها، فنحسم الآن ← تظهر الآية مباشرة
          if (state === 'listening' && !engine.done && engine.pos === engine.units.length - 1 && engine.hi < engine.heard.length) engine.process(true);
          heardEl.innerHTML = `<span class="muted">سمعتُ:</span> ${esc(alts[0].slice(-12).join(' '))}`;
        },
        onInterim(words) {
          if (!words.length) return;
          const stable = words.length - 1;
          const fresh = stable > committed ? words.slice(committed, stable) : [];
          if (stable > committed) committed = stable;
          if (state !== 'listening') return;
          if (fresh.length) engine.feedFinal(fresh);
          if (state === 'listening') engine.preview(words.slice(committed));
          heardEl.innerHTML = `<span class="muted">أسمع:</span> ${esc(words.slice(-12).join(' '))}`;
        },
        onState(s) {
          if (s === 'listening') {
            status.textContent = 'أستمع إليك…'; live.classList.add('on');
            if (!started) { started = Date.now(); timerId = setInterval(() => { main.querySelector('[data-time]').textContent = ui.fmtDuration(Date.now() - started); }, 500); }
          }
          if (s === 'reconnecting') committed = 0;
        },
        onError(code) {
          const msg = {
            'not-allowed': 'لم يُسمح باستخدام المايك. فعّل الإذن من إعدادات المتصفح ثم أعد المحاولة.',
            'audio-capture': 'لم يُعثر على مايك. تأكد من توصيله.',
            'network': 'التعرف على الصوت يحتاج اتصالًا بالإنترنت.',
            'unsupported': 'متصفحك لا يدعم التعرف على الصوت.'
          }[code] || 'حدث خطأ في التعرف على الصوت (' + code + ').';
          status.textContent = 'متوقف'; live.classList.remove('on');
          heardEl.innerHTML = `<span class="bad">${esc(msg)}</span>`;
        }
      });
      listener.start();
      self.cleanup = () => { listener && listener.stop(); clearInterval(timerId); };
      showAyah(0);

      function finish() {
        if (finished) return;
        finished = true;
        listener.stop(); clearInterval(timerId);
        const duration = started ? Date.now() - started : 0;
        const all = results.flatMap(r => r.words);
        const ok = all.filter(w => w.state === 'ok').length;
        const errWords = all.filter(w => w.state === 'err' || w.state === 'skip');
        const accuracy = all.length ? Math.round(ok / all.length * 100) : 0;
        const tested = results.length;
        const complete = tested === ayahs.length;
        const summary = { from: range.from, to: range.to, ayahs: tested, total: ayahs.length, words: all.length, errors: errWords.length, accuracy, duration, at: Date.now(),
          badAyahs: results.filter(r => r.words.some(w => w.state === 'err' || w.state === 'skip')).map(r => r.gi) };
        let outcome = null;
        if (tested) {
          P.recordWords(all);
          P.addTest({ from: range.from, to: range.to, accuracy, errors: errWords.length, ayahs: tested, words: all.length, at: summary.at, duration });
          if (complete) outcome = P.applyResult(testCtx, range.from, range.to, accuracy);
        }
        showResults(summary, errWords, outcome, complete);
      }
    }

    /* ---------------- النتيجة ---------------- */
    function showResults(s, errWords, outcome, complete) {
      const grade = s.accuracy >= 95 ? 'ممتاز، حفظ متقن' : s.accuracy >= 85 ? 'جيد جدًا، راجع الأخطاء' : s.accuracy >= 70 ? 'جيد، يحتاج مراجعة' : 'يحتاج إلى مزيد من المراجعة';
      main.innerHTML = `
        <h1 class="page-title">نتيجة الاختبار</h1>
        <section class="result-hero">
          <div class="ring" style="--p:${s.accuracy}"><span>${Q.ar(s.accuracy)}٪</span></div>
          <div><strong class="grade">${s.ayahs ? grade : 'لم تُختبر أي آية'}</strong>
            <p class="muted">${esc(P.rangeLabel(s.from, s.to))}</p></div>
        </section>
        ${complete ? P.outcomeHtml(outcome, s.from, s.to) : s.ayahs ? `<p class="notice">أنهيت الاختبار قبل آخر آية (${Q.ar(s.ayahs)} من ${Q.ar(s.total)}).</p>` : ''}
        <dl class="stats">
          <div><dt>عدد الآيات</dt><dd>${Q.ar(s.ayahs)}</dd></div>
          <div><dt>عدد الكلمات</dt><dd>${Q.ar(s.words)}</dd></div>
          <div><dt>عدد الأخطاء</dt><dd class="${s.errors ? 'bad' : ''}">${Q.ar(s.errors)}</dd></div>
          <div><dt>نسبة التطابق</dt><dd>${Q.ar(s.accuracy)}٪</dd></div>
          <div><dt>مدة الاختبار</dt><dd>${ui.fmtDuration(s.duration)}</dd></div>
        </dl>
        ${s.badAyahs.length ? `
          <h2 class="section-title">الآيات التي أخطأت فيها (${Q.ar(s.badAyahs.length)})</h2>
          <div class="chips">${s.badAyahs.map(g => `<a class="chip" href="#/test?from=${g}&to=${g}">${esc(Q.shortRef(g))}</a>`).join('')}</div>
          <h2 class="section-title">الكلمات التي أخطأت فيها</h2>
          <ul class="errors">${errWords.map(e => `
            <li><span class="err-ref">${esc(Q.shortRef(e.gi))}</span>
              <span class="err-said">${e.state === 'skip' ? 'لم تقرأها' : e.heard ? 'قلتَ: ' + esc(e.heard) : 'خطأ'}</span>
              <span class="err-fix"><span class="muted">الصواب:</span> <strong class="quran-inline">${esc(e.text)}</strong></span></li>`).join('')}</ul>`
          : s.ayahs ? '<p class="empty-state"><strong>لا أخطاء. أحسنت!</strong></p>' : ''}
        <div class="cta-row">
          <button class="btn btn-primary btn-lg" data-retry>${icons.mic}<span>أعد الاختبار</span></button>
          ${s.badAyahs.length ? `<a class="btn" href="#/test?from=${s.badAyahs[0]}&to=${s.badAyahs[s.badAyahs.length - 1]}">اختبر الآيات التي أخطأت فيها</a>` : ''}
          <a class="btn" href="#/progress">لوحة التقدم</a>
        </div>`;
      P.bindOutcome(main);
      main.querySelector('[data-retry]').addEventListener('click', startTest);
      window.scrollTo(0, 0);
    }
  },
  destroy() { this.cleanup && this.cleanup(); this.cleanup = null; }
};
