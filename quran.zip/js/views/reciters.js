/* 🎙️ صفحة القراء */
App.views.reciters = {
  render(main, params) {
    const { Q, Catalog, Player } = App, ui = App.ui, { esc } = ui;
    ui.setTitle('القراء');
    const f = { q: params.q || '' };
    const picked = {}; // reciterId → recording key المختار في القائمة

    main.innerHTML = `
      <h1 class="page-title">🎙️ القراء</h1>
      <section class="current-reciter" data-current></section>
      <div class="reciter-filters">
        <input class="filter" type="search" placeholder="ابحث عن قارئ" aria-label="البحث عن قارئ" value="${esc(f.q)}" data-q>
      </div>
      <p class="hint" data-count></p>
      <div data-list></div>
      <p class="hint sources" data-sources></p>`;

    const list = main.querySelector('[data-list]');
    const avatar = (r) => r.image
      ? `<img class="avatar" src="${esc(r.image)}" alt="" loading="lazy">`
      : `<span class="avatar" style="--h:${hue(r.name)}" aria-hidden="true">${esc(initials(r.name))}</span>`;

    function drawCurrent() {
      const c = Catalog.current();
      main.querySelector('[data-current]').innerHTML = c ? `
        ${avatar(c.reciter)}
        <div class="cr-text">
          <span class="muted">القارئ الحالي للموقع</span>
          <strong>${esc(c.reciter.name)}</strong>
          <span class="muted small">${esc(c.recording.label)}</span>
        </div>` : '';
      main.querySelector('[data-sources]').innerHTML =
        `${Q.ar(Catalog.list.length)} قراء، ${Object.keys(App.config.providers).filter(k => App.config.providers[k])
          .map(k => esc(App.providers[k].license)).join('، ')}.`;
    }

    function draw() {
      const items = Catalog.search(f.q);
      const cur = Catalog.currentKey();
      main.querySelector('[data-count]').textContent = `${Q.ar(items.length)} قارئ، مرتبون أبجديًا`;
      if (!items.length) { list.innerHTML = '<p class="empty">لا يوجد قارئ يطابق البحث. جرّب اسمًا آخر أو أزل التصفية.</p>'; return; }
      let html = '', letter = '';
      items.forEach(r => {
        const L = firstLetter(r.name);
        if (L !== letter) { if (letter) html += '</ul>'; html += `<h2 class="letter">${esc(L)}</h2><ul class="rc-list">`; letter = L; }
        const recs = r.recordings;
        const chosenKey = picked[r.id] || (recs.find(x => x.key === cur) || recs[0]).key;
        const chosen = recs.find(x => x.key === chosenKey) || recs[0];
        const isCur = r.recordings.some(x => x.key === cur);
        const previewing = Player.active && Player.rec && Player.rec.key === chosen.key && Player.playing;
        html += `
          <li class="rc${isCur ? ' is-current' : ''}" data-id="${esc(r.id)}">
            ${avatar(r)}
            <div class="rc-body">
              <strong>${esc(r.name)}</strong>
              ${recs.length > 1
                ? `<select class="rc-rec" data-rec aria-label="التسجيل">${recs.map(x =>
                    `<option value="${esc(x.key)}" ${x.key === chosen.key ? 'selected' : ''}>${esc(x.label)}</option>`).join('')}</select>`
                : `<span class="muted small">${esc(chosen.label)}</span>`}
              <span class="badges"><span class="badge ok">آية بآية</span>${chosen.rewaya !== 'حفص عن عاصم' ? `<span class="badge">${esc(chosen.rewaya)}</span>` : ''}</span>
            </div>
            <div class="rc-actions">
              <button class="btn btn-sm" data-preview="${esc(chosen.key)}">${previewing ? '⏸ إيقاف' : '▶️ استماع'}</button>
              ${isCur && chosen.key === cur
                ? '<span class="btn btn-sm btn-ok" aria-current="true">✓ المختار</span>'
                : `<button class="btn btn-sm btn-primary" data-select="${esc(chosen.key)}">اختيار</button>`}
            </div>
          </li>`;
      });
      list.innerHTML = html + '</ul>';
    }

    main.querySelector('[data-q]').addEventListener('input', e => { f.q = e.target.value; draw(); });
    main.onclick = e => {
      const pv = e.target.closest('[data-preview]');
      if (pv) {
        const key = pv.dataset.preview;
        if (Player.active && Player.rec && Player.rec.key === key && Player.playing) { Player.stop(); return; }
        App.unlockAudio();
        Player.playSurah(1, { recordingKey: key });
        return;
      }
      const sel = e.target.closest('[data-select]');
      if (sel) {
        const found = Catalog.find(sel.dataset.select);
        Catalog.select(sel.dataset.select);
        ui.toast(`أصبح ${found.reciter.name} القارئ الافتراضي`);
        drawCurrent(); draw();
        if (params.back) setTimeout(() => { location.hash = decodeURIComponent(params.back); }, 400);
        return;
      }
    };
    list.addEventListener('change', e => {
      const s = e.target.closest('[data-rec]'); if (!s) return;
      picked[s.closest('[data-id]').dataset.id] = s.value; draw();
    });

    const refresh = () => { drawCurrent(); draw(); };
    this.offCat = Catalog.on(refresh);
    this.offPlayer = Player.on((p, kind) => { if (kind !== 'time') draw(); });
    refresh();

    function firstLetter(n) { return (String(n).trim()[0] || '#').replace(/[أإآٱ]/, 'ا'); }
    function initials(n) { const w = String(n).replace(/^(الشيخ|شيخ)\s+/, '').split(/\s+/); return (w[0] || '')[0] + ((w[1] || '').replace(/^ال/, '')[0] || ''); }
    function hue(n) { let h = 0; for (const c of String(n)) h = (h * 31 + c.charCodeAt(0)) % 360; return h; }
  },
  destroy() { this.offCat && this.offCat(); this.offPlayer && this.offPlayer(); }
};
