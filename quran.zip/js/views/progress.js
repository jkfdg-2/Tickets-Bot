/* 📊 لوحة التقدم */
App.views.progress = {
  render(main) {
    const { Q, Store } = App, P = App.Progress, ui = App.ui, { esc } = ui;
    ui.setTitle('لوحة التقدم');
    const mem = P.memorizedSet().size;
    const memPct = mem ? Math.max(1, Math.round(mem / Q.TOTAL * 1000) / 10) : 0;
    const c = P.counters();
    const passRate = c.tests ? Math.round(c.testsPassed / c.tests * 100) : null;
    const k = Store.khatma();
    const plan = P.plan();
    const streak = P.streak();
    const due = P.dueAyahCount();
    const tests = P.tests().slice(0, 5);
    const weak = P.weakAyahs(5);
    const fmtPct = n => Q.ar(String(n)) + '٪';

    main.innerHTML = `
      <h1 class="page-title">لوحة التقدم</h1>
      ${ui.memNav('progress')}
      <section class="result-hero">
        <div class="ring" style="--p:${memPct}"><span>${fmtPct(memPct)}</span></div>
        <div><strong class="grade">نسبة الحفظ من المصحف</strong>
          <p class="muted">${Q.ar(mem)} آية محفوظة من ${Q.ar(Q.TOTAL)}</p></div>
      </section>
      <dl class="stats dash">
        <div><dt>الآيات المحفوظة</dt><dd>${Q.ar(mem)}</dd></div>
        <div><dt>تحتاج مراجعة اليوم</dt><dd class="${due ? 'warn-text' : ''}">${Q.ar(due)}</dd></div>
        <div><dt>جلسات التسميع</dt><dd>${Q.ar(c.sessions)}</dd></div>
        <div><dt>نجاح الاختبارات</dt><dd>${passRate == null ? '—' : fmtPct(passRate)}</dd></div>
        <div><dt>نسبة الختمة</dt><dd>${k ? fmtPct(App.khatma.progress(k)) : '—'}</dd></div>
        <div><dt>الأيام المتتالية</dt><dd>${Q.ar(streak)} ${streak ? '🔥' : ''}</dd></div>
      </dl>
      <p class="hint">الآيات المحفوظة هي ما أتممته في خطة الحفظ أو أضفته إلى جدول المراجعة. الاختبار الناجح: ${Q.ar(P.PASS)}٪ فأكثر (${Q.ar(c.testsPassed)} من ${Q.ar(c.tests)}).</p>

      ${plan ? `<a class="strip" href="#/plan">
        <span class="strip-label">خطة الحفظ</span>
        <strong>${esc(P.rangeLabel(plan.from, plan.to))}</strong>
        <span class="progress"><span style="width:${P.planPct(plan)}%"></span></span>
        <span class="strip-meta">${fmtPct(P.planPct(plan))} منجز</span></a>`
        : `<a class="strip" href="#/plan"><span class="strip-label">خطة الحفظ</span><strong>أنشئ خطة حفظ يومية</strong></a>`}

      ${due ? `<a class="btn btn-primary btn-block" href="#/plan">ابدأ مراجعة اليوم (${Q.ar(P.dueReviews().length)})</a>` : ''}

      ${tests.length ? `<h2 class="section-title">آخر الاختبارات</h2>
        <ul class="rows">${tests.map(t => `
          <li class="row"><a class="row-main" href="#/test?from=${t.from}&to=${t.to}">
            <span class="score ${t.accuracy >= 90 ? 'good' : t.accuracy >= 70 ? 'mid' : 'low'}">${Q.ar(t.accuracy)}٪</span>
            <span class="row-text"><strong>${esc(P.rangeLabel(t.from, t.to))}</strong>
            <span class="muted">${Q.ar(t.errors)} أخطاء، ${ui.dateShort.format(t.at)}</span></span></a></li>`).join('')}</ul>` : ''}

      ${weak.length ? `<h2 class="section-title">أكثر الآيات خطأً</h2>
        <div class="chips">${weak.map(w => `<a class="chip" href="#/test?from=${w.gi}&to=${w.gi}">${esc(Q.shortRef(w.gi))} (${Q.ar(w.errs)})</a>`).join('')}</div>` : ''}

      ${!mem && !c.sessions && !c.tests ? `<p class="empty-state">لم تبدأ بعد. <a href="#/plan">أنشئ خطة حفظ</a> أو <a href="#/memorize">ابدأ التسميع</a>.</p>` : ''}`;
  }
};
