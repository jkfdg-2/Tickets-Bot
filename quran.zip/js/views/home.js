App.views = App.views || {};
App.views.home = {
  render(main) {
    const { Q, Store } = App, { icons, esc, setTitle } = App.ui;
    setTitle('');
    const last = Store.lastRead();
    const k = Store.khatma();
    const verse = Q.words(Q.gi(73, 4)).slice(-3).join(' '); // «وَرَتِّلِ ٱلۡقُرۡءَانَ تَرۡتِيلًا» من نص المصدر

    let wird = '';
    if (k) {
      const d = App.khatma.currentDay(k);
      wird = d ? `
        <a class="strip" href="#/wird">
          <span class="strip-label">وردك اليوم</span>
          <strong>${esc(Q.shortRef(d.fromGi))} — ${esc(Q.shortRef(d.toGi))}</strong>
          <span class="strip-meta">اليوم ${Q.ar(d.index + 1)} من ${Q.ar(k.days.length)}</span>
        </a>` : `<a class="strip" href="#/khatma"><span class="strip-label">الختمة</span><strong>أتممت ختمتك، بارك الله فيك</strong></a>`;
    }
    const P = App.Progress;
    const act = P.lastActivity();
    const activity = act ? `
      <section class="activity">
        <div><span class="strip-label">آخر نشاطك</span>
          <strong>${esc(act.label)}</strong>
          <span class="strip-meta">${App.ui.dateShort.format(act.at)}</span></div>
        <a class="btn btn-primary" href="${esc(act.href)}">متابعة</a>
      </section>` : '';
    // متابعة القراءة تظهر منفصلة فقط إن لم تكن هي آخر نشاط
    const cont = last && act && act.kind !== 'read' ? `
      <a class="strip" href="#/read?p=${last.page}&g=${last.gi}">
        <span class="strip-label">تابع القراءة</span>
        <strong>${esc(Q.shortRef(last.gi))}</strong>
        <span class="strip-meta">صفحة ${Q.ar(last.page)}</span>
      </a>` : '';
    const dueN = P.dueReviews().length, pl = P.plan(), pd = pl && P.planDay(pl);
    const memo = (dueN ? `
      <a class="strip" href="#/plan">
        <span class="strip-label">🔄 مراجعات اليوم</span>
        <strong>${Q.ar(dueN)} ${dueN === 1 ? 'مقطع' : 'مقاطع'} للمراجعة</strong>
      </a>` : '') + (pd && pd.date <= P.today() ? `
      <a class="strip" href="#/memorize?from=${pd.from}&to=${pd.to}&plan=${pd.index}">
        <span class="strip-label">📅 ورد الحفظ اليوم</span>
        <strong>${esc(P.rangeLabel(pd.from, pd.to))}</strong>
      </a>` : '');

    main.innerHTML = `
      <section class="hero">
        <p class="hero-verse quran">﴿${esc(verse)}﴾</p>
        <p class="hero-ref">المزمل: ٤</p>
        <p class="hero-sub">اقرأ، واحفظ، وسمّع بصوتك، وأتمّ ختمتك.</p>
      </section>

      ${activity}

      <section class="choices" aria-label="الأقسام الرئيسية">
        <a class="choice" href="#/read${last ? `?p=${last.page}` : ''}">
          <span class="choice-icon">${icons.book}</span>
          <span class="choice-title">قراءة القرآن</span>
          <span class="choice-desc">المصحف كاملًا مع التلاوة الصوتية</span>
        </a>
        <a class="choice" href="#/memorize">
          <span class="choice-icon">${icons.brain}</span>
          <span class="choice-title">حفظ القرآن</span>
          <span class="choice-desc">حدّد مقطعك وسمّع بالمايك</span>
        </a>
        <a class="choice" href="#/khatma">
          <span class="choice-icon">${icons.trophy}</span>
          <span class="choice-title">ختم القرآن</span>
          <span class="choice-desc">خطة يومية تناسب وقتك</span>
        </a>
      </section>

      ${cont || wird || memo ? `<section class="strips">${memo}${cont}${wird}</section>` : ''}

      <nav class="quick" aria-label="روابط سريعة">
        <a href="#/plan">خطة الحفظ</a>
        <a href="#/test">اختبار الحفظ 🎙️</a>
        <a href="#/progress">لوحة التقدم</a>
        <a href="#/surahs">السور</a>
        <a href="#/juz">الأجزاء</a>
        <a href="#/search">البحث</a>
        <a href="#/reciters">القراء</a>
        <a href="#/favorites">المفضلة</a>
      </nav>
    `;
  }
};
