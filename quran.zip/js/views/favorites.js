App.views.favorites = {
  render(main, params) {
    const { Q, Store } = App, { esc, icons, setTitle } = App.ui;
    setTitle('المفضلة');
    const tab = params.t || 'ayah';
    const f = Store.favorites();
    const count = t => f[t].length ? ` <span class="count">${Q.ar(f[t].length)}</span>` : '';
    let items = '';
    if (tab === 'ayah') items = f.ayah.map(x => `
      <li class="fav-item">
        <a href="#/read?g=${x.id}"><span class="result-ref">${esc(Q.refLabel(x.id))}</span><p class="quran">${esc(Q.text(x.id))}</p></a>
        <button class="icon-btn" data-rm="${x.id}" aria-label="إزالة">${icons.trash}</button>
      </li>`).join('');
    if (tab === 'surah') items = f.surah.map(x => `
      <li class="fav-item row-like">
        <a href="#/read?s=${x.id}"><strong>سورة ${esc(Q.sura(x.id).name)}</strong> <span class="muted">${Q.ar(Q.sura(x.id).ayahs)} آية</span></a>
        <button class="icon-btn" data-rm="${x.id}" aria-label="إزالة">${icons.trash}</button>
      </li>`).join('');
    if (tab === 'page') items = f.page.map(x => `
      <li class="fav-item row-like">
        <a href="#/read?p=${x.id}"><strong>صفحة ${Q.ar(x.id)}</strong> <span class="muted">${esc(Q.shortRef(Q.pageRange(x.id)[0]))}، الجزء ${Q.ar(Q.juzOf(Q.pageRange(x.id)[0]))}</span></a>
        <button class="icon-btn" data-rm="${x.id}" aria-label="إزالة">${icons.trash}</button>
      </li>`).join('');
    const emptyMsg = { ayah: 'اضغط على أي آية أثناء القراءة ثم اختر «أضف للمفضلة».', surah: 'اضغط النجمة بجانب السورة في فهرس السور.', page: 'اضغط النجمة في شريط القراءة لحفظ الصفحة.' }[tab];

    main.innerHTML = `
      <h1 class="page-title">المفضلة</h1>
      <div class="seg" role="tablist">
        <a role="tab" href="#/favorites?t=ayah" aria-selected="${tab === 'ayah'}">الآيات${count('ayah')}</a>
        <a role="tab" href="#/favorites?t=surah" aria-selected="${tab === 'surah'}">السور${count('surah')}</a>
        <a role="tab" href="#/favorites?t=page" aria-selected="${tab === 'page'}">الصفحات${count('page')}</a>
      </div>
      <p class="hint">تُحفظ المفضلة على جهازك فقط.</p>
      ${items ? `<ul class="favs">${items}</ul>` : `<div class="empty-state"><p>${emptyMsg}</p><a class="btn btn-primary" href="#/read">افتح المصحف</a></div>`}`;
    main.onclick = e => {
      const b = e.target.closest('[data-rm]'); if (!b) return;
      Store.toggleFav(tab, +b.dataset.rm);
      this.render(main, params);
    };
  }
};
