/* صفحة الحفظ + جلسة التسميع بالمايك + النتيجة */
App.views.memorize = {
  render(main, params) {
    const { Q, Store } = App;
    const ui = App.ui, { esc, icons } = ui;
    ui.setTitle('حفظ القرآن');
    const self = this;

    // النطاق الافتراضي
    let range = Store.lastMemorizeRange() || { from: Q.gi(1, 1), to: Q.gi(1, 7) };
    if (params.from != null) {
      const f = +params.from, r = Q.ref(f);
      range = { from: f, to: params.to != null ? +params.to : Math.min(f + 4, Q.gi(r.sura, Q.sura(r.sura).ayahs)) };
    }
    // السياق: ورد من خطة الحفظ أو مراجعة مجدولة
    const P = App.Progress;
    const ctx = { plan: params.plan != null ? +params.plan : null, review: params.review || null };
    const ctxFits = () => ctx.plan == null && !ctx.review ? false : range.from === +params.from && range.to === +params.to;
    let mode = Store.read('memorizeMode', 'show'); // show | hide

    const supported = App.SpeechListener.supported();
    const canRecord = App.VoiceRecorder.supported();
    let recordVoice = Store.read('recordVoice', true);
    let urls = [];
    const blobUrl = blob => { const u = URL.createObjectURL(blob); urls.push(u); return u; };
    const freeUrls = () => { urls.forEach(u => URL.revokeObjectURL(u)); urls = []; };

    showSetup();

    /* ---------------- الإعداد ---------------- */
    function showSetup() {
      freeUrls();
      const a = Q.ref(range.from), b = Q.ref(range.to);
      const hist = Store.reciteHistory().slice(0, 5);
      main.innerHTML = `
        <h1 class="page-title">حفظ القرآن</h1>
        ${ui.memNav('memorize')}
        ${ctxFits() ? `<p class="ctx-banner">${ctx.plan != null ? `📅 ورد اليوم ${Q.ar(ctx.plan + 1)} من خطة الحفظ — أتمّه بنسبة ${Q.ar(P.PLAN_PASS)}٪ فأكثر ليُسجَّل` : '🔄 مراجعة مجدولة — نتيجتك تحدد موعد المراجعة القادمة'}</p>` : ''}
        <section class="panel">
          <div class="range-grid">
            <fieldset>
              <legend>من</legend>
              <label>السورة<select data-fs>${ui.suraOptions(a.sura)}</select></label>
              <label>الآية<select data-fa>${ui.ayahOptions(a.sura, a.ayah)}</select></label>
            </fieldset>
            <fieldset>
              <legend>إلى</legend>
              <label>السورة<select data-ts>${ui.suraOptions(b.sura)}</select></label>
              <label>الآية<select data-ta>${ui.ayahOptions(b.sura, b.ayah)}</select></label>
            </fieldset>
          </div>
          <p class="range-summary" data-summary></p>
        </section>

        <div class="mode-switch" role="radiogroup" aria-label="وضع الحفظ">
          <button role="radio" data-mode="show" aria-checked="${mode === 'show'}">${icons.eye}<span>إظهار الآيات</span></button>
          <button role="radio" data-mode="hide" aria-checked="${mode === 'hide'}">${icons.eyeOff}<span>إخفاء الآيات</span></button>
        </div>

        <section class="panel listen-panel" data-listen-panel></section>

        <div class="cta-row">
          <button class="btn btn-primary btn-lg" data-start ${supported ? '' : 'disabled'}>${icons.mic}<span>ابدأ التسميع</span></button>
        </div>
        ${canRecord ? `<label class="switch"><input type="checkbox" data-rec-toggle ${recordVoice ? 'checked' : ''}> سجّل تلاوتي صوتيًا لأستمع إليها بعد التسميع</label>` : ''}
        ${supported ? '' : `<p class="notice">متصفحك لا يدعم التعرف على الصوت. استخدم Google Chrome أو Microsoft Edge على الكمبيوتر أو Android، أو Safari على iPhone.</p>`}

        <article class="mushaf passage${mode === 'hide' ? ' is-hidden' : ''}" data-passage></article>

        ${hist.length ? `<section class="history">
          <h2 class="section-title">آخر جلسات التسميع</h2>
          <ul class="rows">${hist.map(h => `
            <li class="row">
              <button class="row-main" data-again="${h.from},${h.to}">
                <span class="score ${h.accuracy >= 90 ? 'good' : h.accuracy >= 70 ? 'mid' : 'low'}">${Q.ar(h.accuracy)}٪</span>
                <span class="row-text"><strong>${esc(Q.shortRef(h.from))} إلى ${esc(Q.shortRef(h.to))}</strong>
                <span class="muted">${Q.ar(h.errors)} أخطاء، ${ui.dateShort.format(h.at)}</span></span>
              </button>
              ${h.rec ? `<button class="icon-btn" data-rec-play="${h.at}" aria-label="استمع لتسجيلك" title="استمع لتسجيلك">${icons.play}</button>` : ''}
            </li>`).join('')}</ul>
        </section>` : ''}
      `;

      const fs = main.querySelector('[data-fs]'), fa = main.querySelector('[data-fa]');
      const ts = main.querySelector('[data-ts]'), ta = main.querySelector('[data-ta]');
      const update = () => {
        let from = Q.gi(+fs.value, +fa.value), to = Q.gi(+ts.value, +ta.value);
        const sum = main.querySelector('[data-summary]');
        const startBtn = main.querySelector('[data-start]');
        if (to < from) {
          sum.innerHTML = '<span class="bad">نهاية المقطع قبل بدايته. عدّل «إلى».</span>';
          startBtn.disabled = true; main.querySelector('[data-passage]').innerHTML = ''; return;
        }
        const n = to - from + 1;
        if (n > App.config.maxReciteAyahs) {
          sum.innerHTML = `<span class="bad">المقطع طويل (${Q.ar(n)} آية). الحد الأقصى ${Q.ar(App.config.maxReciteAyahs)} آية.</span>`;
          startBtn.disabled = true; return;
        }
        startBtn.disabled = !supported;
        range = { from, to };
        Store.setMemorizeRange(range);
        let words = 0; for (let g = from; g <= to; g++) words += Q.words(g).length;
        sum.textContent = `${Q.ar(n)} آية، ${Q.ar(words)} كلمة`;
        renderPassage(main.querySelector('[data-passage]'), from, to, null);
        drawListen();
      };
      fs.addEventListener('change', () => { fa.innerHTML = ui.ayahOptions(+fs.value, 1); if (+ts.value < +fs.value) { ts.value = fs.value; ta.innerHTML = ui.ayahOptions(+fs.value, Math.min(5, Q.sura(+fs.value).ayahs)); } update(); });
      ts.addEventListener('change', () => { ta.innerHTML = ui.ayahOptions(+ts.value, Q.sura(+ts.value).ayahs); update(); });
      fa.addEventListener('change', update); ta.addEventListener('change', update);
      update();

      main.querySelectorAll('[data-mode]').forEach(b => b.addEventListener('click', () => {
        mode = b.dataset.mode; Store.write('memorizeMode', mode);
        main.querySelectorAll('[data-mode]').forEach(x => x.setAttribute('aria-checked', x === b));
        main.querySelector('[data-passage]').classList.toggle('is-hidden', mode === 'hide');
      }));
      drawListen();
      main.querySelector('[data-passage]').addEventListener('click', e => {
        const b = e.target.closest('[data-play-gi]'); if (!b) return;
        playAyah(+b.dataset.playGi, false);
      });
      main.querySelector('[data-start]').addEventListener('click', startSession);
      main.querySelectorAll('[data-again]').forEach(b => b.addEventListener('click', () => {
        const [f, t] = b.dataset.again.split(',').map(Number); range = { from: f, to: t }; showSetup();
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }));
      const recToggle = main.querySelector('[data-rec-toggle]');
      if (recToggle) recToggle.addEventListener('change', () => { recordVoice = recToggle.checked; Store.write('recordVoice', recordVoice); });
      main.querySelectorAll('[data-rec-play]').forEach(b => b.addEventListener('click', () => openRecording(+b.dataset.recPlay)));
    }

    /* ---------- تسجيلات المستخدم ---------- */
    function recordingHtml(url, blob, at) {
      return `<audio controls preload="metadata" src="${url}"></audio>
        <div class="rec-actions">
          <a class="btn btn-sm" href="${url}" download="تسميع-${at}.${App.Recordings.ext(blob)}">⬇️ تحميل</a>
          <button class="btn btn-sm btn-danger" data-rec-del="${at}">${icons.trash}<span>حذف التسجيل</span></button>
        </div>`;
    }
    function bindDelete(root, at, onDone) {
      root.querySelector('[data-rec-del]').addEventListener('click', async () => {
        if (!confirm('حذف هذا التسجيل؟')) return;
        root.querySelector('audio').pause();
        await App.Recordings.remove(at);
        Store.write('reciteHistory', Store.reciteHistory().map(h => h.at === at ? Object.assign(h, { rec: false }) : h));
        ui.toast('حُذف التسجيل'); onDone();
      });
    }
    async function openRecording(at) {
      const h = Store.reciteHistory().find(x => x.at === at);
      const blob = await App.Recordings.get(at);
      if (!blob) {
        Store.write('reciteHistory', Store.reciteHistory().map(x => x.at === at ? Object.assign(x, { rec: false }) : x));
        ui.toast('لم يعد التسجيل محفوظًا على هذا الجهاز'); showSetup(); return;
      }
      App.Player.stop();
      ui.openSheet(`
        <h3 class="sheet-title">تسجيلك: ${esc(Q.shortRef(h.from))} إلى ${esc(Q.shortRef(h.to))}</h3>
        <p class="muted small">${ui.dateShort.format(at)}، النتيجة ${Q.ar(h.accuracy)}٪</p>
        <div class="rec-box">${recordingHtml(blobUrl(blob), blob, at)}</div>`, sheet => {
        bindDelete(sheet, at, () => { ui.closeSheet(); showSetup(); });
      });
    }

    /* ---------- الاستماع للقارئ قبل الحفظ ---------- */
    function memReciter() {
      return App.Catalog.ayahCapable(App.Catalog.currentKey(Store.read('memorizeReciter', null)));
    }
    function playAyah(gi, repeat) {
      const m = memReciter();
      if (!m) { ui.toast('اختر قارئًا يدعم تشغيل الآية'); openPicker(); return; }
      App.unlockAudio();
      App.Player.repeatAyah = !!repeat; App.Player.repeatSurah = false;
      App.Player.play(gi, repeat ? gi : gi, { recordingKey: m.recording.key });
    }
    function drawListen() {
      const box = main.querySelector('[data-listen-panel]'); if (!box) return;
      const m = memReciter();
      let opts = '';
      for (let g = range.from; g <= range.to; g++) opts += `<option value="${g}">${esc(Q.shortRef(g))}</option>`;
      box.innerHTML = `
        <div class="lp-head">
          <span class="muted">القارئ للاستماع</span>
          <strong>${m ? esc(m.reciter.name) : 'لم يُختر'}</strong>
          <button class="btn btn-sm" data-pick>تغيير</button>
        </div>
        ${m ? `<span class="muted small">${esc(m.recording.label)}</span>` : '<p class="notice">القارئ الحالي لا يدعم تشغيل آية بآية. اختر قارئًا آخر للاستماع أثناء الحفظ.</p>'}
        <div class="lp-row">
          <select data-lp-ayah aria-label="الآية">${opts}</select>
          <button class="btn btn-primary" data-lp-play>${icons.play}<span>تشغيل الآية</span></button>
          <button class="btn" data-lp-rep>🔁<span>كرّر الآية</span></button>
          <button class="btn" data-lp-all>استمع للمقطع كاملًا</button>
        </div>
        <p class="hint">يمكنك أيضًا الضغط على رقم أي آية في النص لسماعها.</p>`;
      const sel = box.querySelector('[data-lp-ayah]');
      box.querySelector('[data-pick]').addEventListener('click', openPicker);
      box.querySelector('[data-lp-play]').addEventListener('click', () => playAyah(+sel.value, false));
      box.querySelector('[data-lp-rep]').addEventListener('click', () => playAyah(+sel.value, true));
      box.querySelector('[data-lp-all]').addEventListener('click', () => {
        const mm = memReciter(); if (!mm) { openPicker(); return; }
        App.unlockAudio(); App.Player.repeatAyah = false;
        App.Player.play(range.from, range.to, { recordingKey: mm.recording.key });
      });
    }
    function openPicker() {
      const all = [];
      App.Catalog.list.forEach(r => r.recordings.filter(x => x.ayahMode !== 'surah').forEach(x => all.push({ r, x })));
      const cur = memReciter();
      ui.openSheet(`
        <h3 class="sheet-title">اختر القارئ للاستماع أثناء الحفظ</h3>
        <input class="filter" type="search" placeholder="ابحث عن قارئ" data-ps>
        <ul class="picker" data-pl></ul>
        <a class="btn btn-ghost btn-block" href="#/reciters">كل القراء</a>`, sheet => {
        const ul = sheet.querySelector('[data-pl]');
        const draw = q => {
          const nq = Q.norm.normSearch(q || '');
          ul.innerHTML = all.filter(o => !nq || Q.norm.normSearch(o.r.name).includes(nq)).slice(0, 120).map(o => `
            <li><button data-k="${esc(o.x.key)}" class="${cur && cur.recording.key === o.x.key ? 'on' : ''}">
              <strong>${esc(o.r.name)}</strong><span class="muted small">${esc(o.x.label)}</span></button></li>`).join('')
            || '<li class="empty">لا نتائج</li>';
        };
        draw('');
        sheet.querySelector('[data-ps]').addEventListener('input', e => draw(e.target.value));
        ul.addEventListener('click', e => {
          const b = e.target.closest('[data-k]'); if (!b) return;
          Store.write('memorizeReciter', b.dataset.k);
          ui.closeSheet(); drawListen();
          ui.toast('سيُستخدم هذا القارئ في الحفظ');
        });
      });
    }

    /* عرض المقطع كلمات منفصلة */
    function renderPassage(el, from, to, engine) {
      let html = '', w = 0, lastSura = null;
      for (let gi = from; gi <= to; gi++) {
        const r = Q.ref(gi);
        if (r.sura !== lastSura) {
          if (lastSura !== null) html += '</p>';
          html += `<h3 class="passage-sura">سورة ${esc(Q.sura(r.sura).name)}</h3><p class="ayat quran">`;
          lastSura = r.sura;
        }
        Q.words(gi).forEach(word => { html += `<span class="w" data-w="${w++}">${esc(word)}</span> `; });
        html += (engine ? ui.ayahMark(r.ayah) : `<button class="ayah-play" data-play-gi="${gi}" title="استمع للآية">${ui.ayahMark(r.ayah)}</button>`) + ' ';
      }
      el.innerHTML = html + '</p>';
    }

    /* ---------------- جلسة التسميع ---------------- */
    function startSession() {
      App.Player.stop();
      App.unlockAudio();
      const ayahs = []; for (let g = range.from; g <= range.to; g++) ayahs.push(g);
      const sessionCtx = ctxFits() ? ctx : {};
      const q = `from=${range.from}&to=${range.to}` + (sessionCtx.plan != null ? '&plan=' + sessionCtx.plan : sessionCtx.review ? '&review=' + sessionCtx.review : '');
      P.setActivity('memorize', 'حفظ ' + P.rangeLabel(range.from, range.to), '#/memorize?' + q);
      const settings = Store.settings();
      let wordEls = [];
      let prevState = [];
      let started = 0, timerId = null, finished = false;
      let listener = null;
      const recorder = canRecord && recordVoice ? new App.VoiceRecorder() : null;

      const engine = new App.ReciteEngine(ayahs, {
        strictness: settings.strictness,
        onChange(e) {
          if (e.type === 'error') { App.beep(); errCount.textContent = Q.ar(countErrors()); }
          if (e.type === 'progress' || e.type === 'preview' || e.type === 'error') paint();
          if (e.type === 'complete' && !finished) setTimeout(() => finish(true), 600);
        }
      });

      main.innerHTML = `
        <div class="recite-bar" data-bar>
          <span class="live" data-live><span class="dot"></span><span data-status>جارٍ التحضير…</span></span>
          <span class="stat"><span class="muted">الوقت</span> <strong data-time>٠:٠٠</strong></span>
          <span class="stat"><span class="muted">الأخطاء</span> <strong data-errs>٠</strong></span>
          <span class="rec-badge" data-rec-badge hidden>● يُسجَّل</span>
          <div class="recite-actions">
            <button class="icon-btn" data-toggle-mode aria-label="إظهار/إخفاء الآيات" title="إظهار/إخفاء الآيات">${mode === 'hide' ? icons.eye : icons.eyeOff}</button>
            <button class="btn btn-sm" data-hint title="أظهر الكلمة التالية">تلميح</button>
            <button class="btn btn-sm btn-danger" data-stop>إنهاء</button>
          </div>
        </div>
        <p class="heard" data-heard aria-live="polite">ابدأ القراءة من: <strong class="quran-inline">${esc(Q.words(range.from)[0])}</strong></p>
        <article class="mushaf passage recite${mode === 'hide' ? ' is-hidden' : ''}" data-passage></article>
      `;
      const passage = main.querySelector('[data-passage]');
      renderPassage(passage, range.from, range.to, engine);
      wordEls = [...passage.querySelectorAll('.w')];
      prevState = engine.words.map(() => '');
      engine.words.forEach((w, i) => { if (w.state === 'ok') wordEls[i].classList.add('w-ok'); });
      const errCount = main.querySelector('[data-errs]');
      const status = main.querySelector('[data-status]');
      const live = main.querySelector('[data-live]');
      const heardEl = main.querySelector('[data-heard]');

      function countErrors() { return engine.words.filter(w => w.state === 'err' || w.state === 'skip').length; }

      function paint() {
        const cur = engine.currentWord;
        const prevEnd = engine.previewPos < engine.units.length ? engine.units[engine.previewPos].w : engine.words.length;
        engine.words.forEach((w, i) => {
          let cls = 'w';
          if (w.state === 'ok') cls += ' w-ok';
          else if (w.state === 'err') cls += ' w-err';
          else if (w.state === 'skip') cls += ' w-skip';
          else if (i === cur && engine.previewPos === engine.pos) cls += ' w-current';
          else if (i >= cur && i < prevEnd) cls += ' w-preview';
          else if (i === prevEnd) cls += ' w-current';
          if (w.hinted) cls += ' w-hint';
          if (cls !== prevState[i]) {
            const el = wordEls[i];
            el.className = cls;
            if (w.state === 'err') el.dataset.heard = w.heard ? 'قلتَ: ' + w.heard : '';
            else if (w.state === 'skip') el.dataset.heard = 'فاتتك';
            else delete el.dataset.heard;
            prevState[i] = cls;
          }
        });
        // إبقاء الكلمة الحالية ظاهرة
        const target = wordEls[Math.min(prevEnd, wordEls.length - 1)];
        if (target) {
          const r = target.getBoundingClientRect();
          if (r.top < 150 || r.bottom > innerHeight - 120) target.scrollIntoView({ block: 'center', behavior: 'smooth' });
        }
      }

      main.querySelector('[data-toggle-mode]').addEventListener('click', e => {
        mode = mode === 'hide' ? 'show' : 'hide'; Store.write('memorizeMode', mode);
        passage.classList.toggle('is-hidden', mode === 'hide');
        e.currentTarget.innerHTML = mode === 'hide' ? icons.eye : icons.eyeOff;
      });
      main.querySelector('[data-hint]').addEventListener('click', () => { const w = engine.hint(); if (w >= 0) { prevState[w] = ''; paint(); } });
      main.querySelector('[data-stop]').addEventListener('click', () => finish(false));

      // الحكم الفوري: كلمات النتيجة المؤقتة تُعتمد فور أن يتلوها كلام آخر (عدا الكلمة الأخيرة لأنها قد تتغير)،
      // فيظهر الخطأ أثناء القراءة دون انتظار توقف المستخدم ووصول النتيجة النهائية.
      let committed = 0;
      listener = new App.SpeechListener({
        onFinal(alts) {
          // اختيار أفضل بديل يطابق النص المنتظر (لما لم يُعتمد بعد)
          const rest = alts.map(a => a.slice(committed));
          let best = rest[0], bestScore = -1;
          rest.forEach(a => { const s = engine.scoreCandidate(a); if (s > bestScore) { bestScore = s; best = a; } });
          committed = 0;
          if (best.length) engine.feedFinal(best);
          heardEl.innerHTML = `<span class="muted">سمعتُ:</span> ${esc(alts[0].slice(-12).join(' '))}`;
        },
        onInterim(words) {
          if (!words.length) return;
          const stable = words.length - 1;
          if (stable > committed) { engine.feedFinal(words.slice(committed, stable)); committed = stable; }
          engine.preview(words.slice(committed));
          heardEl.innerHTML = `<span class="muted">أسمع:</span> ${esc(words.slice(-12).join(' '))}`;
        },
        onState(s) {
          if (s === 'listening') {
            status.textContent = 'أستمع إليك…'; live.classList.add('on');
            if (!started) { started = Date.now(); timerId = setInterval(tick, 500); }
          }
          if (s === 'reconnecting') { status.textContent = 'أستمع إليك…'; committed = 0; }
        },
        onError(code) {
          // بعض الأجهزة لا تسمح بالتسجيل والتعرف على الصوت معًا: نوقف التسجيل ونكمل التسميع
          if (code === 'audio-capture' && recorder && recorder.active) {
            recorder.stop(); recBadge.hidden = true;
            ui.toast('أُوقف التسجيل الصوتي لأن جهازك لا يسمح به أثناء التسميع');
            return; // المستمع يعيد تشغيل نفسه تلقائيًا بعد انتهاء الجلسة الحالية
          }
          const msg = {
            'not-allowed': 'لم يُسمح باستخدام المايك. فعّل الإذن من إعدادات المتصفح (رمز القفل بجانب العنوان) ثم أعد المحاولة.',
            'service-not-allowed': 'خدمة التعرف على الصوت غير متاحة في هذا المتصفح.',
            'audio-capture': 'لم يُعثر على مايك. تأكد من توصيله.',
            'network': 'التعرف على الصوت يحتاج اتصالًا بالإنترنت في هذا المتصفح.',
            'unsupported': 'متصفحك لا يدعم التعرف على الصوت.'
          }[code] || 'حدث خطأ في التعرف على الصوت (' + code + ').';
          status.textContent = 'متوقف'; live.classList.remove('on');
          heardEl.innerHTML = `<span class="bad">${esc(msg)}</span>`;
        }
      });
      const recBadge = main.querySelector('[data-rec-badge]');
      listener.start().then(ok => {
        if (!ok || !recorder || finished) return;
        recorder.start().then(on => {
          if (finished) { recorder.stop(); return; }
          recBadge.hidden = !on;
          if (!on) ui.toast('تعذّر بدء التسجيل الصوتي، والتسميع مستمر');
        });
      });
      self.cleanup = () => { listener && listener.stop(); recorder && recorder.stop(); clearInterval(timerId); freeUrls(); };

      function tick() { main.querySelector('[data-time]').textContent = ui.fmtDuration(Date.now() - started); }

      async function finish() {
        if (finished) return;
        finished = true;
        listener.stop(); clearInterval(timerId);
        const blob = recorder ? await recorder.stop() : null;
        const res = engine.finish();
        const duration = started ? Date.now() - started : 0;
        const at = Date.now();
        const result = Object.assign(res, { ayahs: ayahs.length, duration, from: range.from, to: range.to, at, blob });
        if (res.ok + res.errors.length > 0) {
          let rec = false;
          if (blob) rec = await App.Recordings.save(at, blob).then(() => true, () => false);
          Store.addRecite({ from: range.from, to: range.to, accuracy: res.accuracy, errors: res.errors.length, at, duration, rec });
          result.saved = rec;
          P.recordWords(engine.words);
          P.bump('sessions');
          if (!res.unread) result.outcome = P.applyResult(sessionCtx, range.from, range.to, res.accuracy);
        }
        showResults(result);
      }
    }

    /* ---------------- النتيجة ---------------- */
    function showResults(r) {
      const grade = r.accuracy >= 95 ? 'ممتاز، حفظ متقن' : r.accuracy >= 85 ? 'جيد جدًا، راجع الأخطاء' : r.accuracy >= 70 ? 'جيد، يحتاج مراجعة' : 'يحتاج إلى مزيد من المراجعة';
      main.innerHTML = `
        <h1 class="page-title">نتيجة التسميع</h1>
        <section class="result-hero">
          <div class="ring" style="--p:${r.accuracy}"><span>${Q.ar(r.accuracy)}٪</span></div>
          <div>
            <strong class="grade">${grade}</strong>
            <p class="muted">${esc(Q.shortRef(r.from))} إلى ${esc(Q.shortRef(r.to))}</p>
          </div>
        </section>
        ${P.outcomeHtml(r.outcome, r.from, r.to)}
        <dl class="stats">
          <div><dt>الآيات</dt><dd>${Q.ar(r.ayahs)}</dd></div>
          <div><dt>الكلمات</dt><dd>${Q.ar(r.words)}</dd></div>
          <div><dt>الأخطاء</dt><dd class="${r.errors.length ? 'bad' : ''}">${Q.ar(r.errors.length)}</dd></div>
          <div><dt>نسبة التطابق</dt><dd>${Q.ar(r.accuracy)}٪</dd></div>
          <div><dt>المدة</dt><dd>${ui.fmtDuration(r.duration)}</dd></div>
          ${r.unread ? `<div><dt>لم تُقرأ</dt><dd>${Q.ar(r.unread)}</dd></div>` : ''}
        </dl>
        ${r.errors.length ? `
          <h2 class="section-title">الكلمات التي أخطأت فيها</h2>
          <ul class="errors">${r.errors.map(e => `
            <li>
              <span class="err-ref">${esc(Q.shortRef(e.gi))}</span>
              <span class="err-said">${e.state === 'skip' ? 'لم تقرأها' : e.heard ? 'قلتَ: ' + esc(e.heard) : 'خطأ'}</span>
              <span class="err-fix"><span class="muted">الصواب:</span> <strong class="quran-inline">${esc(e.text)}</strong></span>
            </li>`).join('')}</ul>` : r.ok === 0 ? `<p class="notice">لم يُسمع صوتك. تأكد أن المايك يعمل وأنك تقرأ بصوت واضح، ثم أعد المحاولة.</p>`
          : r.unread ? `<p class="empty-state">لا أخطاء فيما قرأته، لكنك توقفت قبل نهاية المقطع.</p>` : `<p class="empty-state"><strong>لا أخطاء. أحسنت!</strong></p>`}
        ${r.blob ? `
          <h2 class="section-title">استمع لتلاوتك</h2>
          <section class="panel rec-box" data-rec-box>${recordingHtml(blobUrl(r.blob), r.blob, r.at)}
            <p class="hint">${r.saved ? 'حُفظ التسجيل على جهازك، وتجده في «آخر جلسات التسميع».' : 'هذا التسجيل لم يُحفظ؛ حمّله إن أردت الاحتفاظ به.'}</p>
          </section>` : ''}
        <div class="cta-row">
          <button class="btn btn-primary btn-lg" data-retry>${icons.mic}<span>أعد التسميع</span></button>
          <button class="btn" data-new>مقطع جديد</button>
        </div>
        <p class="hint">التعرف على الصوت آلي وقد يخطئ أحيانًا في التلاوة المجوّدة؛ إن ظهر خطأ وأنت متأكد من قراءتك، يمكنك تغيير «دقة التسميع» من الإعدادات.</p>`;
      P.bindOutcome(main);
      const recBox = main.querySelector('[data-rec-box]');
      if (recBox) {
        if (r.saved) bindDelete(recBox, r.at, () => { recBox.previousElementSibling.remove(); recBox.remove(); });
        else recBox.querySelector('[data-rec-del]').remove();
      }
      main.querySelector('[data-retry]').addEventListener('click', () => { freeUrls(); startSession(); });
      main.querySelector('[data-new]').addEventListener('click', showSetup);
      window.scrollTo(0, 0);
    }
  },
  destroy() { this.cleanup && this.cleanup(); this.cleanup = null; }
};
