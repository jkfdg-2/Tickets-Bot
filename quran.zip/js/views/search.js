App.views.search = {
  render(main, params) {
    const { Q } = App, { esc, setTitle } = App.ui;
    setTitle('البحث');
    main.innerHTML = `
      <h1 class="page-title">البحث في القرآن</h1>
      <form class="search-box" role="search" data-form>
        <input type="search" name="q" placeholder="كلمة، أو جزء من آية، أو اسم سورة، أو ٢:٢٥٥" aria-label="نص البحث" value="${esc(params.q || '')}" autofocus>
        <button class="btn btn-primary">بحث</button>
      </form>
      <p class="hint">يمكنك الكتابة بدون تشكيل، والبحث يتجاوز فروق الرسم العثماني.</p>
      <div data-results></div>`;
    const out = main.querySelector('[data-results]');
    const form = main.querySelector('[data-form]');
    form.addEventListener('submit', e => {
      e.preventDefault();
      const q = form.q.value.trim();
      history.replaceState(null, '', '#/search?q=' + encodeURIComponent(q));
      run(q);
    });
    let timer;
    form.q.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(() => run(form.q.value.trim()), 250); });
    if (params.q) run(params.q);

    function toLatin(s) { return s.replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)); }

    function run(q) {
      if (!q) { out.innerHTML = ''; return; }
      let html = '';
      const lq = toLatin(q);

      // مرجع مباشر: ٢:٢٥٥ أو "البقرة 255"
      let m = lq.match(/^(\d{1,3})\s*[:：\/\-]\s*(\d{1,3})$/);
      let refGi = null;
      if (m) { const s = +m[1], a = +m[2]; if (s >= 1 && s <= 114 && a >= 1 && a <= Q.sura(s).ayahs) refGi = Q.gi(s, a); }
      m = lq.match(/^(?:سورة\s+)?(.+?)\s+(\d{1,3})$/);
      if (!refGi && m) {
        const n = Q.norm.normSearch(m[1]);
        const s = Q.suras.find(x => Q.norm.normSearch(x.name) === n);
        if (s && +m[2] >= 1 && +m[2] <= s.ayahs) refGi = Q.gi(s.n, +m[2]);
      }
      if (refGi != null) {
        html += `<h2 class="section-title">انتقال مباشر</h2>
          <a class="result" href="#/read?g=${refGi}"><span class="result-ref">${esc(Q.refLabel(refGi))}</span><p class="quran">${esc(Q.text(refGi))}</p></a>`;
      }

      // أسماء السور
      const nq = Q.norm.normSearch(q.replace(/^سورة\s+/, ''));
      const suras = nq ? Q.suras.filter(s => Q.norm.normSearch(s.name).includes(nq)) : [];
      if (suras.length) {
        html += `<h2 class="section-title">السور</h2><div class="chips">` +
          suras.map(s => `<a class="chip" href="#/read?s=${s.n}">سورة ${esc(s.name)}</a>`).join('') + '</div>';
      }

      // نص الآيات
      const tokens = q.split(/\s+/).map(t => Q.norm.normSearch(t)).filter(Boolean);
      const idx = Q.searchIndex();
      const hits = [];
      if (tokens.join('').length >= 2) {
        for (let gi = 0; gi < idx.length; gi++) {
          const m = Q.matchVerse(idx[gi], tokens);
          if (m) hits.push([gi, m]);
        }
      }

      html += `<h2 class="section-title">الآيات <span class="muted">(${Q.ar(hits.length)} نتيجة)</span></h2>`;
      if (!hits.length) html += `<p class="empty">لا توجد آيات تطابق «${esc(q)}». جرّب كلمة أقصر.</p>`;
      const LIMIT = 150;
      html += hits.slice(0, LIMIT).map(([gi, m]) => {
        const words = Q.words(gi).map((w, i) => m.includes(i) ? `<mark>${esc(w)}</mark>` : esc(w)).join(' ');
        return `<a class="result" href="#/read?g=${gi}"><span class="result-ref">${esc(Q.refLabel(gi))}</span><p class="quran">${words}</p></a>`;
      }).join('');
      if (hits.length > LIMIT) html += `<p class="hint">تُعرض أول ${Q.ar(LIMIT)} نتيجة. أضف كلمة أخرى لتضييق البحث.</p>`;
      out.innerHTML = html;
    }
  }
};
