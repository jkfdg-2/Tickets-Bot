App.views.reader = {
  render(main, params) {
    const { Q, Store, Player } = App;
    const ui = App.ui, { esc, icons } = ui;

    // تحديد الصفحة من المعطيات
    let page;
    if (params.g != null) page = Q.pageOf(+params.g);
    else if (params.s) page = Q.pageOf(Q.gi(+params.s, +(params.a || 1)));
    else if (params.j) page = Q.pageOf(Q.juzRange(+params.j)[0]);
    else if (params.p) page = +params.p;
    else { const l = Store.lastRead(); page = l ? l.page : 1; }
    page = Math.min(Math.max(page || 1, 1), Q.PAGES);

    const [from, to] = Q.pageRange(page);
    const focusGi = params.g != null ? +params.g : null;
    Store.setLastRead(page, focusGi != null ? focusGi : from);
    const r0 = Q.ref(from);
    ui.setTitle('صفحة ' + Q.ar(page));

    const wirdTo = params.wirdTo ? +params.wirdTo : null;
    const link = p => `#/read?p=${p}${wirdTo ? `&wirdTo=${wirdTo}` : ''}`;

    // بناء نص الصفحة
    let html = '', openBlock = false;
    for (let gi = from; gi <= to; gi++) {
      const r = Q.ref(gi);
      if (r.ayah === 1) {
        if (openBlock) html += '</p>';
        const s = Q.sura(r.sura);
        html += `<header class="sura-head">
            <span class="sura-meta">${s.type === 'm' ? 'مكية' : 'مدنية'}</span>
            <h2>سورة ${esc(s.name)}</h2>
            <span class="sura-meta">${Q.ar(s.ayahs)} آية
              <button class="icon-btn mini" data-play-sura="${r.sura}" aria-label="تشغيل سورة ${esc(s.name)}" title="تشغيل السورة">${icons.play}</button></span>
          </header>`;
        if (r.sura !== 1 && r.sura !== 9) html += `<p class="bismillah quran">${esc(Q.bismillah())}</p>`;
        html += '<p class="ayat quran">'; openBlock = true;
      } else if (!openBlock) { html += '<p class="ayat quran">'; openBlock = true; }
      const fav = Store.isFav('ayah', gi) ? ' is-fav' : '';
      html += `<span class="ayah${fav}${gi === focusGi ? ' is-focus' : ''}" data-gi="${gi}" tabindex="0" role="button">${esc(Q.text(gi))}${ui.ayahMark(r.ayah)}</span> `;
    }
    if (openBlock) html += '</p>';

    const pageFav = Store.isFav('page', page);
    const wirdBanner = wirdTo ? `
      <div class="wird-banner">
        <span>ورد اليوم: حتى صفحة ${Q.ar(wirdTo)}</span>
        ${page >= wirdTo ? '<a class="btn btn-sm btn-primary" href="#/wird">إنهاء الورد</a>' : `<span class="muted">بقي ${Q.ar(wirdTo - page)} صفحة</span>`}
      </div>` : '';

    main.innerHTML = `
      ${wirdBanner}
      <div class="reader-bar">
        <button class="bar-title" data-goto>
          <strong>سورة ${esc(Q.sura(r0.sura).name)}</strong>
          <span>الجزء ${Q.ar(Q.juzOf(from))}، صفحة ${Q.ar(page)}</span>
          <svg viewBox="0 0 24 24" class="caret"><path d="m6 9 6 6 6-6"/></svg>
        </button>
        <div class="bar-tools">
          <button class="icon-btn" data-font="-1" aria-label="تصغير الخط" title="تصغير الخط"><span class="aa">أ-</span></button>
          <button class="icon-btn" data-font="1" aria-label="تكبير الخط" title="تكبير الخط"><span class="aa">أ+</span></button>
          <button class="icon-btn${pageFav ? ' on' : ''}" data-fav-page aria-pressed="${pageFav}" aria-label="حفظ الصفحة في المفضلة" title="المفضلة">${icons.star}</button>
          <button class="icon-btn" data-play-page aria-label="تشغيل تلاوة الصفحة" title="تشغيل التلاوة">${icons.play}</button>
        </div>
      </div>

      <article class="mushaf" aria-label="صفحة ${page}">${html}
        <footer class="page-no">${Q.ar(page)}</footer>
      </article>

      <nav class="pager" aria-label="التنقل بين الصفحات">
        ${page < Q.PAGES ? `<a class="btn" href="${link(page + 1)}" rel="next">${icons.chevNext}<span>الصفحة التالية</span></a>` : '<span></span>'}
        ${page > 1 ? `<a class="btn btn-ghost" href="${link(page - 1)}" rel="prev"><span>السابقة</span>${icons.chevPrev}</a>` : '<span></span>'}
      </nav>
    `;

    // التمرير إلى الآية المطلوبة
    if (focusGi != null) {
      const el = main.querySelector(`[data-gi="${focusGi}"]`);
      el && setTimeout(() => el.scrollIntoView({ block: 'center', behavior: 'smooth' }), 60);
    }

    // الخط
    main.querySelectorAll('[data-font]').forEach(b => b.addEventListener('click', () => {
      const s = Store.settings();
      const size = Math.min(56, Math.max(18, s.fontSize + 2 * +b.dataset.font));
      Store.setSetting('fontSize', size);
      document.documentElement.style.setProperty('--quran-size', size + 'px');
    }));

    main.querySelector('[data-fav-page]').addEventListener('click', e => {
      const on = Store.toggleFav('page', page);
      e.currentTarget.classList.toggle('on', on);
      e.currentTarget.setAttribute('aria-pressed', on);
      ui.toast(on ? 'أُضيفت الصفحة إلى المفضلة' : 'أُزيلت الصفحة من المفضلة');
    });
    main.querySelector('[data-play-page]').addEventListener('click', () => { App.unlockAudio(); Player.play(from); });
    main.querySelectorAll('[data-play-sura]').forEach(b => b.addEventListener('click', e => {
      e.stopPropagation(); App.unlockAudio(); Player.playSurah(+b.dataset.playSura);
    }));
    main.querySelector('[data-goto]').addEventListener('click', () => openGoto(page, from));

    // الضغط على آية
    const onAyah = e => {
      const el = e.target.closest('.ayah');
      if (!el) return;
      if (e.type === 'keydown' && e.key !== 'Enter' && e.key !== ' ') return;
      e.preventDefault();
      openAyahSheet(+el.dataset.gi, el);
    };
    main.querySelector('.mushaf').addEventListener('click', onAyah);
    main.querySelector('.mushaf').addEventListener('keydown', onAyah);

    // تمييز الآية المُتلاة + قلب الصفحة تلقائيًا
    const sync = p => {
      main.querySelectorAll('.ayah.playing').forEach(x => x.classList.remove('playing'));
      if (p.gi < 0) return;
      const el = main.querySelector(`[data-gi="${p.gi}"]`);
      if (el) {
        el.classList.add('playing');
        const r = el.getBoundingClientRect();
        if (r.top < 90 || r.bottom > innerHeight - 140) el.scrollIntoView({ block: 'center', behavior: 'smooth' });
      } else if (p.gi === to + 1) {
        location.hash = link(page + 1);
      }
    };
    this.off = Player.on(sync);
    sync(Player);

    // لوحة المفاتيح: يسار = التالية (اتجاه المصحف)
    this.keys = e => {
      if (e.target.closest('input, select, textarea')) return;
      if (e.key === 'ArrowLeft' && page < Q.PAGES) location.hash = link(page + 1);
      if (e.key === 'ArrowRight' && page > 1) location.hash = link(page - 1);
    };
    document.addEventListener('keydown', this.keys);

    // السحب على الجوال
    let x0 = null;
    const m = main.querySelector('.mushaf');
    m.addEventListener('touchstart', e => { x0 = e.touches[0].clientX; }, { passive: true });
    m.addEventListener('touchend', e => {
      if (x0 == null) return;
      const dx = e.changedTouches[0].clientX - x0; x0 = null;
      if (Math.abs(dx) < 80) return;
      if (dx > 0 && page < Q.PAGES) location.hash = link(page + 1); // سحب لليمين = التالية كتقليب المصحف
      if (dx < 0 && page > 1) location.hash = link(page - 1);
    });

    function openAyahSheet(gi, el) {
      const fav = Store.isFav('ayah', gi);
      ui.openSheet(`
        <h3 class="sheet-title">${esc(Q.refLabel(gi))}</h3>
        <p class="sheet-verse quran">${esc(Q.text(gi))}</p>
        <div class="sheet-actions">
          <button class="btn btn-primary" data-a="play">${icons.play}<span>استمع من هنا</span></button>
          <button class="btn" data-a="fav">${icons.star}<span>${fav ? 'إزالة من المفضلة' : 'أضف للمفضلة'}</span></button>
          <button class="btn" data-a="copy">${icons.copy}<span>نسخ الآية</span></button>
          <button class="btn" data-a="mem">${icons.mic}<span>سمّع من هذه الآية</span></button>
          <button class="btn" data-a="rep">🔁<span>كرّر هذه الآية</span></button>
          <button class="btn" data-a="sura">▶️<span>شغّل السورة كاملة</span></button>
        </div>
        <p class="sheet-note">القارئ: <strong>${esc((App.Catalog.current() || { reciter: { name: '' } }).reciter.name)}</strong> <a href="#/reciters">تغيير</a></p>`, sheet => {
        sheet.addEventListener('click', ev => {
          const a = ev.target.closest('[data-a]'); if (!a) return;
          const act = a.dataset.a;
          if (act === 'play') { App.unlockAudio(); Player.repeatAyah = false; Player.play(gi); }
          if (act === 'rep') { App.unlockAudio(); Player.repeatAyah = true; Player.repeatSurah = false; Player.play(gi, gi); }
          if (act === 'sura') { App.unlockAudio(); Player.playSurah(Q.ref(gi).sura); }
          if (act === 'fav') { const on = Store.toggleFav('ayah', gi); el.classList.toggle('is-fav', on); ui.toast(on ? 'أُضيفت الآية إلى المفضلة' : 'أُزيلت من المفضلة'); }
          if (act === 'copy') {
            const t = `${Q.text(gi)} [${Q.shortRef(gi)}]`;
            (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(() => ui.toast('نُسخت الآية'), () => ui.toast('تعذّر النسخ'));
          }
          if (act === 'mem') { location.hash = `#/memorize?from=${gi}`; return; }
          ui.closeSheet();
        });
      });
      Store.setLastRead(page, gi);
    }

    function openGoto(page, from) {
      const r = Q.ref(from);
      ui.openSheet(`
        <h3 class="sheet-title">انتقال سريع</h3>
        <div class="form-grid">
          <label>السورة<select data-s>${ui.suraOptions(r.sura)}</select></label>
          <label>الآية<select data-a>${ui.ayahOptions(r.sura, r.ayah)}</select></label>
          <button class="btn btn-primary span-2" data-go-ayah>اذهب إلى الآية</button>
          <label>الجزء<select data-j>${ui.juzOptions(Q.juzOf(from))}</select></label>
          <label>الصفحة<input type="number" inputmode="numeric" min="1" max="604" value="${page}" data-p></label>
          <button class="btn" data-go-juz>اذهب للجزء</button>
          <button class="btn" data-go-page>اذهب للصفحة</button>
        </div>
        <a class="btn btn-ghost btn-block" href="#/surahs">فهرس السور والأجزاء</a>`, sheet => {
        const sS = sheet.querySelector('[data-s]'), sA = sheet.querySelector('[data-a]');
        sS.addEventListener('change', () => { sA.innerHTML = ui.ayahOptions(+sS.value, 1); });
        sheet.querySelector('[data-go-ayah]').addEventListener('click', () => { location.hash = `#/read?g=${Q.gi(+sS.value, +sA.value)}`; });
        sheet.querySelector('[data-go-juz]').addEventListener('click', () => { location.hash = `#/read?j=${sheet.querySelector('[data-j]').value}`; });
        sheet.querySelector('[data-go-page]').addEventListener('click', () => {
          const p = Math.min(604, Math.max(1, +sheet.querySelector('[data-p]').value || 1));
          location.hash = `#/read?p=${p}`;
        });
      });
    }
  },
  destroy() {
    this.off && this.off();
    this.keys && document.removeEventListener('keydown', this.keys);
  }
};
