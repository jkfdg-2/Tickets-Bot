App.views.settings = {
  render(main) {
    const { Store, Q } = App, ui = App.ui, { esc } = ui;
    ui.setTitle('الإعدادات');
    const s = Store.settings();
    const opt = (v, cur, label) => `<option value="${v}" ${v === cur ? 'selected' : ''}>${label}</option>`;
    main.innerHTML = `
      <h1 class="page-title">الإعدادات</h1>
      <section class="panel settings">
        <label class="field">المظهر
          <select data-k="theme">${opt('auto', s.theme, 'تلقائي حسب الجهاز')}${opt('light', s.theme, 'فاتح')}${opt('dark', s.theme, 'داكن (الوضع الليلي)')}</select>
        </label>
        <label class="field">حجم خط المصحف: <strong data-size>${Q.ar(s.fontSize)}</strong>
          <input type="range" min="18" max="56" step="2" value="${s.fontSize}" data-k="fontSize">
        </label>
        <p class="quran sample" data-sample>${esc(Q.text(0))}</p>
        <div class="field">القارئ
          <a class="setting-link" href="#/reciters"><strong>${esc((App.Catalog.current() || { reciter: { name: '—' } }).reciter.name)}</strong><span>تغيير القارئ</span></a>
        </div>
        <label class="field">دقة التسميع
          <select data-k="strictness">
            ${opt('strict', s.strictness, 'صارمة: كل اختلاف يُحسب خطأ')}
            ${opt('medium', s.strictness, 'متوسطة (موصى بها)')}
            ${opt('lenient', s.strictness, 'متسامحة: تتجاوز أخطاء التعرف الآلي')}
          </select>
        </label>
        <label class="switch"><input type="checkbox" data-k="errorSound" ${s.errorSound ? 'checked' : ''}> صوت تنبيه عند الخطأ</label>
      </section>
      <section class="panel">
        <h2 class="section-title">بياناتك</h2>
        <p class="muted">كل بياناتك (آخر موضع، المفضلة، الختمة، سجل التسميع وتسجيلاتك الصوتية) محفوظة على هذا الجهاز فقط. لا حسابات ولا خوادم.</p>
        <button class="btn btn-danger" data-clear>حذف كل البيانات المحفوظة</button>
      </section>
      <section class="panel about">
        <h2 class="section-title">المصادر</h2>
        <p class="muted">نص المصحف: الرسم العثماني برواية حفص عن عاصم من موسوعة القرآن الكريم (QuranEnc.com)، وترقيم الصفحات والأجزاء وفق مصحف المدينة (٦٠٤ صفحات). التلاوات تُبث مباشرة من EveryAyah.com (ملف لكل آية)، ولا تُنسخ أي تسجيلات إلى الموقع.</p>
      </section>`;

    main.querySelectorAll('[data-k]').forEach(el => el.addEventListener(el.type === 'range' ? 'input' : 'change', () => {
      const k = el.dataset.k;
      const v = el.type === 'checkbox' ? el.checked : el.type === 'range' ? +el.value : el.value;
      Store.setSetting(k, v);
      if (k === 'theme') App.applyTheme(v);
      if (k === 'fontSize') {
        document.documentElement.style.setProperty('--quran-size', v + 'px');
        main.querySelector('[data-size]').textContent = Q.ar(v);
      }
    }));
    main.querySelector('[data-clear]').addEventListener('click', () => {
      if (confirm('سيُحذف كل ما حفظته على هذا الجهاز. هل أنت متأكد؟')) {
        Store.clearAll(); App.Recordings.clear(); App.applyTheme('auto');
        document.documentElement.style.removeProperty('--quran-size');
        ui.toast('حُذفت البيانات'); this.render(main);
      }
    });
  }
};
