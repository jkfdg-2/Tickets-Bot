/* 🧠 خطة الحفظ الذكية + 🔄 المراجعة */
App.views.plan = {
  render(main) {
    const { Q } = App, P = App.Progress, ui = App.ui, { esc, icons } = ui;
    ui.setTitle('خطة الحفظ والمراجعة');
    const self = this;
    const p = P.plan();
    if (p) renderActive(p); else renderNew();

    /* ---------- إنشاء خطة ---------- */
    function renderNew() {
      const last = App.Store.lastMemorizeRange();
      const a = Q.ref(last ? last.from : Q.gi(1, 1));
      const bSura = a.sura, today = new Date(); today.setHours(0, 0, 0, 0);
      const iso = d => new Date(d - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
      main.innerHTML = `
        <h1 class="page-title">خطة الحفظ</h1>
        ${ui.memNav('plan')}
        <p class="lead">حدّد المقطع الذي تريد حفظه وعدد الآيات يوميًا، وسننشئ لك خطة حفظ ومراجعة تلقائية.</p>
        <section class="panel">
          <div class="range-grid">
            <fieldset><legend>من</legend>
              <label>السورة<select data-fs>${ui.suraOptions(a.sura)}</select></label>
              <label>الآية<select data-fa>${ui.ayahOptions(a.sura, a.ayah)}</select></label>
            </fieldset>
            <fieldset><legend>إلى</legend>
              <label>السورة<select data-ts>${ui.suraOptions(bSura)}</select></label>
              <label>الآية<select data-ta>${ui.ayahOptions(bSura, Q.sura(bSura).ayahs)}</select></label>
            </fieldset>
          </div>
          <div class="form-grid plan-form">
            <label class="field">عدد الآيات يوميًا<input type="number" inputmode="numeric" min="1" max="100" value="5" data-per></label>
            <label class="field">تاريخ البداية<input type="date" value="${iso(today)}" data-start></label>
          </div>
        </section>
        <section class="panel plan-preview" data-preview></section>
        <button class="btn btn-primary btn-lg btn-block" data-go>أنشئ الخطة</button>
        ${reviewsHtml()}`;

      const fs = main.querySelector('[data-fs]'), fa = main.querySelector('[data-fa]');
      const ts = main.querySelector('[data-ts]'), ta = main.querySelector('[data-ta]');
      const per = main.querySelector('[data-per]'), startIn = main.querySelector('[data-start]');
      const go = main.querySelector('[data-go]');
      let built = null;
      const preview = () => {
        const from = Q.gi(+fs.value, +fa.value), to = Q.gi(+ts.value, +ta.value);
        const n = Math.max(1, Math.min(100, Math.round(+per.value || 1)));
        const box = main.querySelector('[data-preview]');
        if (to < from) { box.innerHTML = '<p class="bad">نهاية المقطع قبل بدايته. عدّل «إلى».</p>'; go.disabled = true; built = null; return; }
        const start = startIn.value ? new Date(startIn.value + 'T00:00:00').getTime() : today.getTime();
        built = P.buildPlan(from, to, n, start);
        go.disabled = false;
        const days = built.days;
        box.innerHTML = `
          <dl class="stats">
            <div><dt>الآيات</dt><dd>${Q.ar(to - from + 1)}</dd></div>
            <div><dt>الأيام</dt><dd>${Q.ar(days.length)}</dd></div>
            <div><dt>البداية</dt><dd class="sm">${ui.dateFmt.format(built.start)}</dd></div>
            <div><dt>النهاية</dt><dd class="sm">${ui.dateFmt.format(ui.addDays(built.start, days.length - 1))}</dd></div>
          </dl>
          <ol class="plan-mini">${days.slice(0, 5).map((d, i) => `<li><strong>اليوم ${Q.ar(i + 1)}:</strong> ${esc(P.rangeLabel(d.from, d.to))}</li>`).join('')}
            ${days.length > 5 ? `<li class="muted">… و${Q.ar(days.length - 5)} أيام أخرى</li>` : ''}</ol>`;
      };
      fs.addEventListener('change', () => { fa.innerHTML = ui.ayahOptions(+fs.value, 1); if (+ts.value < +fs.value) { ts.value = fs.value; ta.innerHTML = ui.ayahOptions(+fs.value, Q.sura(+fs.value).ayahs); } preview(); });
      ts.addEventListener('change', () => { ta.innerHTML = ui.ayahOptions(+ts.value, Q.sura(+ts.value).ayahs); preview(); });
      [fa, ta, startIn].forEach(x => x.addEventListener('change', preview));
      per.addEventListener('input', preview);
      preview();
      go.addEventListener('click', () => {
        if (!built) return;
        P.setPlan(built);
        P.setActivity('plan', 'خطة حفظ ' + P.rangeLabel(built.from, built.to), '#/plan');
        ui.toast('أُنشئت خطة الحفظ');
        self.render(main);
      });
      bindReviews();
    }

    /* ---------- الخطة الحالية ---------- */
    function renderActive(p) {
      const pct = P.planPct(p), cur = P.planDay(p);
      const doneCount = p.days.filter(d => d.done).length;
      const late = cur ? ui.daysBetween(cur.date, Date.now()) : 0;
      const q = d => `from=${d.from}&to=${d.to}&plan=${d.index}`;
      main.innerHTML = `
        <h1 class="page-title">خطة الحفظ</h1>
        ${ui.memNav('plan')}
        <section class="result-hero">
          <div class="ring" style="--p:${pct}"><span>${Q.ar(pct)}٪</span></div>
          <div>
            <strong class="grade">${cur ? `أنجزت ${Q.ar(doneCount)} من ${Q.ar(p.days.length)} يومًا` : 'أتممت خطة الحفظ، بارك الله فيك'}</strong>
            <p class="muted">${esc(P.rangeLabel(p.from, p.to))}، ${Q.ar(p.perDay)} آيات يوميًا</p>
          </div>
        </section>
        ${cur ? `
          <section class="wird-card today-card">
            <p class="wird-kicker">${cur.date > P.today() ? `📅 يبدأ ${ui.dateFmt.format(cur.date)}` : '📖 ورد الحفظ اليوم'}</p>
            <h2>${esc(P.rangeLabel(cur.from, cur.to))}</h2>
            <p class="muted">اليوم ${Q.ar(cur.index + 1)} من ${Q.ar(p.days.length)}</p>
            ${late > 0 ? `<p class="notice">أنت متأخر ${Q.ar(late)} ${late === 1 ? 'يومًا' : 'أيام'} عن الخطة. لا بأس، تابع من حيث وقفت.</p>` : ''}
            <div class="cta-row">
              <a class="btn btn-primary btn-lg" href="#/memorize?${q(cur)}">${icons.mic}<span>احفظ وسمّع</span></a>
              <a class="btn btn-lg" href="#/test?${q(cur)}">🎙️ اختبرني</a>
            </div>
            <p class="hint">يُسجَّل الورد عند إتمامه بنسبة ${Q.ar(P.PLAN_PASS)}٪ فأكثر، ثم يدخل جدول المراجعة تلقائيًا.</p>
          </section>` : ''}
        ${reviewsHtml()}
        <h2 class="section-title">أيام الخطة</h2>
        <ol class="plan">${p.days.map((d, i) => `
          <li class="${d.done ? 'done' : cur && i === cur.index ? 'current' : ''}">
            <button class="check" data-i="${i}" aria-pressed="${d.done}" aria-label="اليوم ${i + 1}: ${d.done ? 'منجز' : 'غير منجز'}">${d.done ? '✓' : Q.ar(i + 1)}</button>
            <a href="#/memorize?from=${d.from}&to=${d.to}&plan=${i}">
              <strong>${esc(P.rangeLabel(d.from, d.to))}</strong>
              <span class="muted">${ui.dateShort.format(ui.addDays(p.start, i))}${d.acc != null ? `، النتيجة ${Q.ar(d.acc)}٪` : ''}</span>
            </a>
          </li>`).join('')}</ol>
        <button class="btn btn-ghost btn-block" data-reset>حذف الخطة والبدء من جديد</button>`;

      main.querySelectorAll('[data-i]').forEach(b => b.addEventListener('click', () => {
        const pl = P.plan(), d = pl.days[+b.dataset.i];
        if (d.done) { d.done = false; d.doneAt = null; P.setPlan(pl); }
        else P.completePlanDay(+b.dataset.i, null);
        self.render(main);
      }));
      main.querySelector('[data-reset]').addEventListener('click', () => {
        if (confirm('حذف خطة الحفظ؟ يبقى جدول المراجعة كما هو.')) { P.setPlan(null); self.render(main); }
      });
      bindReviews();
    }

    /* ---------- المراجعة ---------- */
    function reviewsHtml() {
      const due = P.dueReviews(), next = P.upcomingReviews(5), weak = P.weakAyahs(5);
      if (!due.length && !next.length && !weak.length) return '';
      return `
        <h2 class="section-title">🔄 المراجعة</h2>
        ${due.length ? `<ul class="rows">${due.map(r => `
          <li class="row">
            <a class="row-main" href="#/test?from=${r.from}&to=${r.to}&review=${r.id}">
              <span class="score ${r.weight ? 'low' : 'mid'}">${r.weight ? '⚠️' : '🔄'}</span>
              <span class="row-text"><strong>${esc(P.rangeLabel(r.from, r.to))}</strong>
              <span class="muted">${r.late > 0 ? `متأخرة ${Q.ar(r.late)} ${r.late === 1 ? 'يومًا' : 'أيام'}` : 'مستحقة اليوم'}${r.weight ? `، فيها ${Q.ar(r.weight)} أخطاء سابقة` : ''}${r.lastAcc != null ? `، آخر نتيجة ${Q.ar(r.lastAcc)}٪` : ''}</span></span>
            </a>
            <a class="btn btn-sm btn-primary" href="#/test?from=${r.from}&to=${r.to}&review=${r.id}">راجع</a>
          </li>`).join('')}</ul>` : '<p class="empty-state">لا مراجعات مستحقة اليوم ✅</p>'}
        ${next.length ? `<h3 class="sub-title">القادمة</h3><ul class="rows">${next.map(r => `
          <li class="row"><span class="row-text"><strong>${esc(P.rangeLabel(r.from, r.to))}</strong>
            <span class="muted">${ui.dateFmt.format(r.due)}</span></span>
            <button class="icon-btn" data-del-review="${r.id}" aria-label="حذف من المراجعة" title="حذف من المراجعة">${icons.trash}</button></li>`).join('')}</ul>` : ''}
        ${weak.length ? `<h3 class="sub-title">آيات تحتاج تركيزًا</h3><p class="hint">الآيات التي يكثر فيها خطؤك، وتُقدَّم مراجعاتها أولًا.</p>
          <ul class="rows">${weak.map(w => `
          <li class="row"><a class="row-main" href="#/test?from=${w.gi}&to=${w.gi}">
            <span class="score low">${Q.ar(w.errs)}</span>
            <span class="row-text"><strong>${esc(Q.shortRef(w.gi))}</strong><span class="muted">${Q.ar(w.errs)} أخطاء — اضغط لاختبارها</span></span></a></li>`).join('')}</ul>` : ''}`;
    }
    function bindReviews() {
      main.querySelectorAll('[data-del-review]').forEach(b => b.addEventListener('click', () => {
        if (confirm('حذف هذا المقطع من جدول المراجعة؟')) { P.removeReview(b.dataset.delReview); self.render(main); }
      }));
    }
  }
};
