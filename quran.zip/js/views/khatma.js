/* الختمة + ورد اليوم */
(function () {
  const Q = App.Q;

  /* تقسيم ٦٠٤ صفحة على عدد الأيام بالتساوي */
  function buildPlan(daysCount, startTs) {
    const base = Math.floor(Q.PAGES / daysCount), extra = Q.PAGES % daysCount;
    const days = [];
    let p = 1;
    for (let i = 0; i < daysCount; i++) {
      const n = base + (i < extra ? 1 : 0);
      const fromPage = p, toPage = p + n - 1;
      days.push({
        fromPage, toPage,
        fromGi: Q.pageRange(fromPage)[0], toGi: Q.pageRange(toPage)[1],
        done: false, doneAt: null
      });
      p += n;
    }
    return { start: App.ui.dayKey(startTs), days, created: Date.now() };
  }
  function currentDay(k) {
    const i = k.days.findIndex(d => !d.done);
    return i < 0 ? null : Object.assign({ index: i }, k.days[i]);
  }
  function progress(k) {
    const pages = k.days.filter(d => d.done).reduce((s, d) => s + d.toPage - d.fromPage + 1, 0);
    return Math.round(pages / Q.PAGES * 100);
  }
  function juzSpan(d) {
    const a = Q.juzOf(d.fromGi), b = Q.juzOf(d.toGi);
    return a === b ? `الجزء ${Q.ar(a)}` : `الأجزاء ${Q.ar(a)} إلى ${Q.ar(b)}`;
  }
  App.khatma = { buildPlan, currentDay, progress, juzSpan };

  App.views.khatma = {
    render(main) {
      const { Store } = App, ui = App.ui, { esc } = ui;
      ui.setTitle('ختم القرآن');
      const k = Store.khatma();
      if (!k) return renderNew();
      renderActive(k);

      function renderNew() {
        let chosen = 30;
        const today = new Date(); today.setHours(0, 0, 0, 0);
        const iso = d => new Date(d - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
        main.innerHTML = `
          <h1 class="page-title">ختم القرآن</h1>
          <p class="lead">اختر المدة التي تريد أن تختم فيها، وسنقسّم لك المصحف إلى وِرد يومي.</p>
          <div class="durations" role="radiogroup" aria-label="مدة الختمة">
            ${App.config.khatmaPresets.map(d => `<button role="radio" data-d="${d}" aria-checked="${d === chosen}"><strong>${Q.ar(d)}</strong><span>${d === 3 || d === 7 || d === 10 ? 'أيام' : 'يومًا'}</span></button>`).join('')}
            <button role="radio" data-d="custom" aria-checked="false"><strong>…</strong><span>مدة مخصصة</span></button>
          </div>
          <label class="custom-days" hidden data-custom>عدد الأيام
            <input type="number" inputmode="numeric" min="1" max="604" value="60">
          </label>
          <label class="field">تاريخ البداية <input type="date" value="${iso(today)}" data-start></label>
          <section class="panel plan-preview" data-preview></section>
          <button class="btn btn-primary btn-lg btn-block" data-go>ابدأ الختمة</button>`;

        const customBox = main.querySelector('[data-custom]');
        const customIn = customBox.querySelector('input');
        const startIn = main.querySelector('[data-start]');
        const days = () => chosen === 'custom' ? Math.min(604, Math.max(1, Math.round(+customIn.value || 1))) : chosen;
        const preview = () => {
          const n = days();
          const start = startIn.value ? new Date(startIn.value + 'T00:00:00') : today;
          const end = ui.addDays(start, n - 1);
          const ppd = Q.PAGES / n;
          main.querySelector('[data-preview]').innerHTML = `
            <dl class="stats">
              <div><dt>الورد اليومي</dt><dd>${ppd >= 20 ? Q.ar(+(30 / n).toFixed(1)) + ' جزء' : Q.ar(Math.ceil(ppd)) + ' صفحة'}</dd></div>
              <div><dt>الصفحات يوميًا</dt><dd>${Q.ar(Math.floor(ppd))}${Q.PAGES % n ? '–' + Q.ar(Math.ceil(ppd)) : ''}</dd></div>
              <div><dt>الأجزاء يوميًا</dt><dd>${Q.ar(+(30 / n).toFixed(2))}</dd></div>
              <div><dt>البداية</dt><dd class="sm">${ui.dateFmt.format(start)}</dd></div>
              <div><dt>النهاية</dt><dd class="sm">${ui.dateFmt.format(end)}</dd></div>
            </dl>`;
        };
        main.querySelectorAll('[data-d]').forEach(b => b.addEventListener('click', () => {
          chosen = b.dataset.d === 'custom' ? 'custom' : +b.dataset.d;
          main.querySelectorAll('[data-d]').forEach(x => x.setAttribute('aria-checked', x === b));
          customBox.hidden = chosen !== 'custom';
          if (chosen === 'custom') customIn.focus();
          preview();
        }));
        customIn.addEventListener('input', preview);
        startIn.addEventListener('change', preview);
        preview();
        main.querySelector('[data-go]').addEventListener('click', () => {
          const start = startIn.value ? new Date(startIn.value + 'T00:00:00').getTime() : Date.now();
          Store.setKhatma(buildPlan(days(), start));
          location.hash = '#/wird';
        });
      }

      function renderActive(k) {
        const pct = progress(k);
        const end = ui.addDays(k.start, k.days.length - 1);
        const cur = currentDay(k);
        const doneCount = k.days.filter(d => d.done).length;
        main.innerHTML = `
          <h1 class="page-title">ختمتك</h1>
          <section class="result-hero">
            <div class="ring" style="--p:${pct}"><span>${Q.ar(pct)}٪</span></div>
            <div>
              <strong class="grade">${cur ? `أنجزت ${Q.ar(doneCount)} من ${Q.ar(k.days.length)} يومًا` : 'أتممت الختمة، تقبّل الله منك'}</strong>
              <p class="muted">من ${ui.dateFmt.format(k.start)} إلى ${ui.dateFmt.format(end)}</p>
            </div>
          </section>
          ${cur ? `<a class="btn btn-primary btn-lg btn-block" href="#/wird">ورد اليوم</a>` : ''}
          <h2 class="section-title">خطة الختمة</h2>
          <ol class="plan">${k.days.map((d, i) => `
            <li class="${d.done ? 'done' : cur && i === cur.index ? 'current' : ''}">
              <button class="check" data-i="${i}" aria-pressed="${d.done}" aria-label="اليوم ${i + 1}: ${d.done ? 'منجز' : 'غير منجز'}">${d.done ? '✓' : Q.ar(i + 1)}</button>
              <a href="#/read?p=${d.fromPage}&wirdTo=${d.toPage}">
                <strong>${esc(Q.shortRef(d.fromGi))} — ${esc(Q.shortRef(d.toGi))}</strong>
                <span class="muted">${ui.dateShort.format(ui.addDays(k.start, i))}، ص ${Q.ar(d.fromPage)}–${Q.ar(d.toPage)}، ${juzSpan(d)}</span>
              </a>
            </li>`).join('')}</ol>
          <button class="btn btn-ghost btn-block" data-reset>إلغاء الختمة والبدء من جديد</button>`;

        main.querySelectorAll('[data-i]').forEach(b => b.addEventListener('click', () => {
          const d = k.days[+b.dataset.i];
          d.done = !d.done; d.doneAt = d.done ? Date.now() : null;
          if (d.done) Store.addReadPages(d.fromPage, d.toPage);
          Store.setKhatma(k);
          renderActive(k);
        }));
        main.querySelector('[data-reset]').addEventListener('click', () => {
          if (confirm('هل تريد إلغاء الختمة الحالية؟ سيُحذف تقدّمها.')) { Store.setKhatma(null); renderNew(); }
        });
      }
    }
  };

  App.views.wird = {
    render(main) {
      const { Store } = App, ui = App.ui, { esc, icons } = ui;
      ui.setTitle('ورد اليوم');
      const k = Store.khatma();
      if (!k) {
        main.innerHTML = `<div class="empty-state"><h1 class="page-title">ورد اليوم</h1><p>لم تبدأ ختمة بعد. اختر مدة الختمة ليظهر لك وردك اليومي.</p><a class="btn btn-primary" href="#/khatma">ابدأ ختمة</a></div>`;
        return;
      }
      const d = currentDay(k);
      if (!d) {
        main.innerHTML = `<div class="empty-state"><h1 class="page-title">أتممت الختمة</h1><p>بارك الله في وقتك. يمكنك بدء ختمة جديدة.</p><a class="btn btn-primary" href="#/khatma">عرض الختمة</a></div>`;
        return;
      }
      const dayByDate = ui.daysBetween(k.start, Date.now());
      const late = dayByDate - d.index;
      const pages = d.toPage - d.fromPage + 1;
      main.innerHTML = `
        <section class="wird-card">
          <p class="wird-kicker">📖 وردك اليوم</p>
          <h1>${juzSpan(d)}</h1>
          <div class="wird-range">
            <div><span class="muted">من</span><strong>سورة ${esc(Q.sura(Q.ref(d.fromGi).sura).name)}</strong><span>آية ${Q.ar(Q.ref(d.fromGi).ayah)}</span></div>
            <div><span class="muted">إلى</span><strong>سورة ${esc(Q.sura(Q.ref(d.toGi).sura).name)}</strong><span>آية ${Q.ar(Q.ref(d.toGi).ayah)}</span></div>
          </div>
          <p class="muted">${Q.ar(pages)} صفحة (${Q.ar(d.fromPage)}–${Q.ar(d.toPage)})، اليوم ${Q.ar(d.index + 1)} من ${Q.ar(k.days.length)}</p>
          ${late > 0 ? `<p class="notice">أنت متأخر ${Q.ar(late)} ${late === 1 ? 'يومًا' : 'أيام'} عن الخطة. لا بأس، تابع من حيث وقفت.</p>` : ''}
          <div class="cta-row">
            <a class="btn btn-primary btn-lg" href="#/read?p=${d.fromPage}&wirdTo=${d.toPage}">${icons.book}<span>ابدأ القراءة</span></a>
            <button class="btn btn-lg btn-ok" data-done>تم الإنجاز ✅</button>
          </div>
        </section>
        <a class="btn btn-ghost btn-block" href="#/khatma">عرض خطة الختمة كاملة (${Q.ar(App.khatma.progress(k))}٪)</a>`;
      main.querySelector('[data-done]').addEventListener('click', () => {
        k.days[d.index].done = true; k.days[d.index].doneAt = Date.now();
        Store.addReadPages(d.fromPage, d.toPage);
        Store.setKhatma(k);
        ui.toast('أحسنت! سُجّل إنجاز ورد اليوم');
        this.render(main);
      });
    }
  };
})();
