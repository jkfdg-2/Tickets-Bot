/* صفحة السور وصفحة الأجزاء */
(function () {
  function tabs(active) {
    return `<div class="seg" role="tablist">
      <a role="tab" href="#/surahs" aria-selected="${active === 's'}">السور</a>
      <a role="tab" href="#/juz" aria-selected="${active === 'j'}">الأجزاء</a>
    </div>`;
  }

  App.views.surahs = {
    render(main) {
      const { Q, Store } = App, { esc, icons, setTitle } = App.ui;
      setTitle('سور القرآن');
      main.innerHTML = `
        <h1 class="page-title">سور القرآن الكريم</h1>
        ${tabs('s')}
        <input class="filter" type="search" placeholder="ابحث باسم السورة أو رقمها" aria-label="تصفية السور" data-filter>
        <ul class="rows" data-list></ul>`;
      const list = main.querySelector('[data-list]');
      const draw = q => {
        const nq = App.Q.norm.normSearch(q || '');
        const items = Q.suras.filter(s => !q || String(s.n) === q.trim() || Q.norm.normSearch(s.name).includes(nq));
        list.innerHTML = items.map(s => `
          <li class="row">
            <a class="row-main" href="#/read?s=${s.n}">
              <span class="num-badge">${Q.ar(s.n)}</span>
              <span class="row-text">
                <strong>${esc(s.name)}</strong>
                <span class="muted">${Q.ar(s.ayahs)} آية، ${s.type === 'm' ? 'مكية' : 'مدنية'}</span>
              </span>
            </a>
            <button class="icon-btn${Store.isFav('surah', s.n) ? ' on' : ''}" data-fav="${s.n}" aria-label="مفضلة سورة ${esc(s.name)}">${icons.star}</button>
            <a class="btn btn-sm" href="#/read?s=${s.n}">فتح</a>
          </li>`).join('') || '<li class="empty">لا توجد سورة بهذا الاسم.</li>';
      };
      draw('');
      main.querySelector('[data-filter]').addEventListener('input', e => draw(e.target.value));
      list.addEventListener('click', e => {
        const b = e.target.closest('[data-fav]'); if (!b) return;
        const on = Store.toggleFav('surah', +b.dataset.fav);
        b.classList.toggle('on', on);
        App.ui.toast(on ? 'أُضيفت السورة إلى المفضلة' : 'أُزيلت من المفضلة');
      });
    }
  };

  App.views.juz = {
    render(main) {
      const { Q, Store } = App, { esc, setTitle } = App.ui;
      setTitle('أجزاء القرآن');
      const read = Store.readPages();
      let rows = '';
      for (let j = 1; j <= 30; j++) {
        const [a, b] = Q.juzRange(j);
        const [pa, pb] = Q.juzPages(j);
        let done = 0; for (let p = pa; p <= pb; p++) if (read.has(p)) done++;
        const pct = Math.round(done / (pb - pa + 1) * 100);
        rows += `
          <li class="row juz-row">
            <a class="row-main" href="#/read?j=${j}">
              <span class="num-badge">${Q.ar(j)}</span>
              <span class="row-text">
                <strong>الجزء ${Q.ar(j)}</strong>
                <span class="muted">من ${esc(Q.shortRef(a))} إلى ${esc(Q.shortRef(b))}</span>
                <span class="progress" aria-label="الإنجاز ${pct}%"><span style="width:${pct}%"></span></span>
              </span>
            </a>
            <span class="pct">${Q.ar(pct)}٪</span>
            <a class="btn btn-sm" href="#/read?j=${j}">فتح</a>
          </li>`;
      }
      main.innerHTML = `
        <h1 class="page-title">أجزاء القرآن الكريم</h1>
        ${tabs('j')}
        <p class="hint">تُحسب نسبة الإنجاز من الصفحات التي أتممتها في وِرد الختمة.</p>
        <ul class="rows">${rows}</ul>`;
    }
  };
})();
