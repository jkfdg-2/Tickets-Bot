/* تخزين محلي على جهاز المستخدم — بلا حسابات ولا خوادم */
(function () {
  const P = App.config.storagePrefix;

  function read(key, fallback) {
    try {
      const raw = localStorage.getItem(P + key);
      return raw == null ? fallback : JSON.parse(raw);
    } catch (e) { return fallback; }
  }
  function write(key, value) {
    try { localStorage.setItem(P + key, JSON.stringify(value)); return true; }
    catch (e) { console.warn('storage failed', e); return false; }
  }

  const Store = {
    read, write,

    settings() { return Object.assign({}, App.config.defaults, read('settings', {})); },
    setSetting(k, v) { const s = read('settings', {}); s[k] = v; write('settings', s); },

    /* آخر موضع قراءة */
    lastRead() { return read('lastRead', null); },
    setLastRead(page, gi) { write('lastRead', { page, gi, at: Date.now() }); App.Progress && App.Progress.markActive(); },

    /* المفضلة: ayah (فهرس عام) / surah (1-114) / page (1-604) */
    favorites() { return read('favorites', { ayah: [], surah: [], page: [] }); },
    isFav(type, id) { return this.favorites()[type].some(f => f.id === id); },
    toggleFav(type, id) {
      const f = this.favorites();
      const i = f[type].findIndex(x => x.id === id);
      if (i >= 0) f[type].splice(i, 1); else f[type].unshift({ id, at: Date.now() });
      write('favorites', f);
      return i < 0;
    },

    /* الختمة */
    khatma() { return read('khatma', null); },
    setKhatma(k) { write('khatma', k); },

    /* الصفحات المقروءة (لنسبة إنجاز الأجزاء) */
    readPages() { return new Set(read('readPages', [])); },
    addReadPages(from, to) {
      const s = this.readPages();
      for (let p = from; p <= to; p++) s.add(p);
      write('readPages', [...s]);
    },

    /* سجل التسميع */
    reciteHistory() { return read('reciteHistory', []); },
    addRecite(entry) {
      const h = this.reciteHistory();
      h.unshift(entry);
      write('reciteHistory', h.slice(0, 50));
    },
    lastMemorizeRange() { return read('memorizeRange', null); },
    setMemorizeRange(r) { write('memorizeRange', r); },

    clearAll() {
      Object.keys(localStorage).filter(k => k.startsWith(P)).forEach(k => localStorage.removeItem(k));
    }
  };

  App.Store = Store;
})();
