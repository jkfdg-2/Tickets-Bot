/* واجهة المشغل الثابت أسفل الشاشة */
App.initPlayerUI = function () {
  const { $ } = App.ui, P = App.Player;
  const bar = $('[data-player]'), more = $('[data-p-more]');
  const seek = $('[data-p-seek]'), vol = $('[data-p-vol]');
  let dragging = false;

  bar.addEventListener('click', e => {
    const b = e.target.closest('[data-p]'); if (!b) return;
    const a = b.dataset.p;
    if (a === 'toggle') P.toggle();
    if (a === 'prev') P.prev();
    if (a === 'next') P.next();
    if (a === 'close') P.stop();
    if (a === 'expand') {
      more.hidden = !more.hidden;
      b.setAttribute('aria-expanded', !more.hidden);
      bar.classList.toggle('expanded', !more.hidden);
    }
    if (a === 'repeatAyah') { P.repeatAyah = !P.repeatAyah; if (P.repeatAyah) P.repeatSurah = false; render(); }
    if (a === 'repeatSurah') { P.repeatSurah = !P.repeatSurah; if (P.repeatSurah) P.repeatAyah = false; render(); }
  });
  seek.addEventListener('input', () => { dragging = true; });
  seek.addEventListener('change', () => { P.seek(seek.value / 1000); dragging = false; });
  vol.value = P.volume;
  vol.addEventListener('input', () => P.setVolume(+vol.value));

  function render(p = P, kind) {
    const on = p.active;
    bar.hidden = !on;
    document.body.classList.toggle('has-player', on);
    if (!on) return;
    const [cur, dur] = p.times();
    $('[data-p-bar]').style.width = (p.progress() * 100) + '%';
    if (!dragging) seek.value = Math.round(p.progress() * 1000);
    $('[data-p-cur]').textContent = App.fmtTime(cur);
    $('[data-p-dur]').textContent = App.fmtTime(dur);
    if (kind === 'time') return;
    const t = p.title();
    $('[data-p-title]').textContent = t.main;
    $('[data-p-sub]').textContent = [t.sub, p.reciter && p.reciter.name].filter(Boolean).join('، ');
    bar.classList.toggle('is-playing', p.playing);
    bar.classList.toggle('is-loading', p.loading);
    const surahMode = p.mode === 'surah';
    $('[data-p="prev"]').setAttribute('aria-label', surahMode ? 'السورة السابقة' : 'الآية السابقة');
    $('[data-p="next"]').setAttribute('aria-label', surahMode ? 'السورة التالية' : 'الآية التالية');
    const ra = $('[data-p="repeatAyah"]');
    ra.hidden = surahMode;
    ra.setAttribute('aria-pressed', p.repeatAyah);
    $('[data-p="repeatSurah"]').setAttribute('aria-pressed', p.repeatSurah);
    const dl = $('[data-p-dl]'), url = p.downloadUrl();
    dl.hidden = !url; if (url) dl.href = url;
    const prov = p.rec && App.providers[p.rec.provider];
    $('[data-p-src]').textContent = prov ? 'المصدر: ' + prov.name : '';
  }
  P.on(render);
  render();
};
