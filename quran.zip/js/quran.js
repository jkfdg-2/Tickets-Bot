/* الوصول لبيانات القرآن + تطبيع النص العربي للبحث والتسميع.
   كل الآيات مفهرسة بفهرس عام gi من 0 إلى 6235. */
(function () {
  const D = window.QURAN_DATA;
  const TOTAL = D.verses.length;       // 6236
  const PAGES = D.pages.length;        // 604

  const AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';
  const ar = n => String(n).replace(/\d/g, d => AR_DIGITS[d]);

  // بحث ثنائي: أكبر i بحيث arr[i] <= x
  function floorIndex(arr, x) {
    let lo = 0, hi = arr.length - 1, ans = 0;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      if (arr[mid] <= x) { ans = mid; lo = mid + 1; } else hi = mid - 1;
    }
    return ans;
  }
  const suraStarts = D.suras.map(s => s[3]);

  const Q = {
    TOTAL, PAGES, ar,
    source: D.source,
    suras: D.suras.map((s, i) => ({ n: i + 1, name: s[0], ayahs: s[1], type: s[2], start: s[3] })),

    text(gi) { return D.verses[gi]; },
    gi(sura, ayah) { return D.suras[sura - 1][3] + ayah - 1; },
    ref(gi) {
      const si = floorIndex(suraStarts, gi);
      return { sura: si + 1, ayah: gi - suraStarts[si] + 1 };
    },
    sura(n) { return this.suras[n - 1]; },
    refLabel(gi, withSura = true) {
      const r = this.ref(gi);
      return (withSura ? 'سورة ' + this.suras[r.sura - 1].name + ' ' : '') + 'آية ' + ar(r.ayah);
    },
    shortRef(gi) {
      const r = this.ref(gi);
      return this.suras[r.sura - 1].name + ' ' + ar(r.ayah);
    },

    pageOf(gi) { return floorIndex(D.pages, gi) + 1; },
    pageRange(p) { return [D.pages[p - 1], p < PAGES ? D.pages[p] - 1 : TOTAL - 1]; },
    juzOf(gi) { return floorIndex(D.juz, gi) + 1; },
    juzRange(j) { return [D.juz[j - 1], j < 30 ? D.juz[j] - 1 : TOTAL - 1]; },
    juzPages(j) { const [a, b] = this.juzRange(j); return [this.pageOf(a), this.pageOf(b)]; },
    isSajda(gi) { return D.sajda.includes(gi); },
    isHizbStart(gi) { return D.hizbQuarters.includes(gi); },

    bismillah() { return D.verses[0]; }, // الفاتحة ١ من المصدر نفسه

    words(gi) { return D.verses[gi].split(/\s+/).filter(Boolean); }
  };

  /* ---------- التطبيع ---------- */
  // تشكيل وعلامات ضبط ووقف (ما عدا الألف الخنجرية ٰ فتُعالج منفصلة)
  const MARKS = /[\u0610-\u061A\u064B-\u065F\u06D6-\u06DC\u06DE-\u06E4\u06E7-\u06ED\u0640]/g;

  function baseLetters(s) {
    return s
      .replace(/[\u06E6\u06E7]/g, 'ي')     // ياء صغيرة (إبراهـۧم)
      .replace(/\u06E5/g, '')              // واو الصلة الصغيرة (لهُۥ)
      .replace(MARKS, '')
      .replace(/[\u06DD\u06DF\u06E0\u06E9\u06DE]/g, '');
  }
  function letters(s) {
    return s
      .replace(/[أإآٱٲٳ]/g, 'ا')
      .replace(/ى/g, 'ي')
      .replace(/ة/g, 'ه')
      .replace(/ؤ/g, 'و')
      .replace(/ئ/g, 'ي')
      .replace(/ء/g, '')
      .replace(/[^\u0621-\u064A]/g, '');
  }
  // صيغة "مرخاة": بلا ألفات — تتجاوز فروق الرسم العثماني والإملائي
  const loose = s => s.replace(/ا/g, '');

  /* يُرجع كل الصيغ المقبولة لكلمة عثمانية */
  function wordForms(word) {
    const b = baseLetters(word);
    const out = new Set();
    // (١) الألف الخنجرية تُحذف  (٢) تُصبح ألفًا  (٣) الواو قبلها تُقرأ ألفًا (الصلوٰة)
    const variants = [
      b.replace(/\u0670/g, ''),
      b.replace(/\u0670/g, 'ا'),
      b.replace(/و\u0670/g, 'ا').replace(/\u0670/g, ''),
      b.replace(/ى\u0670/g, 'ا').replace(/\u0670/g, '')
    ];
    variants.forEach(v => { const l = letters(v); if (l) { out.add(l); out.add(loose(l)); } });
    return out;
  }
  // تطبيع كلام المستخدم (نص إملائي عادي من محرك التعرف)
  function normHeard(w) { return loose(letters(baseLetters(w).replace(/\u0670/g, ''))); }
  // تطبيع للبحث
  function normSearch(s) { return loose(letters(baseLetters(s).replace(/\u0670/g, 'ا'))); }

  /* الحروف المقطعة: تُقرأ بأسماء الحروف */
  const LETTER_NAMES = { 'ا': 'الف', 'ل': 'لام', 'م': 'ميم', 'ص': 'صاد', 'ر': 'را', 'ك': 'كاف', 'ه': 'ها',
    'ي': 'يا', 'ع': 'عين', 'ط': 'طا', 'س': 'سين', 'ح': 'حا', 'ق': 'قاف', 'ن': 'نون' };
  const MUQATTAAT = new Set(['الم', 'الر', 'المص', 'المر', 'كهيعص', 'طه', 'طسم', 'طس', 'يس', 'ص', 'حم', 'عسق', 'ق', 'ن']);
  function muqattaat(word) {
    if (!word.includes('\u0653')) return null;
    const plain = letters(baseLetters(word).replace(/\u0670/g, ''));
    if (!MUQATTAAT.has(plain)) return null;
    return [...plain].map(ch => LETTER_NAMES[ch] || ch);
  }

  Q.norm = { baseLetters, letters, loose, wordForms, normHeard, normSearch, muqattaat };

  /* فهرس بحث يُبنى عند أول استخدام: لكل كلمة صيغها المرخاة (تتجاوز فروق الرسم العثماني) */
  function searchForms(w) { return [...wordForms(w)].filter(x => !x.includes('ا')); }
  let searchIndex = null;
  Q.searchIndex = function () {
    if (!searchIndex) searchIndex = D.verses.map(v => v.split(/\s+/).map(searchForms));
    return searchIndex;
  };
  Q.searchForms = searchForms;
  /* هل تحتوي الآية على تسلسل الكلمات المطلوب؟ يُرجع فهارس الكلمات المطابقة */
  Q.matchVerse = function (forms, tokens) {
    const n = tokens.length;
    const has = (fs, t) => fs.some(f => f.includes(t));
    for (let i = 0; i + n <= forms.length; i++) {
      let ok = true;
      for (let k = 0; k < n && ok; k++) ok = has(forms[i + k], tokens[k]);
      if (ok) { const r = []; for (let k = 0; k < n; k++) r.push(i + k); return r; }
    }
    return null;
  };

  App.Q = Q;
})();
