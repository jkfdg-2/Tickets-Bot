/* محرك التلاوة: ملف لكل آية (بث مباشر)، والسورة تُشغَّل آية بعد آية */
(function () {
  const Q = App.Q;
  const el = new Audio();
  el.preload = 'auto';
  const pre = new Audio(); pre.preload = 'auto';

  const Player = {
    rec: null, reciter: null,     // التسجيل الحالي
    mode: 'ayah',
    gi: -1, endGi: -1, sura: 0,
    playing: false, loading: false,
    repeatAyah: false, repeatSurah: false,
    listeners: new Set(),
    _token: 0,

    get active() { return this.gi >= 0; },

    /* تشغيل من آية (وحتى endGi) بالقارئ الافتراضي أو بقارئ محدد */
    async play(gi, endGi, opts = {}) {
      if (!this._use(opts.recordingKey)) return;
      this.endGi = endGi == null ? Q.TOTAL - 1 : endGi;
      this._ayah(gi);
    },

    /* تشغيل سورة كاملة (آية بعد آية) */
    async playSurah(sura, opts = {}) {
      if (!this._use(opts.recordingKey)) return;
      const first = Q.gi(sura, 1), last = Q.gi(sura, Q.sura(sura).ayahs);
      this.endGi = opts.continue ? Q.TOTAL - 1 : last;
      this._ayah(first);
    },

    toggle() {
      if (!this.active) return;
      if (el.paused) { el.play().catch(() => {}); } else el.pause();
    },
    stop() {
      this._token++;
      el.pause(); el.removeAttribute('src'); el.load();
      this.gi = -1; this.sura = 0; this.playing = false; this.loading = false;
      this.notify();
    },
    next() {
      if (this.gi >= 0 && this.gi < Q.TOTAL - 1) { if (this.gi + 1 > this.endGi) this.endGi = this.gi + 1; this._ayah(this.gi + 1); }
    },
    prev() {
      if (this.gi > 0) this._ayah(this.gi - 1);
    },
    setVolume(v) { el.volume = v; App.Store.setSetting('volume', v); },
    get volume() { return el.volume; },

    /* التقدم داخل الآية من ٠ إلى ١ */
    progress() { return el.duration ? clamp(el.currentTime / el.duration) : 0; },
    times() { return [el.currentTime || 0, el.duration || 0]; },
    seek(p) { if (el.duration) el.currentTime = p * el.duration; },

    downloadUrl() { return null; },
    title() {
      if (this.gi < 0) return { main: '', sub: '' };
      const r = Q.ref(this.gi);
      return { main: 'سورة ' + Q.sura(r.sura).name, sub: 'آية ' + Q.ar(r.ayah) };
    },

    on(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); },
    notify() { this.listeners.forEach(fn => fn(this)); },

    /* ---------- داخلي ---------- */
    _use(key) {
      const f = App.Catalog.current(key);
      if (!f) { App.ui.toast('لم يُعثر على القارئ. اختر قارئًا من صفحة القراء.'); return false; }
      this.rec = f.recording; this.reciter = f.reciter;
      return true;
    },
    _load(src, at) {
      const token = ++this._token;
      this.loading = true; this.notify();
      if (el.src !== src) el.src = src;
      const go = () => {
        if (token !== this._token) return;
        try { if (Math.abs(el.currentTime - at) > 0.25) el.currentTime = at; } catch (e) {}
        el.play().catch(err => { if (err.name !== 'AbortError') { this.loading = false; this.notify(); App.ui.toast('اضغط تشغيل لبدء التلاوة'); } });
      };
      if (el.readyState >= 1) go(); else el.addEventListener('loadedmetadata', go, { once: true });
    },
    _ayah(gi) {
      const r = Q.ref(gi);
      this.gi = gi; this.sura = r.sura;
      const rec = this.rec, prov = App.providers[rec.provider];
      this._load(new URL(prov.ayahUrl(rec, r.sura, r.ayah), location.href).href, 0);
      if (gi + 1 <= this.endGi) { const n = Q.ref(gi + 1); pre.src = prov.ayahUrl(rec, n.sura, n.ayah); }
      this._media();
    },
    _ayahEnded() {
      if (this._ending) return;
      this._ending = true; setTimeout(() => { this._ending = false; }, 200);
      if (this.repeatAyah) return this._ayah(this.gi);
      const r = Q.ref(this.gi);
      const lastOfSurah = Q.gi(r.sura, Q.sura(r.sura).ayahs);
      if (this.repeatSurah && this.gi >= Math.min(lastOfSurah, this.endGi)) return this._ayah(Q.gi(r.sura, 1));
      if (this.gi + 1 > this.endGi || this.gi + 1 >= Q.TOTAL) { this.stop(); return; }
      this._ayah(this.gi + 1);
    },
    _media() {
      if (!('mediaSession' in navigator) || !window.MediaMetadata) return;
      const t = this.title();
      try {
        navigator.mediaSession.metadata = new MediaMetadata({ title: (t.main + ' ' + t.sub).trim(), artist: this.reciter ? this.reciter.name : '', album: 'رتّل' });
        navigator.mediaSession.setActionHandler('nexttrack', () => this.next());
        navigator.mediaSession.setActionHandler('previoustrack', () => this.prev());
      } catch (e) {}
    }
  };

  function clamp(x) { return Math.max(0, Math.min(1, x || 0)); }

  el.addEventListener('timeupdate', () => Player.listeners.forEach(fn => fn(Player, 'time')));
  el.addEventListener('ended', () => Player._ayahEnded());
  el.addEventListener('playing', () => { Player.playing = true; Player.loading = false; Player.notify(); });
  el.addEventListener('pause', () => { Player.playing = false; Player.notify(); });
  el.addEventListener('waiting', () => { Player.loading = true; Player.notify(); });
  el.addEventListener('error', () => {
    if (!el.getAttribute('src')) return;
    App.ui.toast('تعذّر تحميل التلاوة. تحقق من الاتصال أو جرّب قارئًا آخر.');
    Player.stop();
  });

  try { const v = App.Store.settings().volume; if (v != null) el.volume = v; } catch (e) {}

  /* صوت تنبيه خفيف للخطأ في التسميع */
  let ctx = null;
  function beep() {
    if (!App.Store.settings().errorSound) return;
    try {
      ctx = ctx || new (window.AudioContext || window.webkitAudioContext)();
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.type = 'sine';
      o.frequency.setValueAtTime(620, ctx.currentTime);
      o.frequency.exponentialRampToValueAtTime(420, ctx.currentTime + 0.14);
      g.gain.setValueAtTime(0.0001, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.12, ctx.currentTime + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.18);
      o.connect(g).connect(ctx.destination);
      o.start(); o.stop(ctx.currentTime + 0.2);
    } catch (e) {}
  }
  function unlockAudio() { try { ctx = ctx || new (window.AudioContext || window.webkitAudioContext)(); ctx.resume(); } catch (e) {} }

  App.Player = Player;
  App.beep = beep;
  App.unlockAudio = unlockAudio;
  App.fmtTime = s => { s = Math.max(0, Math.floor(s || 0)); return '\u2066' + Q.ar(Math.floor(s / 60)) + ':' + Q.ar(String(s % 60).padStart(2, '0')) + '\u2069'; };
})();
