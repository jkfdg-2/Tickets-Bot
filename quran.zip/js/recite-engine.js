/* محرك التسميع: يطابق ما يقوله المستخدم مع النص القرآني كلمة بكلمة.
   مستقل عن الواجهة وعن محرك التعرف على الصوت، ليسهل استبداله أو نقله لتطبيق جوال.

   المفاهيم:
   - word: كلمة معروضة في المصحف (قد تحتوي عدة "وحدات" مثل الحروف المقطعة: الٓمٓ = الف لام ميم)
   - unit: وحدة نطق واحدة تُطابق بكلمة مسموعة
   حالات الكلمة: pending | ok | err (قال كلمة أخرى) | skip (تجاوزها) */
(function () {
  const N = App.Q.norm;

  const THRESHOLDS = { strict: 1, medium: 0.8, lenient: 0.67 };

  function similarity(a, b) {
    if (a === b) return 1;
    const m = a.length, n = b.length;
    if (!m || !n) return 0;
    let prev = Array.from({ length: n + 1 }, (_, j) => j);
    for (let i = 1; i <= m; i++) {
      const cur = [i];
      for (let j = 1; j <= n; j++) {
        cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      }
      prev = cur;
    }
    return 1 - prev[n] / Math.max(m, n);
  }

  class ReciteEngine {
    /**
     * @param {number[]} ayahs فهارس الآيات العامة
     * @param {object} opts { strictness, onChange(event) }
     */
    constructor(ayahs, opts = {}) {
      this.opts = opts;
      this.threshold = THRESHOLDS[opts.strictness] || THRESHOLDS.medium;
      this.words = [];   // { gi, idx, text, state, heard }
      this.units = [];   // { w, forms:Set, first, groupLen, groupForms }
      ayahs.forEach(gi => {
        App.Q.words(gi).forEach((text, idx) => {
          const w = this.words.length;
          this.words.push({ gi, idx, text, state: 'pending', heard: null });
          const letters = N.muqattaat(text);
          const whole = N.wordForms(text);
          if (letters) {
            letters.forEach((name, k) => this.units.push({
              w, forms: new Set([N.normHeard(name)]), first: k === 0,
              groupLen: letters.length, groupForms: whole
            }));
          } else if (whole.size) {
            this.units.push({ w, forms: whole, first: true, groupLen: 1, groupForms: whole });
          } else {
            this.words[w].state = 'ok'; // علامة بلا حروف
          }
        });
      });
      this.pos = 0;          // الوحدة المنتظرة
      this.heard = [];       // كلمات نهائية مسموعة (مُطبّعة)
      this.heardRaw = [];
      this.hi = 0;           // أول كلمة مسموعة لم تُعالج
      this.previewPos = 0;
    }

    get done() { return this.pos >= this.units.length; }
    get currentWord() { return this.done ? -1 : this.units[this.pos].w; }

    /* هل الكلمة المسموعة h تطابق الوحدة u؟ يُرجع عدد الوحدات المستهلكة */
    matchAt(h, u) {
      const unit = this.units[u];
      if (!unit || !h) return 0;
      if (unit.first && unit.groupLen > 1 && unit.groupForms.has(h)) return unit.groupLen;
      if (unit.forms.has(h)) return 1;
      if (this.threshold < 1 && h.length >= 3) {
        for (const f of unit.forms) {
          if (Math.abs(f.length - h.length) <= 2 && similarity(f, h) >= this.threshold) return 1;
        }
      }
      return 0;
    }
    formOf(u) { const it = this.units[u].forms.values(); let best = ''; for (const f of it) if (f.length > best.length) best = f; return best; }
    looseOf(u) { let s = null; for (const f of this.units[u].forms) if (!f.includes('ا') && (s === null || f.length < s.length)) s = f; return s || ''; }

    /* كلمة مسموعة واحدة = كلمتان في المصحف (مثل: يابني) */
    matchJoinedExpected(h, u) {
      if (u + 1 >= this.units.length) return false;
      return h === this.looseOf(u) + this.looseOf(u + 1);
    }

    mark(u, count, state, heard) {
      for (let k = 0; k < count; k++) {
        const unit = this.units[u + k];
        const w = this.words[unit.w];
        if (state === 'ok') { if (w.state === 'pending') w.state = 'ok'; continue; }
        w.state = state; w.heard = heard || null;
        this.emit({ type: 'error', word: unit.w, state });
      }
    }
    emit(e) { this.opts.onChange && this.opts.onChange(e); }

    feedFinal(rawWords) {
      rawWords.forEach(r => {
        const n = N.normHeard(r);
        if (n) { this.heard.push(n); this.heardRaw.push(r); }
      });
      this.process(false);
    }

    /* معالجة الكلمات المسموعة. flush=true عند الانتهاء لحسم الكلمة الأخيرة المعلقة */
    process(flush) {
      const tolerateShort = this.threshold < 1;
      while (this.hi < this.heard.length && !this.done) {
        const h = this.heard[this.hi];
        const hasNext = this.hi + 1 < this.heard.length;
        const hn = hasNext ? this.heard[this.hi + 1] : null;
        const raw = this.heardRaw[this.hi];
        let c;

        // ١) تطابق مباشر
        if ((c = this.matchAt(h, this.pos))) { this.mark(this.pos, c, 'ok'); this.pos += c; this.hi++; continue; }
        // ٢) كلمتان مسموعتان = كلمة واحدة (يا أيها ← يٰٓأيها)
        if (hn && (c = this.matchAt(h + hn, this.pos))) { this.mark(this.pos, c, 'ok'); this.pos += c; this.hi += 2; continue; }
        // ٣) كلمة مسموعة = كلمتان في النص
        if (this.matchJoinedExpected(h, this.pos)) { this.mark(this.pos, 2, 'ok'); this.pos += 2; this.hi++; continue; }
        // ٤) تكرار لكلمة سابقة (المستخدم يعيد) → تجاهل
        let repeated = false;
        for (let b = 1; b <= 3 && this.pos - b >= 0; b++) if (this.matchAt(h, this.pos - b)) { repeated = true; break; }
        if (repeated) { this.hi++; continue; }
        // ٥) تجاوز كلمة أو أكثر (حتى ٣)
        let jumped = false;
        for (let k = 1; k <= 3 && this.pos + k < this.units.length; k++) {
          if ((c = this.matchAt(h, this.pos + k))) {
            for (let s = 0; s < k; s++) {
              const u = this.pos + s;
              // محركات التعرف كثيرًا ما تُسقط الكلمات القصيرة (في، من، لا)؛ نتسامح معها في الوضع المتوسط/المتسامح
              const shortWord = this.looseOf(u).length <= 2 && k === 1;
              this.mark(u, 1, tolerateShort && shortWord ? 'ok' : 'skip');
            }
            this.mark(this.pos + k, c, 'ok');
            this.pos += k + c; this.hi++; jumped = true; break;
          }
        }
        if (jumped) continue;
        // ٦) نحتاج الكلمة التالية لنحكم
        if (!hasNext && !flush) break;
        // ٧) كلمة زائدة: التالية تطابق المنتظرة
        if (hn && this.matchAt(hn, this.pos)) { this.hi++; continue; }
        // ٨) إبدال: قال كلمة غير الصحيحة
        this.mark(this.pos, 1, 'err', raw);
        this.pos += 1; this.hi++;
      }
      this.previewPos = this.pos;
      this.emit({ type: 'progress' });
      if (this.done) this.emit({ type: 'complete' });
    }

    /* معاينة فورية من النتائج المؤقتة (لا تُسجَّل أخطاء) */
    preview(rawWords) {
      let p = this.pos;
      const hs = rawWords.map(N.normHeard).filter(Boolean);
      // حسم الكلمة المعلقة مبكرًا باستخدام أول كلمة مؤقتة (لإظهار الخطأ فورًا)
      if (hs.length && this.hi === this.heard.length - 1 && !this.done) {
        if (this.matchAt(hs[0], this.pos)) { this.hi++; }                 // كانت كلمة زائدة
        else if (this.matchAt(hs[0], this.pos + 1)) { this.process(true); } // كانت إبدالًا
      }
      p = this.pos;
      for (let i = 0; i < hs.length && p < this.units.length; i++) {
        const c = this.matchAt(hs[i], p);
        if (c) p += c;
        else if (hs[i + 1] && this.matchAt(hs[i] + hs[i + 1], p)) { p += 1; i++; }
        else if (this.matchAt(hs[i], p + 1)) p += 2;
      }
      if (p !== this.previewPos) { this.previewPos = p; this.emit({ type: 'preview' }); }
    }

    /* لاختيار أفضل بديل من بدائل محرك التعرف: كم كلمة ستتطابق من الموضع الحالي */
    scoreCandidate(rawWords) {
      let p = this.pos, score = 0;
      const hs = rawWords.map(N.normHeard).filter(Boolean);
      for (let i = 0; i < hs.length && p < this.units.length; i++) {
        let c = this.matchAt(hs[i], p);
        if (c) { score += 1; p += c; continue; }
        for (let k = 1; k <= 2; k++) if ((c = this.matchAt(hs[i], p + k))) { score += 0.5; p += k + c; break; }
      }
      return score;
    }

    hint() { if (!this.done) { const w = this.words[this.units[this.pos].w]; w.hinted = true; return this.units[this.pos].w; } return -1; }

    finish() {
      this.process(true);
      const total = this.words.length;
      const ok = this.words.filter(w => w.state === 'ok').length;
      const errors = this.words.filter(w => w.state === 'err' || w.state === 'skip');
      const unread = this.words.filter(w => w.state === 'pending').length;
      return {
        words: total, ok, unread,
        errors: errors.map(w => ({ gi: w.gi, text: w.text, heard: w.heard, state: w.state })),
        accuracy: total ? Math.round((ok / total) * 100) : 0
      };
    }
  }

  App.ReciteEngine = ReciteEngine;
  App.similarity = similarity;
})();
