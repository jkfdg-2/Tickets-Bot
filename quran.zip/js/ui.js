/* أدوات واجهة مشتركة */
(function () {
  const Q = App.Q;
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

  const icons = {
    star: '<svg viewBox="0 0 24 24"><path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9L12 3Z"/></svg>',
    play: '<svg viewBox="0 0 24 24"><path d="M7 4.5v15l12-7.5-12-7.5Z"/></svg>',
    copy: '<svg viewBox="0 0 24 24"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/></svg>',
    mic: '<svg viewBox="0 0 24 24"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>',
    chevNext: '<svg viewBox="0 0 24 24"><path d="m15 6-6 6 6 6"/></svg>',
    chevPrev: '<svg viewBox="0 0 24 24"><path d="m9 6 6 6-6 6"/></svg>',
    book: '<svg viewBox="0 0 24 24"><path d="M12 6c-3-2-6-2-8-1.5v14c2-.5 5-.5 8 1.5 3-2 6-2 8-1.5v-14C18 4 15 4 12 6Z"/><path d="M12 6v14"/></svg>',
    brain: '<svg viewBox="0 0 24 24"><path d="M9 4a3 3 0 0 0-3 3 3 3 0 0 0-2 5 3 3 0 0 0 2 5 3 3 0 0 0 6 1V5a2 2 0 0 0-3-1Z"/><path d="M15 4a3 3 0 0 1 3 3 3 3 0 0 1 2 5 3 3 0 0 1-2 5 3 3 0 0 1-6 1"/></svg>',
    trophy: '<svg viewBox="0 0 24 24"><path d="M8 4h8v5a4 4 0 0 1-8 0V4Z"/><path d="M8 6H5a3 3 0 0 0 3 4M16 6h3a3 3 0 0 1-3 4M12 13v4M8 20h8M9 17h6"/></svg>',
    home: '<svg viewBox="0 0 24 24"><path d="M4 11 12 4l8 7v8a1 1 0 0 1-1 1h-5v-6h-4v6H5a1 1 0 0 1-1-1v-8Z"/></svg>',
    list: '<svg viewBox="0 0 24 24"><path d="M9 6h11M9 12h11M9 18h11M4 6h.01M4 12h.01M4 18h.01"/></svg>',
    trash: '<svg viewBox="0 0 24 24"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>',
    eye: '<svg viewBox="0 0 24 24"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>',
    eyeOff: '<svg viewBox="0 0 24 24"><path d="M3 3l18 18M10.6 5.1A10 10 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3.3 4.2M6.6 6.6C3.7 8.5 2 12 2 12s3.5 7 10 7a9.7 9.7 0 0 0 5.4-1.6M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>'
  };

  const tabs = [
    { href: '#/', label: 'الرئيسية', icon: 'home', match: /^\/?$/ },
    { href: '#/read', label: 'القراءة', icon: 'book', match: /^\/read/ },
    { href: '#/memorize', label: 'الحفظ', icon: 'brain', match: /^\/(memorize|plan|test|progress)/ },
    { href: '#/khatma', label: 'الختمة', icon: 'trophy', match: /^\/(khatma|wird)/ },
    { href: '#/favorites', label: 'المفضلة', icon: 'star', match: /^\/favorites/ }
  ];

  function renderNav(path) {
    const html = tabs.map(t => `<a href="${t.href}" ${t.match.test(path) ? 'aria-current="page"' : ''}>${icons[t.icon]}<span>${t.label}</span></a>`).join('');
    $('[data-nav]').innerHTML = html;
    $('[data-tabbar]').innerHTML = html;
  }

  let toastTimer;
  function toast(msg) {
    const t = $('[data-toast]');
    t.textContent = msg; t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), 2400);
  }

  function openSheet(html, onMount) {
    const sheet = $('[data-sheet]'), bd = $('[data-sheet-backdrop]');
    sheet.innerHTML = '<div class="sheet-handle"></div>' + html;
    sheet.hidden = false; bd.hidden = false;
    requestAnimationFrame(() => { sheet.classList.add('open'); bd.classList.add('open'); });
    onMount && onMount(sheet);
    const first = sheet.querySelector('button, a, select, input');
    first && first.focus();
  }
  function closeSheet() {
    const sheet = $('[data-sheet]'), bd = $('[data-sheet-backdrop]');
    sheet.querySelectorAll('audio').forEach(a => a.pause());
    sheet.classList.remove('open'); bd.classList.remove('open');
    setTimeout(() => { sheet.hidden = true; bd.hidden = true; sheet.innerHTML = ''; }, 200);
  }

  function suraOptions(selected) {
    return Q.suras.map(s => `<option value="${s.n}" ${s.n === selected ? 'selected' : ''}>${Q.ar(s.n)}. ${s.name}</option>`).join('');
  }
  function ayahOptions(sura, selected) {
    let o = '';
    for (let a = 1; a <= Q.sura(sura).ayahs; a++) o += `<option value="${a}" ${a === selected ? 'selected' : ''}>${Q.ar(a)}</option>`;
    return o;
  }
  function juzOptions(selected) {
    let o = '';
    for (let j = 1; j <= 30; j++) o += `<option value="${j}" ${j === selected ? 'selected' : ''}>الجزء ${Q.ar(j)}</option>`;
    return o;
  }

  /* نص آية كامل بعلامة نهايتها */
  function ayahMark(n) { return `<span class="ayah-num" aria-label="آية ${n}">﴿${Q.ar(n)}﴾</span>`; }

  const dateFmt = new Intl.DateTimeFormat('ar-u-nu-arab-ca-gregory', { weekday: 'long', day: 'numeric', month: 'long' });
  const dateShort = new Intl.DateTimeFormat('ar-u-nu-arab-ca-gregory', { day: 'numeric', month: 'short' });
  function dayKey(d) { const x = new Date(d); x.setHours(0, 0, 0, 0); return x.getTime(); }
  function addDays(d, n) { const x = new Date(dayKey(d)); x.setDate(x.getDate() + n); return x.getTime(); }
  function daysBetween(a, b) { return Math.round((dayKey(b) - dayKey(a)) / 86400000); }
  function fmtDuration(ms) {
    const s = Math.round(ms / 1000), m = Math.floor(s / 60), r = s % 60;
    return '\u2066' + Q.ar(m) + ':' + Q.ar(String(r).padStart(2, '0')) + '\u2069';
  }

  /* التنقل بين أقسام الحفظ */
  function memNav(active) {
    const items = [['memorize', 'التسميع'], ['plan', 'الخطة والمراجعة'], ['test', 'اختبار الحفظ 🎙️'], ['progress', 'التقدم']];
    return `<nav class="seg mem-nav" aria-label="أقسام الحفظ">${items.map(([k, l]) =>
      `<a href="#/${k}" ${k === active ? 'aria-selected="true"' : ''}>${l}</a>`).join('')}</nav>`;
  }

  function setTitle(t) { document.title = t ? t + ' — رتّل' : 'رتّل — القرآن الكريم'; }

  App.ui = { esc, $, $$, icons, renderNav, toast, openSheet, closeSheet, suraOptions, ayahOptions, juzOptions,
    ayahMark, dateFmt, dateShort, dayKey, addDays, daysBetween, fmtDuration, setTitle, memNav };
})();
