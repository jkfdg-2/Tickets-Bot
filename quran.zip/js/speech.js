/* غلاف التعرف على الكلام (Web Speech API).
   مصمم كواجهة قابلة للاستبدال: يمكن لاحقًا استبداله بنموذج متخصص في التلاوة
   (مثل Whisper مدرّب على القرآن) على خادم أو داخل تطبيق جوال، بنفس الأحداث:
   onFinal(alternatives[][]), onInterim(words[]), onState(state), onError(code) */
(function () {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;

  class SpeechListener {
    static supported() { return !!SR; }

    constructor(handlers) {
      this.h = handlers;
      this.active = false;
      this.rec = null;
      this.restarts = 0;
    }

    async requestMic() {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return true;
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
        stream.getTracks().forEach(t => t.stop());
        return true;
      } catch (e) {
        this.h.onError && this.h.onError(e.name === 'NotAllowedError' ? 'not-allowed' : 'audio-capture');
        return false;
      }
    }

    async start() {
      if (!SR) { this.h.onError && this.h.onError('unsupported'); return false; }
      const ok = await this.requestMic();
      if (!ok) return false;
      this.active = true;
      this._spawn();
      return true;
    }

    _spawn() {
      const rec = new SR();
      rec.lang = App.config.speechLang;
      rec.continuous = true;
      rec.interimResults = true;
      rec.maxAlternatives = 4;
      const done = new Set();

      rec.onstart = () => this.h.onState && this.h.onState('listening');
      rec.onresult = e => {
        let interim = [];
        for (let i = e.resultIndex; i < e.results.length; i++) {
          const r = e.results[i];
          if (r.isFinal) {
            if (done.has(i)) continue;
            done.add(i);
            const alts = [];
            for (let a = 0; a < r.length; a++) alts.push(split(r[a].transcript));
            this.h.onFinal && this.h.onFinal(alts);
          } else {
            interim = interim.concat(split(r[0].transcript));
          }
        }
        this.h.onInterim && this.h.onInterim(interim);
      };
      rec.onerror = e => {
        if (e.error === 'no-speech' || e.error === 'aborted') return;
        if (e.error === 'not-allowed' || e.error === 'service-not-allowed' || e.error === 'network') this.active = false;
        this.h.onError && this.h.onError(e.error);
      };
      rec.onend = () => {
        // المتصفح يوقف الاستماع بعد صمت؛ نعيد التشغيل تلقائيًا دون إزعاج المستخدم
        if (this.active) {
          this.h.onState && this.h.onState('reconnecting');
          setTimeout(() => { if (this.active) this._spawn(); }, 120);
        } else {
          this.h.onState && this.h.onState('stopped');
        }
      };
      this.rec = rec;
      try { rec.start(); } catch (err) { /* بدأ مسبقًا */ }
    }

    stop() {
      this.active = false;
      if (this.rec) { try { this.rec.stop(); } catch (e) {} }
    }
  }

  function split(t) { return (t || '').trim().split(/\s+/).filter(Boolean); }

  App.SpeechListener = SpeechListener;
})();
