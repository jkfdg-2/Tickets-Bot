/* إعدادات عامة قابلة للتعديل */
window.App = window.App || {};

App.config = {
  appName: 'رتّل',
  storagePrefix: 'rattil:',
  /* مزوّدو التلاوات: بث مباشر لملفات الآيات، بلا API ولا فهرس يُجلب من الإنترنت. */
  providers: {
    everyayah: true
  },
  // صور القراء (اختياري): { 'اسم القارئ كما يظهر': 'رابط صورة مرخّصة' }
  reciterImages: {},
  khatmaPresets: [3, 7, 10, 15, 30],
  // أقصى عدد آيات في مقطع التسميع الواحد
  maxReciteAyahs: 300,
  // لغة التعرف على الصوت
  speechLang: 'ar-SA',
  defaults: {
    theme: 'auto',
    fontSize: 30,
    reciter: 'everyayah:Alafasy_128kbps', // مشاري العفاسي — حفص مرتل
    strictness: 'medium', // strict | medium | lenient
    errorSound: true
  }
};
