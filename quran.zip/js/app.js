/* الموجّه والتهيئة */
(function () {
  const { $, renderNav, closeSheet } = App.ui;
  const routes = {
    '': 'home', 'read': 'reader', 'surahs': 'surahs', 'juz': 'juz', 'search': 'search',
    'favorites': 'favorites', 'memorize': 'memorize', 'khatma': 'khatma', 'wird': 'wird', 'settings': 'settings', 'reciters': 'reciters',
    'plan': 'plan', 'test': 'test', 'progress': 'progress'
  };
  let current = null;

  function parse() {
    const raw = location.hash.replace(/^#/, '') || '/';
    const [path, qs] = raw.split('?');
    const params = Object.fromEntries(new URLSearchParams(qs || ''));
    const seg = path.replace(/^\//, '').split('/')[0];
    return { path, seg, params };
  }

  function route() {
    const { path, seg, params } = parse();
    const name = routes[seg] || 'home';
    if (current && current.destroy) current.destroy();
    closeSheet();
    const main = $('#main');
    main.innerHTML = '';
    main.onclick = null;
    main.className = 'view view-' + name;
    renderNav(path);
    current = App.views[name];
    current.render(main, params);
    if (!params.g) window.scrollTo(0, 0);
  }

  function applyTheme(t) {
    if (t === 'auto') t = matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    document.documentElement.dataset.theme = t;
    document.querySelector('meta[name=theme-color]').content = t === 'dark' ? '#0F1615' : '#1F5C57';
  }
  App.applyTheme = applyTheme;

  document.addEventListener('DOMContentLoaded', () => {
    applyTheme(App.Store.settings().theme);
    $('[data-theme-toggle]').addEventListener('click', () => {
      const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
      App.Store.setSetting('theme', next);
      applyTheme(next);
    });
    $('[data-sheet-backdrop]').addEventListener('click', closeSheet);
    document.addEventListener('keydown', e => { if (e.key === 'Escape') closeSheet(); });

    // القراء والمشغل
    App.Catalog.load();
    App.initPlayerUI();

    window.addEventListener('hashchange', route);
    route();

    // تطبيق ويب تقدمي (يعمل دون اتصال بعد أول زيارة) — فقط عبر http/https
    if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
      navigator.serviceWorker.register('sw.js').catch(() => {});
    }
  });
})();
