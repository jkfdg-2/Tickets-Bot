/* التسجيل الصوتي لتلاوة المستخدم أثناء التسميع (MediaRecorder)
   + حفظ التسجيلات على الجهاز في IndexedDB (أكبر من أن تتسع لها localStorage). */
(function () {
  const MR = window.MediaRecorder;
  const MIME = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg;codecs=opus'];

  class VoiceRecorder {
    static supported() { return !!(MR && navigator.mediaDevices && navigator.mediaDevices.getUserMedia); }

    constructor() { this.rec = null; this.stream = null; this.chunks = []; }

    async start() {
      if (!VoiceRecorder.supported()) return false;
      try {
        this.stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
        const mimeType = MIME.find(t => MR.isTypeSupported && MR.isTypeSupported(t));
        this.rec = new MR(this.stream, mimeType ? { mimeType } : undefined);
        this.chunks = [];
        this.rec.ondataavailable = e => { if (e.data && e.data.size) this.chunks.push(e.data); };
        this.rec.start(1000);
        return true;
      } catch (e) {
        this._release();
        return false;
      }
    }

    get active() { return !!(this.rec && this.rec.state !== 'inactive'); }

    /* يُرجع Blob التسجيل، أو null إن لم يُسجَّل شيء */
    stop() {
      return new Promise(resolve => {
        if (!this.active) { this._release(); resolve(null); return; }
        const rec = this.rec;
        rec.onstop = () => {
          this._release();
          resolve(this.chunks.length ? new Blob(this.chunks, { type: rec.mimeType || 'audio/webm' }) : null);
        };
        try { rec.stop(); } catch (e) { this._release(); resolve(null); }
      });
    }

    _release() {
      if (this.stream) this.stream.getTracks().forEach(t => t.stop());
      this.stream = null;
    }
  }

  /* مخزن التسجيلات: المفتاح = وقت الجلسة (at) في سجل التسميع */
  const DB = 'rattil-recordings', OS = 'recordings', MAX = 30;
  let dbp = null;
  function db() {
    if (!dbp) dbp = new Promise((res, rej) => {
      if (!window.indexedDB) { rej(new Error('no-idb')); return; }
      const r = indexedDB.open(DB, 1);
      r.onupgradeneeded = () => r.result.createObjectStore(OS);
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });
    return dbp;
  }
  function tx(mode, fn) {
    return db().then(d => new Promise((res, rej) => {
      const t = d.transaction(OS, mode), s = t.objectStore(OS);
      const out = fn(s);
      t.oncomplete = () => res(out && 'result' in out ? out.result : undefined);
      t.onerror = () => rej(t.error);
    }));
  }

  const Recordings = {
    get: id => tx('readonly', s => s.get(id)).catch(() => null),
    keys: () => tx('readonly', s => s.getAllKeys()).catch(() => []),
    remove: id => tx('readwrite', s => s.delete(id)).catch(() => {}),
    clear: () => tx('readwrite', s => s.clear()).catch(() => {}),
    async save(id, blob) {
      await tx('readwrite', s => s.put(blob, id));
      // الإبقاء على آخر التسجيلات فقط لتوفير مساحة الجهاز
      const keys = (await this.keys()).sort((a, b) => a - b);
      for (const k of keys.slice(0, Math.max(0, keys.length - MAX))) await this.remove(k);
    },
    ext: blob => /mp4/.test(blob.type) ? 'm4a' : /ogg/.test(blob.type) ? 'ogg' : 'webm'
  };

  App.VoiceRecorder = VoiceRecorder;
  App.Recordings = Recordings;
})();
